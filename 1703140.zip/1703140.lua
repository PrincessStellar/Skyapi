-- Lua provided by SkyAPI 
-- Game: Isle of Jura
addappid(1703140)
addappid(1703141, 1, "981eb524fa6581a1cbc2141a1a03c3e8b26196f322d4516c6e55c7ca706baef4")
addappid(1703142, 1, "3fa89001c0603d701adbe03e3d5ab1bd6e035004930f2e9b3132ae1cbaa0153a")
addappid(1703143, 1, "d4ef17b2b98d9112f950dd0cf20f4fc602e9136719346846378caef163c6ba61")
