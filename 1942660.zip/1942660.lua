-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1942660)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1942661,0,"9d1b0097a379bec2df245db6cf282f44f4b7d1760a07a012f664eb1acb888686")
setManifestid(1942661,"8345020917175693014")