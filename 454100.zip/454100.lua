-- Lua provided by SkyAPI 
-- Game: Dungeon Escape
addappid(454100)
addappid(454101, 1, "37709ba8f29ea4fce083fa35a3d6f01196604f4ec9fa859bd71bdc0dea5d79d9")
