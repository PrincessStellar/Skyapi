-- Lua provided by SkyAPI 
-- Game: Super Puzzle Platformer Deluxe
addappid(238530)
addappid(238531, 1, "f8e158ee6a4eaa95a38cd9b6452f16f34b91ccf2a5e50b103547409d60868d1c")
