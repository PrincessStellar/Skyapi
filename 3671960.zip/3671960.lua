-- Lua provided by SkyAPI 
-- Game: AppID 3671960
addappid(3671960)
addappid(3671961, 1, "53bd803aaad1d79da4caf3918bc4fd29cbbd6cf4167050d7175e525e51c3abfd")
addappid(3671962, 1, "6e56f901344f9d41f5859da0b344628986f668721af485b5644c485ff3e052c4")
