-- Lua provided by SkyAPI 
-- Game: Beyond the Long Night: Original Soundtrack
addappid(2350600)
addappid(2350601, 1, "7d441e9abe5c961088ced6ee650f66d4125d2d1eda75559f4cd8c27a368f1363")
addappid(2350602, 1, "8388e1a9de5dc5c04da4a406267ada1c219bc53899a20b0aa99454812fe112e9")
