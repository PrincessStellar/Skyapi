-- Lua provided by SkyAPI 
-- Game: Cute Farmer Life
addappid(2556160)
addappid(2556161, 1, "1c085ee216faad7bc550091b3f5fd127fa56d5723f13b6299b4aa58a45adc1a8")
addappid(2556162, 1, "2343b1e088b474ed0002df013a1515b2ff84a3bebb11c63769f1f95e52b63d8f")
addappid(2556163, 1, "e94b11f86ab05b8080dc23c665ada5ce05e0b4db8a0556e3b8cc65ffa92e1a5f")
