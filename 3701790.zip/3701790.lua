-- Lua provided by SkyAPI 
-- Game: AppID 3701790
addappid(3701790)
addappid(3701791, 1, "9f7543d72971ac797e1e163c957f93c745254f4d6faaa7c5c82cb52b4d3710c8")
addappid(3701792, 1, "f8498e1d15c406775f8819a6bfdb2c3ee03e45e09efcba4d858cf1501cc4ed4e")
