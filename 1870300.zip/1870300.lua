-- Lua provided by SkyAPI 
-- Game: SOVL: Fantasy Warfare
addappid(1870300)
addappid(1870301, 1, "bf490f0cc51b55f40f81878a7bf7f250a31a0adf39bb3c76ac06b82a9c9fad86")
addappid(1870302, 1, "333736498f35cc5e583dc48ecba8f769403fec828e64c3897e1b6b4558861259")
