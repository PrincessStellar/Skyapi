-- Lua provided by SkyAPI 
-- Game: Hyperspace Pinball
addappid(349020)
addappid(349021, 1, "239b6919569f55129f1ec9f6a1052d497719186cdc044763e72d85fec346ab9b")
addappid(494300, 0, "ae7ee6cc869d8e79df6618d7d0b35bf3b0ad3c974287ec756b230021136d3a69")
