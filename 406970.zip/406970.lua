-- Lua provided by SkyAPI 
-- Game: AppID 406970
addappid(406970)
addappid(406971, 1, "2b4f06ffde27ebd013fe0ae18746e619908eafe52d1c020769d81af0a0d30527")
addappid(564030, 0, "0f0b83c8aed959c1e5d410d75218ccbdae4d9025c88c1180d6e06b83ff291aa7")
