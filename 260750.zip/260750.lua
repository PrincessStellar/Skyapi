-- Lua provided by SkyAPI 
-- Game: Neighbours from Hell Compilation
addappid(260750)
addappid(260751, 1, "b859045ab96b7796ef93ec90224ebf5933ca52269563a8cb98706ac4740ea702")
