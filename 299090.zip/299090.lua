-- Lua provided by SkyAPI 
-- Game: Cosplay Maker
addappid(299090)
addappid(299091, 1, "564ab8f2ceaeac942375ec2bd964abc6a5f8a6b36e1a1b7d6e2ffe6e748cb616")
