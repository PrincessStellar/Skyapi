-- Lua provided by SkyAPI 
-- Game: Learn Japanese To Survive! Hiragana Battle
addappid(438270)
addappid(438271, 1, "1bce0d9e436c12282959bd6d0af991b746de30d55610d93571afb57650edfc4c")
addappid(572210, 0, "c8b1b7624395a290a242590b604b3b460ffb6e3d57d46c38c9cf0b10b1d52673")
