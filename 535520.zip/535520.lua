-- Lua provided by SkyAPI 
-- Game: Nidhogg 2
addappid(535520)
addappid(535521, 1, "c7bde878b201e0ac69b8431c894b333fe26adbd6f6f47455075720c4f29bb7c0")
addappid(683740, 0, "49594b56ff5790ccfaf0950b5f9281cd4f5ef63c826489d16b998addf32478f8")
