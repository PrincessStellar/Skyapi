-- Lua provided by SkyAPI 
-- Game: Mistake
addappid(1817400)
addappid(1817401, 1, "dfd653557af780dabd3ba1e29e6f82e5432e6ce56c4eaad3fb011d0368ea5b70")
addappid(1817402, 1, "135520176d9bf71852771c245589bf79d7291d3b0dc2fdf7d03e41b6254ce38b")
