-- Lua provided by SkyAPI 
-- Game: Depths of Peril
addappid(23600)
addappid(23601, 1, "e93576ac9dd1630eb3b10f8f8be0ca0a6403ebaae1ac22f59417fd80e1b0fd12")
