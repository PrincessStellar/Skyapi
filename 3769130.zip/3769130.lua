-- Lua provided by SkyAPI 
-- Game: Keep on Mining!
addappid(3769130)
addappid(3769131, 1, "79dda683e39e3551788e59192e005fe2d8b3e5f3f3adecacf712b638a9e732b3")
addappid(3769132, 1, "4143d4c98337ddcbaa5a9c74444b143a9204495eca185108b268a76f237de3a6")
addappid(3862020)
