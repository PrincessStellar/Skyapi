-- Lua provided by SkyAPI 
-- Game: AppID 622370
addappid(622370)
addappid(622371, 1, "5731b251bd91bab4bd13eb9f64917010d24611f8ae56397a239952d36538a405")
addappid(683270, 0, "0e9b7b04517f5f7093b9d1a43ecf4147c39cd7b6b56eaf1aa9ba953b12fcbc36")
