-- Lua provided by SkyAPI 
-- Game: Penarium
addappid(307590)
addappid(307591, 1, "7e16ebed6477d67a710cc9137510f349b043c1ac7b11c258b8ebe228d1d8f9c6")
