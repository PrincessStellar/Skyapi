-- Lua provided by SkyAPI 
-- Game: Rage Runner
addappid(279520)
addappid(279521, 1, "061b79d20450fc7bf19567c8a97668a3500107a8357f05fa9ad5a9390b40a759")
