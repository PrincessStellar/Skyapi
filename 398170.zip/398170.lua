-- Lua provided by SkyAPI 
-- Game: AppID 398170
addappid(398170)
addappid(398171, 1, "a7049f0c044d46c74c90c119a5cae418cb0f0c76a3fdccbc4e0066158f41d7b3")
