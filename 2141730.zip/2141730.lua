-- Lua provided by SkyAPI 
-- Game: Backrooms: Escape Together
addappid(2141730)
addappid(2141731, 1, "cfcbb1b05a371faabeb03500c308dbae345a2c7d9a45417a910283c9201e084d")
addappid(2141732, 1, "1038f744a70ce5b445cdbfc9ce77601ae45a36279d0a9ad02b59b714acfba762")
