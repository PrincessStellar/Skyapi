-- Lua provided by SkyAPI 
-- Game: Earthworm Jim
addappid(38480)
addappid(38481, 1, "6778a7f58d926166ed32d1f84241ff1b10a0b7145ca2ca0077ad0f7c70801607")
