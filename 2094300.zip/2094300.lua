-- Lua provided by SkyAPI 
-- Game: Virtual AI - Aki & Mika
addappid(2094300)
addappid(2094301, 1, "3be580c2ce127bd8e5297deb909d28b35dda4bfd772ce541ad02666277ce8538")
addappid(2094303, 1, "d76a80a713b5591fcd2135ee785918a9a3fa2ebbc230c03d5add89062cd7b4a9")
addappid(2094304, 1, "1b4cbb7151278b9783e35357b1cb03eb4e279aff246e042f837a4490e86e6835")
