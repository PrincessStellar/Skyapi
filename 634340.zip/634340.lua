-- Lua provided by SkyAPI 
-- Game: AppID 634340
addappid(634340)
addappid(634341, 1, "2df235a2678d2e6670b2a75c4d4923e0741e070002db35b1d4a0a71cf119bbf8")
