-- Lua provided by SkyAPI 
-- Game: Dream Chamber
addappid(391590)
addappid(391591, 1, "7b900a7f6cbfa58856846e8d595f7a66b4d76b3b924dd3b997c018ae68cbaf0c")
