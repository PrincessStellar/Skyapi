-- Lua provided by SkyAPI 
-- Game: Alwa's Awakening
addappid(549260)
addappid(549261, 1, "99f0b4233558c86da42f820c0a224713ef79fc9fbf0dbb03264f1210e1c40a1d")
addappid(2001510, 0, "60f19b45ae85f0035f9eda766cc00d03df217f0573988ca1399f7a600f1ed1c1")
