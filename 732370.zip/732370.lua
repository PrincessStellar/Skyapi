-- Lua provided by SkyAPI 
-- Game: Juicy Realm
addappid(732370)
addappid(732371, 1, "51b51a81caa136eddf4825a0666102dc91529eaa0534361c239f230f8b85b8bd")
