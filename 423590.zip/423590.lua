-- Lua provided by SkyAPI 
-- Game: The Little Acre
addappid(423590)
addappid(423591, 1, "7bfdce1a68a2d5141d0a505fc031e983169cee973a5907ab3d7c66271b2d55ea")
addappid(554340, 0, "876c11b7d6e580cbba99ee0406bba9c1a0ac671a24498b629e4195bd3e0383fb")
