-- Lua provided by SkyAPI 
-- Game: AppID 330990
addappid(330990)
addappid(330991, 1, "2a72c0f9295caa9799f9446a7a1a55bcb4272560ddeb2845e31b8dabbf08e430")
