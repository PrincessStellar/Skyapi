-- Lua provided by SkyAPI 
-- Game: AppID 703950
addappid(703950)
addappid(703951, 1, "925ddb1dd827550cd6aa878450c843e8d953df50d57e99a9e0d570b5d3ad70ae")
