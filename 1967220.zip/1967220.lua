-- Lua provided by SkyAPI 
-- Game: No Return
addappid(1967220)
addappid(1967221, 1, "c186d27d3af23cca8b3ef364c0392f9f9d5d161c465bb4f0e499cebd8c77b71f")
addappid(1967222, 1, "ccb9e4ab039d2e242a089a3cfeff880e49a390aa82bda5a3ef874bc8c7e38d8c")
addappid(1967223, 1, "69ae711ad4ecc0dc3778157baf6a50154389487f5c9af17efb4535e56111e423")
