-- Lua provided by SkyAPI 
-- Game: OPUS: Echo of Starsong Complete Soundtrack -Vol.2-
addappid(1838330)
addappid(1838331, 1, "c69238fb8a31026d752b7e78b9f0ffb7f62f56fc2add686c338e952b8c1d95a5")
addappid(1838332, 1, "5b6af6e1681225ac20c9c08c142b74711a98262179807b7a37231db2f5a76330")
