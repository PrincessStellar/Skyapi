-- Lua provided by SkyAPI 
-- Game: Cloudbase Prime
addappid(511250)
addappid(511251, 1, "ee5df89b880a367378ee00ec6725a7350c180e12a4fd9d0d55e2a27a0d772ecf")
