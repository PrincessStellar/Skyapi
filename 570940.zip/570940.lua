-- Lua provided by SkyAPI 
-- Game: DARK SOULS™: REMASTERED
addappid(570940)
addappid(570941, 1, "e782efcd07a6c765e4393f9b7b6285c09819e62da5f1573e40f15b98303799fe")
