-- Lua provided by SkyAPI 
-- Game: Märchen Forest Original Soundtrack
addappid(1611500)
addappid(1611501, 1, "58b33292bb207f31ac7638612f36d6f2b85520db2befc71f10ed5d9df28a2c83")
addappid(1611502, 1, "72d4987a0786f83a84f6ac1fb9a72364fba328982e5f061154d286a5ba489ac5")
