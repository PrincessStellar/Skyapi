-- Lua provided by SkyAPI 
-- Game: AppID 481870
addappid(481870)
addappid(481871, 1, "113614cea802cbce9619a63f4faeb90ab2913454f2d9d0a41e29ca2d470b388d")
