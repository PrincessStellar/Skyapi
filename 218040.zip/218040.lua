-- Lua provided by SkyAPI 
-- Game: Democracy 2
addappid(218040)
addappid(218041, 1, "85fffde7e17ae52506a341777f6ae59ec62bc7981782c4d2523486a0d2e9f266")
