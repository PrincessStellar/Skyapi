-- Lua provided by SkyAPI 
-- Game: The Circle Tales: Elvenwoods
addappid(2805910)
addappid(2805911, 1, "92489497e5594ceab52df5e82436bf6a84159e85e43d66e37ba0f3a3fc9488df")
addappid(2805912, 1, "95a1050c7f02f2973c94ec08e2baf46e6375ded335278c90723b78582d6f8044")
