-- Lua provided by SkyAPI 
-- Game: Dreamscapes: The Sandman - Premium Edition
addappid(289260)
addappid(289261, 1, "cdc79d48b3b2a9ffcd3a6848590aee38abbe698e2618a071880076f3900f0fbf")
