-- Lua provided by SkyAPI 
-- Game: The Outforce
addappid(2633480)
addappid(2633481, 1, "f94c8b0a66458bb8fe9f4e223cdc262627237dfd16ba972d01697fe8c97073c8")
addappid(2633484, 1, "10ea0d8cc337fc827e9a2173c68b0aa8cf80c7e04b8637e84b75899c5f290512")
addappid(2633485, 1, "9e2c7bf5fa08210920a480b8ddf7884bf12f5f2d2446bd1e592da97a15fbbea9")
