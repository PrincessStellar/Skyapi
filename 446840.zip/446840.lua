-- Lua provided by SkyAPI 
-- Game: AppID 446840
addappid(446840)
addappid(446841, 1, "f2b439bd0d655618da85a92078e18f02084ba87e579c45835a24b3e8914f6233")
