-- Lua provided by SkyAPI 
-- Game: Trapped with Jester
addappid(2160000)
addappid(2160001, 1, "890f4d7e56ee84364c97eccc692f2a873bf17be9aaf33790fe17e51ae787db7d")
addappid(2160002, 1, "48637eabb49f2e0ebafe4d4a13cd243f045fcd2b6b5d60a72f8f8aca404b80af")
addappid(2171990)
