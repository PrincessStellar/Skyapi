-- Lua provided by SkyAPI 
-- Game: The Nightmare Cooperative
addappid(310070)
addappid(310071, 1, "42945f1594bb29fcd6ec3f6ae9894ee00907ee60f9ee210c48c6e5b8a67f17f6")
