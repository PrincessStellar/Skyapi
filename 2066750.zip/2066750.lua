-- Lua provided by SkyAPI 
-- Game: AppID 2066750
addappid(2066750)
addappid(2066751, 1, "a532152117ba3ac9dcd1abd484b212ca49b43f7a621f166f4bbf5d96787a39f8")
addappid(2066752, 1, "363b71809c76303b14eac577b19af86c0d58a29ea3d9b3b2ba5ac3b1445e8c86")
