-- 3199650's Lua and Manifest Created by Morrenus
-- Pathologic 3
-- Created: January 13, 2026 at 18:47:40 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(3199650) -- Pathologic 3
-- MAIN APP DEPOTS
addappid(3199651, 1, "5a843f4bb384528f9d115b2fb887b607b71c549a756fc80aa7af67bb07344f3a") -- Depot 3199651
setManifestid(3199651, "2283354827915798491", 43770373143)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4250480) -- Pathologic 3 - Supporter Pack
addappid(4284630) -- Pathologic 3 - Polyhedral Room