-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(543900)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(543901,0,"6660062fa5608dd613cb712c1e4f4d930be90938794ff33a3963dab922c843bf")
setManifestid(543901,"4780105174229705182")