-- Lua provided by SkyAPI 
-- Game: Frankenstein: Master of Death
addappid(347430)
addappid(347431, 1, "4a47395fef83912173ada889b02f8a2f51890a97c487da9c255ff58665645458")
