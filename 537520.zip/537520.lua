-- Lua provided by SkyAPI 
-- Game: SYMMETRY
addappid(537520)
addappid(537521, 1, "04f66cbe7be3fa6930c3d6e8689427b9530b6ce01172dba8733bf8f98a83b21c")
