-- Lua provided by SkyAPI 
-- Game: Never Alone (Kisima Ingitchuna)
addappid(295790)
addappid(295791, 1, "3716689fac3abf95a3b13b9ca78e16bdb3c2be6d2313e74a11003ce1457b5c07")
addappid(351740, 0, "3144dd495ef0758b0c9f0c33027209bcd3654f3b765c17dc1c486bbe3f158ce3")
addappid(355740, 0, "e42bcc7f20e0f89af4b61a246d0dbfc8eed45f9e7fee92936132dfdb1907cb92")
