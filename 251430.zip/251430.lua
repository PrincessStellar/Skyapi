-- Lua provided by SkyAPI 
-- Game: AppID 251430
addappid(251430)
addappid(251431, 1, "01be5ee7b465303040e9f0744a6d6000860b71907ab2d8d925a1aa1a6d6489b7")
