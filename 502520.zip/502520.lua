-- Lua provided by SkyAPI 
-- Game: Ultimate General: Civil War
addappid(502520)
addappid(502521, 1, "ad4835ef3ca4b2ab3c10eb9165897f84b2d1493b75a5393b7c1c1d64d7649f60")
