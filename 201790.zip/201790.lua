-- Lua provided by SkyAPI 
-- Game: Orcs Must Die! 2
addappid(201790)
addappid(201791, 1, "07e18a6715cee99f3c872f9fc3f7484243f7bf6c8dcbf57bebd21c3ed7e8e08a")
