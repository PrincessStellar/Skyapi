-- Lua provided by SkyAPI 
-- Game: Spooky Cats
addappid(372210)
addappid(372211, 1, "fb41e356ba292b54ac054fc25afe75eeb166bbd53262d08b84eddbf97b6ed9ab")
