-- Lua provided by SkyAPI 
-- Game: Dungeon of gain
addappid(340030)
addappid(340031, 1, "dd2f1ab8d03204a7bfa544f1a5b444f1bd8ddb5333838403e57044a241afa169")
