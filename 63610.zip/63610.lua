-- Lua provided by SkyAPI 
-- Game: Riven (1997)
addappid(63610)
addappid(63611, 1, "bbab6bc956cdec6de22bb380af99db1af024da253b40b7b7fed97cf752769562")
