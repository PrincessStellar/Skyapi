-- 1073440's Lua and Manifest Created by Morrenus
-- コイカツ / Koikatsu Party
-- Created: October 01, 2025 at 09:38:50 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 7
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1073440) -- コイカツ / Koikatsu Party
-- MAIN APP DEPOTS
addappid(1073441, 1, "91b8d0025bafa91d25b4027500725baf74cede579270d8b1804e3d43960cff9a") -- Koikatsu Party
--setManifestid(1073441, "8951179070837990656", 14508075360)
addappid(1073442, 1, "f51ee8eeaf2c6651ed85fe9cb664ce3c8ab64542b7d7fc246bc830bda03787f1") -- コイカツ / Koikatsu Party 繁_簡_Update
--setManifestid(1073442, "5081772461190184573", 1140271083)
addappid(1073443, 1, "0cb7226c0cf6905db84774c26458130048ee466c6812c4c8ad44a0e60f6b92c2") -- コイカツ / Koikatsu Party CustomUpdate　デポ
--setManifestid(1073443, "8133812221863396186", 379317708)
-- DLCS WITH DEDICATED DEPOTS
--   Koikatsu Party VR (AppID: 1109630)
addappid(1109630)
addappid(1109631, 1, "06f2dba1f6521736c124ffcc98424ae1811deac1c2d22ee0d9e689a6e0300f8e") --   Koikatsu Party VR - コイカツ！ / Koikatsu Party VR
--setManifestid(1109631, "5399546537393896809", 352878069)
addappid(1109632, 1, "c5ea30717d1e42129546361de7719d65b462a2f15b432c965c017c81ce0e32c4") --   Koikatsu Party VR - コイカツ！ / Koikatsu Party VR デポ 中国語対応
--setManifestid(1109632, "1771320043801749055", 132211512)
addappid(1109633, 1, "e9a49ce4ad36743d58c10e5fcb5dbf912c563531ba6b676744b28b5e7230cc5f") --   Koikatsu Party VR - コイカツ！ / Koikatsu Party VR キャラ調整デポ
--setManifestid(1109633, "4677410745437728552", 202793745)
--   Koikatsu Party -  After Party (AppID: 1485180)
addappid(1485180)
addappid(1485180, 1, "c01385d129651901af75550a75641424e4224b75b69ea8b3c93ecd64c63be19b") --   Koikatsu Party -  After Party - コイカツ！ / Koikatsu Party - 拡張パック After Party デポ
--setManifestid(1485180, "3413466757197005956", 5211038743)