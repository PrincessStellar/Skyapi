-- Lua provided by SkyAPI 
-- Game: Shardlight
addappid(336130)
addappid(336131, 1, "fb318a3837fd589643057a0b91e6932df74037f9ea4e0ac0e99aa33608e1f8d1")
addappid(447870, 0, "fbf7bc183072212be848e637802a0ebf76d552133a20a8a598f175c87ff79725")
