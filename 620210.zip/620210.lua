-- Lua provided by SkyAPI 
-- Game: Fatal Twelve
addappid(620210)
addappid(620211, 1, "73905704c3b652cac12e832523c96b0f04e358087cc42f276b52aa65330c1c8e")
addappid(838140, 0, "76eff396de5d7c28fb074eea4b85228eef0cbd9e12a23e62ee4a6f2984b85b87")
addappid(2416310)
