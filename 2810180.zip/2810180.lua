-- Lua provided by SkyAPI 
-- Game: Rise Of The White Sun Soundtrack
addappid(2810180)
addappid(2810181, 1, "ec8f523e609e3b5c869e393062f9d0687e967e1261fb5e8e101a619509b07af3")
addappid(2810182, 1, "9738e33f2cab2fcef37149e27b098a8fceb70c36cd674f1687900b7255b6af5a")
