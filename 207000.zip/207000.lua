-- Lua provided by SkyAPI 
-- Game: Alien Spidy
addappid(207000)
addappid(207001, 1, "712a4181cd75a88f43c3f84bb8e9e0895c3d33506b207d3f4ea9e8703a8570c6")
addappid(207951)
