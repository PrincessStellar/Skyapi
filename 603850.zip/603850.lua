-- Lua provided by SkyAPI 
-- Game: AppID 603850
addappid(603850)
addappid(603851, 1, "03e3821f3ac71152e806701403e0c9252f4839c75291b5b3a585aacd9e962080")
