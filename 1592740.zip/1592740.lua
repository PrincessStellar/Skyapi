-- Lua provided by SkyAPI 
-- Game: Railroad Ink Challenge
addappid(1592740)
addappid(1592741, 1, "f75729627154a140ba2850ba4be68ede81d27836681c764970846ebd5245e26b")
addappid(1592742, 1, "e593df2d9a9e04e93759b2a7a93ff50580658aa80a0e6656598efe31ccf58244")
