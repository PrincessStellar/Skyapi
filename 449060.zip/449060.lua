-- Lua provided by SkyAPI 
-- Game: Cellar
addappid(449060)
addappid(449061, 1, "f90e2d8185def1dad3e6cb47629fc33c77045cc97483a223199d686038c82923")
