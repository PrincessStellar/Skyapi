-- Lua provided by SkyAPI 
-- Game: Astatos Original Soundtrack
addappid(1764200)
addappid(1764201, 1, "6c2121533f29b221e912b06214c88f9e568151562fb0a20a5fc92384bd65013e")
addappid(1764202, 1, "5ab746dd6eca4f250d8e0eec03512e625a9958aa92c63f89f9f0d169a1ae169b")
