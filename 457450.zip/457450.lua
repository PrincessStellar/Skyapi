-- Lua provided by SkyAPI 
-- Game: Defend Your Crypt
addappid(457450)
addappid(457451, 1, "4ac48c2f51b082de57ec2870e5d7d7e3c0c979a3fb61018835974e61c67fd302")
addappid(470200)
