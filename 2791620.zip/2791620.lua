-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2791620)
addappid(2791621,0,"4fbe2fde3244cb2e4492c6b449d3c7825e06a8cbe72ac04a197985015358af12")
setManifestid(2791621,"1306097263951966945")