-- Lua provided by SkyAPI 
-- Game: Automate It Original Soundtrack
addappid(3588550)
addappid(3588551, 1, "ef2c82f1c9308377dd17b66aecf4693125227f85d35a88bd19632d3970d673bd")
addappid(3588552, 1, "d3dfcf872fb717f90c086b091fee337a364b15900d5e12d5898b9b85515dda7b")
