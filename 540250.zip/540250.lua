-- Lua provided by SkyAPI 
-- Game: Tank Battle: 1945
addappid(540250)
addappid(540251, 1, "df3ceaf496a3e1ff0c5c0b10591f9df8ae6278309c0748bd4d77571c66393758")
