-- Lua provided by SkyAPI 
-- Game: Liveza: Death of the Earth
addappid(463100)
addappid(463101, 1, "a046ec89a38987ec2d34f9342b08dd33c96c2f0aa2ba10060bf736e55aad8f53")
