-- Lua provided by SkyAPI 
-- Game: AppID 264140
addappid(264140)
addappid(264141, 1, "58a18168231b4cde2a56a5264db6cf2d4abfe30b33d46e845a9b3649cb926041")
addappid(365970, 0, "635ab13dedd745136361f48389694cc84e48131dda6716bcf9a40b44f07897f9")
addappid(2314920)
