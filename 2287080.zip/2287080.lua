-- Lua provided by SkyAPI 
-- Game: FLUCTUOID
addappid(2287080)
addappid(2287081, 1, "1ceb32a7a4623bd9b01342890bac4ebcb451755ab7d9597ffa8a259c098f21a3")
addappid(2287082, 1, "1c3f5a408d638cc6d9f6d1c91a29240803e20a8b54e166c00225f227d2e5c0a4")
