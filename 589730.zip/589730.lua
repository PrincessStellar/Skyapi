-- Lua provided by SkyAPI 
-- Game: AppID 589730
addappid(589730)
addappid(589731, 1, "2895c8cbbc00cfbcc54cba8ef07d9b164c22b8078b348bfc5a9d00852c1f0a2e")
