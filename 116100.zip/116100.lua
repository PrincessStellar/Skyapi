-- Lua provided by SkyAPI 
-- Game: Super Toy Cars
addappid(116100)
addappid(116101, 1, "ce237214d91a5d96b1c9e576cf20f7c65de12f071b57958b3b425af0b52dda79")
