-- Lua provided by SkyAPI 
-- Game: Castle Crashers®
addappid(204360)
addappid(204361, 1, "2428bf7adcf5bac5af5d4f346adeea328831349da1ac601a9d6c33db6d6b5677")
addappid(3133920)
