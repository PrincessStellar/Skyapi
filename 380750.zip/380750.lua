-- Lua provided by SkyAPI 
-- Game: Anima: Gate of Memories
addappid(380750)
addappid(380751, 1, "37ee9621d197eeb71e1009946f71fee423b8e11fdefc5eb5846cf97c8a2a0090")
addappid(538930, 0, "b78d44ac10c1d08a2740bd6b755b83835aac6aca1d9651b53af1a7d00f8fd10a")
