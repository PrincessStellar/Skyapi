-- Lua provided by SkyAPI 
-- Game: Scribble Space
addappid(351450)
addappid(351451, 1, "74f7d2ccfe126ef69f16100f7b8e71efcc8436be66c1a669fd43852d7b978a6b")
