-- Lua provided by SkyAPI 
-- Game: AppID 419810
addappid(419810)
addappid(419811, 1, "017eb0eab85107c75b508e7505cb073151837b1965ee8ce6859806eed82ada75")
