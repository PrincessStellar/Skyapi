-- Lua provided by SkyAPI 
-- Game: DRAINUS Original Soundtrack
addappid(2004950)
addappid(2004951, 1, "df77a509de32476017628adc4b09dd15ca1ae2748e24552049409a0f6fc0f926")
addappid(2004952, 1, "61602df57a9a9e08a63a613d9deee3c5d59d54dae3550c02502132af0332cf7b")
