-- Lua provided by SkyAPI 
-- Game: PAC-MAN 256
addappid(455400)
addappid(455401, 1, "4fdc5f2690ff3db27995339d2f6a292662f48e53b5ef23df5a0190e2c13dee7a")
