-- 1156120's Lua and Manifest Created by Morrenus
-- DOOMBRINGER
-- Created: December 05, 2025 at 10:59:02 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1156120) -- DOOMBRINGER
-- MAIN APP DEPOTS
addappid(1156121, 1, "f0668802a2df06060549621fdcea840e7b3f5415c2c79b5fd45cfb9f94d50f95") -- DOOMBRINGER Content
setManifestid(1156121, "6102375543926000220", 5378092653)