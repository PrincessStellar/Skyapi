-- Lua provided by SkyAPI 
-- Game: Flagi
addappid(2124390)
addappid(2124391, 1, "02202931ba03149e22d3a2005e012b64e938f2acfeb21821b9b29c0a1fb198f7")
addappid(2124392, 1, "195dea98cebfc83ddafa04dd9fa6a6f95038116974385414fe89b7bb64b31ec9")
addappid(2124393, 1, "f556c3af76cace088d69f9c0d0d3ac8b03183adb239c8ad796b1d003a6b6629d")
