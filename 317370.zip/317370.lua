-- Lua provided by SkyAPI 
-- Game: The Keep
addappid(317370)
addappid(317371, 1, "060d24b8cfb0c1652eb72a5da74d67a6422e149872ff51956f7a86cb1d16405c")
