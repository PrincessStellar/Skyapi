-- Lua provided by SkyAPI 
-- Game: 風色幻想SP:封神之刻
addappid(2020540)
addappid(2020541, 1, "cad2a10cdaccf10725c59278d3309d3ddcd5f7b1d0a9876ec9c828dd94ca055d")
addappid(2020542, 1, "4d788c2e6e719f23b92c5c76e9c38aca83144b4253ca5f87ba4c3b603667de76")
