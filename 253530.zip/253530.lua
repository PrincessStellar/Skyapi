-- Lua provided by SkyAPI 
-- Game: AppID 253530
addappid(253530)
addappid(253531, 1, "d64e06d35da487acad1c766551ad9b0edfcc3c9edf3e4e178605e73271ec0ca4")
