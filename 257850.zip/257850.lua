-- Lua provided by SkyAPI 
-- Game: Hyper Light Drifter
addappid(257850)
addappid(257851, 1, "37a8a32e3f159349f6a5702f391bdd0d4a341ae4c61d63111b9ae41c6b7ee678")
