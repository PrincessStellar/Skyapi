-- Lua provided by SkyAPI 
-- Game: AppID 440650
addappid(440650)
addappid(440651, 1, "173b902c8affd1385f5e1087a2ec9c5ea9737f0d1540c21344efc2cdb62135cc")
addappid(712900, 0, "7c75d34250e255708b38d182519d0798068b4d8fe113735eb16341fcb9f53dbf")
