-- Lua provided by SkyAPI 
-- Game: AppID 719040
addappid(719040)
addappid(719041, 1, "f91809973de8000057590dbcfbacae7ca360a08589cc923bb510ac7c4722240a")
addappid(1191060)
addappid(1382210, 0, "68e5b6c946ca34cd022286692fccfc5aac7da40cfae9dd3ff4e5e8f09c49baa8")
addappid(1522650)
addappid(1593330)
addappid(1642320)
