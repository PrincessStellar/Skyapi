-- Lua provided by SkyAPI 
-- Game: Journey to the West Soundtrack
addappid(2119250)
addappid(2119251, 1, "d4e34e1ede9959f6b1d91b2645a135096c1a0c45611ee0af0c5b741b43e79993")
addappid(2119252, 1, "49652cad32ca56ebb56852cd4c94b41b0870fc8cf440eb9fe2677d9b0f94a4ff")
