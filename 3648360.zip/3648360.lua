-- Lua provided by SkyAPI 
-- Game: The Beast and the Princess
addappid(3648360)
addappid(3648361, 1, "b0b0def1da047b637b94225f1211d7d36d4c69119cd6b985de1e75bf504e5eb5")
addappid(3648362, 1, "e346b1509c8935123b3ce99a479b707468fec4dad12c945f38e2e2457dc81ef4")
