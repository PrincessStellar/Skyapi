-- Lua provided by SkyAPI 
-- Game: Hypnagogia: Boundless Dreams Soundtrack
addappid(2530340)
addappid(2530341, 1, "33510544111ae0c5316d867bca5927db2721fe6eccaa3b721b9630cb54002846")
addappid(2530342, 1, "7613912d23709eec70f675e6b6c591235454b12af66a668c9cfc2825116a5442")
