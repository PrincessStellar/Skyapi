-- Lua provided by SkyAPI 
-- Game: Snapshot
addappid(204220)
addappid(204221, 1, "47d544d948be9491de9f4364464eafb0d8e457390c8781bdc2149db8a483a3f2")
addappid(219380, 0, "749880ecf32a1cf88ffb7ebae2b179c5421f958b7b29fe0bf79d17ce4a0c4ac6")
