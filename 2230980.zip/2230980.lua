-- Lua provided by SkyAPI 
-- Game: Caribbean Legend
addappid(2230980)
addappid(2230981, 1, "e7fe65b71497e767bb8766c4fe56dc415b2d80b04c17e0b513f8f63c913fc4f4")
addappid(2230982, 1, "91bee1c1f2bfb0853316a2d1104ede22aaee2beca78ccecfbbc4c586eee29a8d")
