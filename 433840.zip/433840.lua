-- Lua provided by SkyAPI 
-- Game: AppID 433840
addappid(433840)
addappid(433841, 1, "02a4f8785d34cd7c032b7b996fa83edcf3879b26aa6e3b791008db27c6bd5542")
