-- Lua provided by SkyAPI 
-- Game: The Maker's Eden
addappid(313360)
addappid(313361, 1, "b66e3c43a848f27c1c261d8635120559c263b1ab10022c1909eb69c352c70a7a")
addappid(316640, 0, "f95b5f56a0fa8cfe52e0c130aded6e37859c1ff7655a1a4ba3b8e77cdfd3db95")
