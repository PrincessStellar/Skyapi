-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1644960)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1644961,0,"7bd16fd362dc178163d8afa11b87e3fe72a6c53a23d000d8b4671c601f1c5d95")
setManifestid(1644961,"2365432848179719315")