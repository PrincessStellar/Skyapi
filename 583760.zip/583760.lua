-- Lua provided by SkyAPI 
-- Game: Slash It 2
addappid(583760)
addappid(583761, 1, "02c46e33b40e6c08eb5bb91f1982ba12f5f9a7c0d62f5d4e95a770e34612ad6d")
