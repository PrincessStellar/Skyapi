-- Lua provided by SkyAPI 
-- Game: Isaac the Adventurer
addappid(341260)
addappid(341261, 1, "6b3553c7783e3574083a97bec702e0208ce47d1999ed34272ceedb3dd5235de7")
