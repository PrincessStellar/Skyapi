-- Lua provided by SkyAPI 
-- Game: Spirit City: Lofi Sessions
addappid(2113850)
addappid(2113851, 1, "c96341ff6c37bb63b6a46045e820f5c956aeea66a47703fb62c8476f09300ae9")
addappid(2113852, 1, "554e69a56122534ea8d5ddaab8928c69bcd639fd5ca10425459c1617d2f3f908")
