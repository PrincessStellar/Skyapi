-- Lua provided by SkyAPI 
-- Game: Longvinter
addappid(1635450)
addappid(1635451, 1, "c2ee929e91b9cd2a8c5fbeacc241aa350dd3d69ef9b816e088ca7f13d8a1bb7c")
addappid(1635452, 1, "e8ba636ef56364d7b8ac0a117aaf34b9218b34c51597690c910afeb6f34f3f47")
