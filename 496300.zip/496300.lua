-- Lua provided by SkyAPI 
-- Game: Kingdom: New Lands
addappid(496300)
addappid(496301, 1, "572df00b3e10f4316ee29f1b11a3ac01192e3cd6a58b7332781d8b1101bf89e3")
