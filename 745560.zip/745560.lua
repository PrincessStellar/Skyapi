-- Lua provided by SkyAPI 
-- Game: Overclocked
addappid(745560)
addappid(745561, 1, "b54949e0e4eb367d4ca0d8515fe8302a90b854eb9663d9a5820106fa0907c2e0")
