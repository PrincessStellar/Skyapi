-- Lua provided by SkyAPI 
-- Game: AppID 2419920
addappid(2419920)
addappid(2419921, 1, "26f662cf9c77bd813b31de5f69235a3dc04f7985324467d37c686fceff425c46")
addappid(2419922, 1, "fb33bc6abdfd4051a60756960781a64cba56167f9a2ba0da9134de0edc8ea70d")
