-- Lua provided by SkyAPI 
-- Game: AppID 493280
addappid(493280)
addappid(493281, 1, "a52c3d75e15c97d7ff48db74b3708499de1b7f4d1ec21b4df5735952a3d32fc7")
