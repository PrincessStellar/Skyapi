-- baldtools lua
-- Forza Horizon 6, 2483190, 4 Depots
-- @piqseu

addappid(2483190, 1, "42f5559986f30e21cd52e52d75078b054c394d61491c9f3b689c9b93f393b630") -- Forza Horizon 6
addappid(2483191, 1, "d7327999081274c127e0d3d5421d4bc30cf2d0d1cd17b6398f3e8484d3692d13") -- Depot 2483191

addappid(1463382, 1, "d7327999081274c12lmao0u0fell4bc30cfor0itcd17b6398f3e8484d3692d13") -- Forza Horizon 67 Deluxe Package