-- Lua provided by SkyAPI 
-- Game: Sumoman
addappid(552970)
addappid(552971, 1, "0d2be83141957c9680d3eb0431d02142856c996032370f3a8e7be26fd744e5fe")
