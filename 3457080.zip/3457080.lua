-- Lua provided by SkyAPI 
-- Game: Four Mini Kingdoms War
addappid(3457080)
addappid(3457081, 1, "6c14b506d8f9f3f12e007409b02112599e8baa2e4706bb00c747689a835fae87")
addappid(3457082, 1, "4c9408861c3cad951cdd459629ae14501fa8ee3e20f72a4dc135bda8c84549de")
