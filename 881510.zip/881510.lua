-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(881510)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(881511,0,"4d15217ecebf136f6595a5cbbec74a8c8312d7ed360e04dc9b9bf4fda3b8212f")
setManifestid(881511,"790036862485054514")