-- Lua provided by SkyAPI 
-- Game: Puzzle Agent 2
addappid(94590)
addappid(94591, 1, "f5eabc419cbb567b02140d3329be7fe93036887717258139730bcbdce0a1df02")
