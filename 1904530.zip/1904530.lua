-- Lua provided by SkyAPI 
-- Game: Forgotten Realms: The Archives - Collection Three
addappid(1904530)
addappid(1904531, 1, "11c62fcf53b08fad6acc489157c4e3838d25d1f8e119865685abed8e8054ab9d")
addappid(1904550, 1, "ae8cd96c49460f25870726c6e13badf5c85ee11e9adf7fc7681d76358e8a65c0")
addappid(1904551, 0, "787b231da5d126661beeb2780472475f844ff32fa4fd489869d5f459b7b9d6eb")
