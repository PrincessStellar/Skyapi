-- Lua provided by SkyAPI 
-- Game: SGS Battle For: Shanghai
addappid(2595230)
addappid(2595231, 1, "c381fa4c563e787a597d653a7b7e916d0aa18ae6911fe7f422c7758d944e92d6")
addappid(2595233, 1, "2f3790ea982f7408cbf5a206754fd16a784c451d92a876ac1e5dcce28f261ee6")
