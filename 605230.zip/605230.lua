-- Lua provided by SkyAPI 
-- Game: Grey Hack
addappid(605230)
addappid(605231, 1, "f8ce15232e8c5ded9644310c1a9df571c731568b45e089110442ce8ad6d435f5")
