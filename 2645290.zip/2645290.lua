-- Lua provided by SkyAPI 
-- Game: Jusant: Original Soundtrack
addappid(2645290)
addappid(2645291, 1, "65b29d3ee6a2e6ee5be7e3f9656900f8271113f9794d078d3e11da5271cd7623")
addappid(2645292, 1, "aed6dd0410352ccd366c8f4e7cf10fee4a6dbcb879745c7e44749cc178db5532")
