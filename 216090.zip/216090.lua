-- Lua provided by SkyAPI 
-- Game: Go Home Dinosaurs!
addappid(216090)
addappid(216091, 1, "a4bb799ed59acb194fc5993c8f4168f07c6e45bd0653afb0a6f97ebfccb76290")
