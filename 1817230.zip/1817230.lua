-- Lua provided by SkyAPI 
-- Game: Hi-Fi RUSH
addappid(1817230)
addappid(1817231, 1, "0b72efdcb9381949af6d0260210821349bfd5047d33c3ed7e6a62e5fbbc9c816")
addappid(1817232, 1, "1fd310294fa59e457d3df62891cb2a4b9285b3e6a7d97adad3bdbf70106d4e4f")
