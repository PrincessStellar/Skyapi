-- Lua provided by SkyAPI 
-- Game: Omega Warp
addappid(2083320)
addappid(2083321, 1, "7c848c3148e3f0beae00c873e5592a6d357bcd7ca140cc1aa6893cd8d0a5cf37")
addappid(2083322, 1, "74fa1cf986e641f8af3bbae2da7c69bbb99432bc2b4cc7b4f6a51d08256c93f7")
