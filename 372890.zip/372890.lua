-- Lua provided by SkyAPI 
-- Game: Red Crow Mysteries: Legion
addappid(372890)
addappid(372891, 1, "c534bae0f5c70787a9ab657704a54b3642f725f921d23c1e5a54b80b2d310ba8")
