-- Lua provided by SkyAPI 
-- Game: Linea, the Game
addappid(428900)
addappid(428901, 1, "226364d383ec023443db1c8508aab04acc44d4d23f4cbc794a18ff389aa48e2b")
addappid(453330, 0, "9eae251e1603198dc815362841c312e09e7c92d743ede6017d2a3f09ca3d9e11")
