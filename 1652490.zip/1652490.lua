-- Lua provided by SkyAPI 
-- Game: Boxing Club Manager
addappid(1652490)
addappid(1652491, 1, "2aef38eb40275b2c2b1faf920db59d8bf226b068ef3f09aff5b2519d233253fa")
addappid(1652493, 1, "87bce98f5c9fce08ba719adc5f5fbd699bb0be3650d54676c4c572aad91330cb")
