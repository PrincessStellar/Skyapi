-- Lua provided by SkyAPI 
-- Game: DayZ
addappid(221100)
addappid(221101, 1, "9d9c5d3d77309bbe701a3f018cea877d22d07160b4ea2b65bdf261d0dc399c15")
addappid(1151700, 0, "ed6fa275132bd015ad355b4058b0e4af4a79d000c2f912d1e28a19185ef3c1eb")
