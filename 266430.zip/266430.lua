-- Lua provided by SkyAPI 
-- Game: Anarchy Arcade
addappid(266430)
addappid(266431, 1, "3d052e64a9f1c780d40de3395b9b7fbaac5736e3bd38fbc41eb05e00de390ada")
