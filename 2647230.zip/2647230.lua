-- Lua provided by SkyAPI 
-- Game: HoloParade
addappid(2647230)
addappid(2647231, 1, "87cf51dc782ed05a6cd166a2afaeed41b892254357d389acd72164f5f282ae53")
addappid(2647232, 1, "24690152865a2580990f2da29d0e7492f51e964557f38f263184486361cfdd2a")
