-- Lua provided by SkyAPI 
-- Game: Cross Set
addappid(415400)
addappid(415401, 1, "575e2f46e0f218986f98fb02d0f79b8900c31eb68d580e1ad6022926697a6627")
