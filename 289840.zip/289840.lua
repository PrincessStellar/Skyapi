-- Lua provided by SkyAPI 
-- Game: Dracula 3: The Path of the Dragon
addappid(289840)
addappid(289841, 1, "7b4bdd9d1763fa17398231b16bbd222a080aaa8ef30d4af187606681531334fd")
