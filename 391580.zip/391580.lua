-- Lua provided by SkyAPI 
-- Game: Egyptian Senet
addappid(391580)
addappid(391581, 1, "b4661f0154feb738764936044ff55b919658e5b67ec1959050aca96ad52d51e2")
