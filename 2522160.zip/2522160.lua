-- Lua provided by SkyAPI 
-- Game: Rogue Fist
addappid(2522160)
addappid(2522161, 1, "86c6f18e2326032d254e0847ed344e49d280c0e1e813411317c393c6ce2f1e36")
addappid(2522162, 1, "5a3f62c582a07686a930b686913f4394dbbdfa8f476c1fd5edc4cad61a50c2fc")
