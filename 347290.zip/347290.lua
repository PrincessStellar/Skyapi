-- Lua provided by SkyAPI 
-- Game: Rise & Shine
addappid(347290)
addappid(347291, 1, "05fa7cc98f46969041d720e86d6d645426b1c422b92522c23a57a5754c6c3bc8")
