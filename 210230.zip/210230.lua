-- Lua provided by SkyAPI 
-- Game: Nancy Drew®: Tomb of the Lost Queen
addappid(210230)
addappid(210231, 1, "e5ad2c06f848ba64e44d17a18fbaa8019e6a27fd18197cc98a697ea6c963d6e6")
addappid(908340)
