-- Lua provided by SkyAPI 
-- Game: Katy and Bob Way Back Home
addappid(575890)
addappid(575891, 1, "f168a267d3ab3fb0b9cbfe5d1155ad7c0b25012a6abc7d343b33e45c25291687")
