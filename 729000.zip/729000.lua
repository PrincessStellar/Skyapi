-- Lua provided by SkyAPI 
-- Game: Wytchwood
addappid(729000)
addappid(729001, 1, "780040a91bd50436fc7fcf7bffbb8de3340117c553345c76a4c83040d5b07c58")
