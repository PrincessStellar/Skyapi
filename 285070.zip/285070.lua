-- Lua provided by SkyAPI 
-- Game: Between Me and The Night
addappid(285070)
addappid(285071, 1, "51c7c2137ec4a3869c1b34edadbae4c0525bfccee1399de7695ffca4bc8e7e61")
