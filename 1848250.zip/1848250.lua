-- Lua provided by SkyAPI 
-- Game: Dog Adventure
addappid(1848250)
addappid(1848251, 1, "e999ea900b0c8f2f12e8962cdf3310e4b5d28e582a1dac5135cd7bb02adae8dc")
addappid(1848252, 1, "5741304b65d0f64500d74e2d5c9d17e86c8bee8fb6ab1c045a9a44f4872580d1")
