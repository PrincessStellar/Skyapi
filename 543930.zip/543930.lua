-- Lua provided by SkyAPI 
-- Game: Koi Musubi
addappid(543930)
addappid(543931, 1, "afdfa1a3a404d9dc5ff22ae6c781e3bfb8c06df0b66ba8b8248a364f741e0a70")
addappid(605030, 0, "391550f9965e01ff55ea5d44e296c978de8ed585068a22e7362722feb641ca5b")
