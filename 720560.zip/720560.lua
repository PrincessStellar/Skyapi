-- Lua provided by SkyAPI 
-- Game: Vigil: The Longest Night
addappid(720560)
addappid(720561, 1, "63f6f8caa8cd806884a8e248f609efbe4da76971b0456368525d4ad2d82bca68")
addappid(1415310, 0, "9248fa192f26c2cc91c730603e272a70497e9b2e7896a15aa5037e130763d650")
addappid(1425910)
addappid(1448680, 0, "aac111f0b90583508b344dc179b3c620b5293b376cfa38fd12affa3bf6643085")
