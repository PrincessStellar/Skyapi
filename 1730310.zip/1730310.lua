-- Lua provided by SkyAPI 
-- Game: The Lonely Helmet
addappid(1730310)
addappid(1730311, 1, "1888c330be4c20376bb89e83cbafda963e086b90d5812634bef0fde953afbbd4")
addappid(1730312, 1, "7180a2b6687e4fae2926bc3ceebfab8e9e5d26cc6931d6313c67763bfa5f0825")
