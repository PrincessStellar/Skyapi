-- Lua provided by SkyAPI 
-- Game: B-17 Flying Fortress: World War II Bombers in Action
addappid(1634450)
addappid(1634451, 1, "9033e79a66bf502baefb0857a5a34791ed3233d2db730ccdd1c38ad1411fc2ec")
addappid(1634452, 1, "f6dd3779bafffb83f1c4e629f7feba180dcc7c3e449cd5b931af210caeae3427")
addappid(1634453, 1, "5848c4ee7db2e1de10750ef390edbcf4c1a3889a38a02755c90b3f246449ea31")
