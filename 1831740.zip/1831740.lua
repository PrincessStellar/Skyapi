-- Lua provided by SkyAPI 
-- Game: December 24th
addappid(1831740)
addappid(1831741, 1, "7536cd4bf0c0916892670a9a72b7268ad38a95454189bf97fc00b939eee07858")
addappid(1831742, 1, "ec53dfc7b4df4a708cee9916145fbfdb3c56e44ae926e6fa13020b5a3165eca6")
