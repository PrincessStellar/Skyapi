-- Lua provided by SkyAPI 
-- Game: Shadowrun Returns
addappid(234650)
addappid(234651, 1, "009ac25728262c38d88343e270143bae2eb10c6fc7cac6739e57509c225baaa0")
addappid(237810, 0, "2be072853dc376ccca52ab324f70c115dabc11c24f5fb8b2c51c579801e09fef")
addappid(272030, 0, "c829d0a69e60564753ba384c4f24c821c42d19e932c09e33b780e9ca1edb145b")
addappid(272031)
addappid(272032)
