-- Lua provided by SkyAPI 
-- Game: AppID 200910
addappid(200910)
addappid(200911, 1, "c8dee7bdf21c4d51c7924831c71e6a971429f5036c3190ab8d1c4f97283565de")
