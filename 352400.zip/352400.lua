-- Lua provided by SkyAPI 
-- Game: LEGO® Jurassic World
addappid(352400)
addappid(352401, 1, "8f90accf2ae69d17b8af3f20d03010a81298e10cabe5a506afeacf7a96f6464e")
addappid(367870, 0, "2dbcde1124451c5ceb31876a703e4d8ff4eae855a849c257e61e236005cd609e")
addappid(367871, 0, "be5df76c98427f835656cdde0dea25d59e180145be23095ddc73105019f46efe")
addappid(367872, 0, "6a07538a35eb9272b45a3ad970382c79b139b8cc084baa4cca7918c2ebca3184")
