-- Lua provided by SkyAPI 
-- Game: Dominating eyes
addappid(2505740)
addappid(2505741, 1, "b5142cc43b1c212e5be08fc2bb864100b9a440bb3abb24d0a77afd85a9587b59")
addappid(2505742, 1, "323813ad3120e7d2a506e073b143c7dc794ab7bd902d95b01bb42fc3a2b82f40")
