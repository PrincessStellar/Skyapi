-- Lua provided by SkyAPI 
-- Game: ALICE VR
addappid(513320)
addappid(513321, 1, "3c7c31560d0f0b9c063745fd8b43f52b080007128f3e1fbd2d0a165dc64bd70a")
addappid(530670, 0, "132b3e5bd84c121045ae8994260f32d9d66f911aaf1d2499fc62a0d417eeecd8")
addappid(530671, 0, "6554cfdea96efdf6f94f3bb7e3b87eba2d7576c057e192efacfa97bffcd8d1ec")
addappid(544620, 0, "108b795eec85d749bc2526e44de0c4de1d954044ab4a5e8a980f0aae6d369eae")
addappid(612870, 0, "3f403cc819ab007621d7eb623f24af5f19e7a6745d1a9f9127c0e77f6b2ded2f")
