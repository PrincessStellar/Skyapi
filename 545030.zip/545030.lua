-- Lua provided by SkyAPI 
-- Game: NSFW ~ Not a Simulator For Working
addappid(545030)
addappid(545031, 1, "0e197b45407b0819953c7c1b283421c1d5e840a6b15fc55a59a8a0a329fb701e")
