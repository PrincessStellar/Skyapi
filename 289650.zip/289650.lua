-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(289650)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(289651,0,"8f869005c44f493f984aa111e49e96c4f64e69a4b4078cbfff77f01ce5bb7b8e")
setManifestid(289651,"2453667985741823211")
addappid(289653,0,"8aa4b40cbc6dc05229d0cdd4f7fc19f1e5b0cebe991d6db3fec2f3ffb906d700")
setManifestid(289653,"6428421478294991249")
addappid(289652,0,"dd7b22e30a71132cc09a5e75b0d8b326d5a0716911cb3b63f6f656fafe0ddad1")
setManifestid(289652,"2679326884158097457")
addappid(324333,0,"9b07cb83c48f76dd01431636c4dcfed721bbf6d70141900658c6ff573ac15d3c")
setManifestid(324333,"4731501881144486504")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
setManifestid(1716751,"3341282173115166582")