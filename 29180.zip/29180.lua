-- Lua provided by SkyAPI 
-- Game: Osmos
addappid(29180)
addappid(29181, 1, "d0c47e8295db1ca538e2428678f22c7f2bc280c1e4490f466f9095ca3c2c4290")
