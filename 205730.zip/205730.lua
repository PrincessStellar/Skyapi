-- Lua provided by SkyAPI 
-- Game: AppID 205730
addappid(205730)
addappid(205731, 1, "27c2d822d03edf37865a1a6af3e37ff4a5a712b45ec29f93157c38e9a07daf8a")
