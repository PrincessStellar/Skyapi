-- Lua provided by SkyAPI 
-- Game: Charrua Soccer - Mirror Edition
addappid(2726240)
addappid(2726241, 1, "948eafd0e723dd96e2a4f5ff91c836a5f2f327de2ec92dd37c2cedc01df38472")
addappid(2726242, 1, "0689fb56c03fd5829a21ee35e1d0830b9c3bf6f33dccbbf21cadafc1ac8e7636")
addappid(2726243, 1, "42498db7102c73de94b1a5dd77276ed330e9c7e67d7c9aee211f4736e67d3877")
