-- Lua provided by SkyAPI 
-- Game: The Incredible Adventures of Van Helsing II
addappid(272470)
addappid(272471, 1, "02fce8f9d8656c40e5d515dbf9043a3e6758b03f99af415a839557bbce85f221")
addappid(307750, 0, "c1970075d818ccb5d328f49215cb407ba901c6334eaa2fa8e3fb0321812ba054")
