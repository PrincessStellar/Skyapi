-- Lua provided by SkyAPI 
-- Game: AppID 298400
addappid(298400)
addappid(298401, 1, "2c5c7c5aa419c8ef51d3c12230455e7671b760086fb6ea0545961cd2bab8117c")
