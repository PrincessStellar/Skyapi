-- Lua provided by SkyAPI 
-- Game: SpaceInvasion
addappid(2051060)
addappid(2051061, 1, "6bfcdac5b06af9a6f6fbcec8cbb91891523d767176ed924504e73d1e6da484fe")
addappid(2051062, 1, "494a91d15c29e7dd089cd84ff1a985876b4700db9d113ea02bed7a5c9c9b9a6a")
