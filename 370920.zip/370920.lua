-- Lua provided by SkyAPI 
-- Game: AppID 370920
addappid(370920)
addappid(370921, 1, "1e200410137bb6a92532849823148bcec94dead7249d7643e6a1f4bb40e357a9")
addappid(379650, 0, "98a2955e8ed6b1d8961e2dd5cdb56ab1efa75de1e6888f092759c11aa378d7ea")
