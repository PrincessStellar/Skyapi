-- Lua provided by SkyAPI 
-- Game: AppID 334230
addappid(334230)
addappid(334231, 1, "fd70f0b581e55a112ec1bad0c7dd80be2d51d7ef00a9116d2e23008527892d14")
addappid(626470)
addappid(648420, 0, "f14b8455fee151d54b453bf703d357aaf52222c5142a03bdc57ee32ae3c8a12f")
