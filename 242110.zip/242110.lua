-- Lua provided by SkyAPI 
-- Game: Joe Danger 2: The Movie
addappid(242110)
addappid(242111, 1, "c46ff154e673e17af8a00ecc43f2cc22f72732ce66f87392f71488758197aff8")
addappid(242120, 0, "70b432fc13cb3ec47af8ce1d8d975019176e622096a3ac1416068264f4729f8b")
