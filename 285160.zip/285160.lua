-- Lua provided by SkyAPI 
-- Game: LEGO® The Hobbit™
addappid(285160)
addappid(285161, 1, "4135d51d7feab5c9486308c898045892514450bfceffc9cf366b1c37dfceb5ca")
addappid(292710, 0, "97849e45cf4fc1b5f410f52b05fb9184db288e1a4868847b4d87c537a6568e55")
addappid(292711, 0, "c2e5b9a384de141a6d83e35ea0f412275c1248582010345ce3efec5340a7c9aa")
addappid(292712, 0, "4adda7e7d7fec70194b674e56dcfba0ac942bcc63feb57541ff2193e2588df7c")
