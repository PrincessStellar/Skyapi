-- Lua provided by SkyAPI 
-- Game: Rebel Duet
addappid(2676930)
addappid(2676931, 1, "b9a943e9928ea24b4f5d60393a9d674f2659937160af72e8c7339dc11f8bce85")
addappid(2676932, 1, "ebca2fa5e9cd29f0e59441b6b08bae2f9d805faf740908ba064c4814fd936882")
