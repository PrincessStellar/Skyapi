-- Lua provided by SkyAPI 
-- Game: Sid Meier's Starships
addappid(282210)
addappid(282211, 1, "4bc768a4b99952d7c933acf0358b80376fcbe69dc8fe4e46c5c0d7ca78332f9b")
