-- Lua provided by SkyAPI 
-- Game: Cards and Castles 2
addappid(1719390)
addappid(1719391, 1, "6667a1201f9c784814a597e771f71019e8cfe2c12983f7ecc49086810581d15a")
addappid(1719392, 1, "67ac4f582f5d6f7b6c05b2d24a3b58d94aa1f1e984aa6dd65d26158c25228b36")
