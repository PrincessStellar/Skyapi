-- Lua provided by SkyAPI 
-- Game: Minabo - A walk through life
addappid(1822560)
addappid(1822561, 1, "d04010c39a3ec7b129f4a599acd711ecb51637f1b1a6b07e7434860e4197ee29")
addappid(1822562, 1, "0ae8017e6a2356c0dcf96bab234c8f6ae049931b7ffea03c67c20aa04f349431")
