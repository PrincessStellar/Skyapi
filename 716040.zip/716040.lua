-- Lua provided by SkyAPI 
-- Game: AppID 716040
addappid(716040)
addappid(716041, 1, "3f280e7daf598545ff77a0245bfb1882cdbfa49abfcc23f48e1068eeb75f670e")
