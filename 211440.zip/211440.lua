-- Lua provided by SkyAPI 
-- Game: AppID 211440
addappid(211440)
addappid(211441, 1, "29105c9ad5dcb3f3b147de6cebc6f4ff815bf47b77b85f8c464f8b303acdc379")
