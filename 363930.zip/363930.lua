-- Lua provided by SkyAPI 
-- Game: Dead Age
addappid(363930)
addappid(363931, 1, "9c7f6e3c67e3cea7e7154a18ab18667dad632de03006366d9e879e0b7b2140ce")
addappid(1330410, 0, "8f7246bdac676faa81ed17e595c32d9488608a00a379e35123ab2b0cb20162a1")
