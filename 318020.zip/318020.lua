-- Lua provided by SkyAPI 
-- Game: Act of Aggression - Reboot Edition
addappid(318020)
addappid(318021, 1, "7ab6dd8f67baf01fb48b29ac386cd3f4b22475129d3b66fbf64be0db43a3a268")
