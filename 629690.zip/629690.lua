-- Lua provided by SkyAPI 
-- Game: Vaporum
addappid(629690)
addappid(629691, 1, "c88a64cd73358e0a4a483d798af7942666412929f975948c40dbb3d7c1db8707")
