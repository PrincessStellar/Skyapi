-- Lua provided by SkyAPI 
-- Game: Turlock Holmes
addappid(2142160)
addappid(2142161, 1, "356927aad4e2d4e871ad11b0368d47e684624f36b64b7b7c38cf9d98b61d34f9")
addappid(2142162, 1, "64c99e6e11ed0fe901f084eec34c665a946561a6b54706a59bd776891f32e610")
