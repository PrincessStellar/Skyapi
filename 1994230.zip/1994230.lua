-- Lua provided by SkyAPI 
-- Game: Almost Home Now
addappid(1994230)
addappid(1994231, 1, "bfcd8db9d61f90067cdbcb6b85f55f79783d0a376faa6557e8bf9caab1de8302")
addappid(1994232, 1, "d18db78f32f7c3f3308cc910d22f5b1cbfc9d0b1284fa195be3182c84e19d5c0")
