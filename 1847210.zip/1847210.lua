-- Lua provided by SkyAPI 
-- Game: AppID 1847210
addappid(1847210)
addappid(1847211, 1, "d0bc05c9a39a3f820a9535d0400c721feb642bd18450340c5d1fad27e5a545c2")
addappid(1847212, 1, "1ddcf4da0d0ebd89e30a30dd38e0fb636fb20ae7ac5abe20fb62f7649ff986b1")
