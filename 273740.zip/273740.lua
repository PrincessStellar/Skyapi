-- Lua provided by SkyAPI 
-- Game: AppID 273740
addappid(273740)
addappid(273741, 1, "2b206a1a29e83bbe5b891e09d8a210dbb1e264669c8e6dcf4ddfa987b5a45bb6")
