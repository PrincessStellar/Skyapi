-- Lua provided by SkyAPI 
-- Game: AppID 312230
addappid(312230)
addappid(312231, 1, "190d62550b27aa00c59de24334a2d451b6583d59fb8242388f790d867efb8410")
addappid(387080, 0, "054d7c624e7c49677def1d51ecaa88e9ac0aad2b122740fba2dc16ced8d6f8bb")
