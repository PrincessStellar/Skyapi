-- Lua provided by SkyAPI 
-- Game: Dishonored
addappid(205100)
addappid(205101, 1, "42107f3f2d8fde4d980e3de5a3b6a9548497675b97fb5be88e578964c24991ce")
addappid(208570, 0, "d5f8adf6db0731cd395883db60b943cf3c83d2d447084a3111822237c1f56fe4")
addappid(208575, 0, "ccddbb489f2ba68ba8ab5239862de740f6bfe8871f1d6336bc9364cbf012dd4c")
addappid(212890)
addappid(212891)
addappid(212892)
addappid(212893)
addappid(212894, 0, "9db7ad1dd15bd13765ae84a6b4f3a6fb5d6947c4c334781e68f96d244989e52f")
