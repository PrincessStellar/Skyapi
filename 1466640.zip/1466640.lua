-- 1466640's Lua and Manifest Created by Morrenus
-- Road 96
-- Created: September 30, 2025 at 10:34:48 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 2 (1 excluded)

-- MAIN APPLICATION
addappid(1466640) -- Road 96
-- MAIN APP DEPOTS
addappid(1466641, 1, "4002fa24b467f86f7d65fb8a377d33358f83d3b42ebe25cc72332820bafcea85") -- Road 96 Content
setManifestid(1466641, "1278914480800819686", 14940120045)
-- DLCS WITH DEDICATED DEPOTS
-- Road 96 Book Prologue (AppID: 1681090)
addappid(1681090)
addappid(1681090, 1, "e849c920b7bd10b6cd085dd924dcc425c8526ca5adef4f3bcc6d5d76edbc523c") -- Road 96 Book Prologue - Road 96 Book Prologue (1681090) Depot
setManifestid(1681090, "5843759502219600104", 68627708)
-- Road 96 Documentary (AppID: 1782160)
addappid(1782160)
addappid(1782160, 1, "76552fd3f798c97e0f65596b191fff61ae78efa157fff76de8fbb409d322755e") -- Road 96 Documentary - Depot 1782160
setManifestid(1782160, "4289489805529103210", 10084471135)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(2367930) -- Road 96: About a Girl (unreleased)