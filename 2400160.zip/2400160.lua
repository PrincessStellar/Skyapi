-- Lua provided by SkyAPI 
-- Game: Glyphica: Typing Survival
addappid(2400160)
addappid(2400161, 1, "6f7a7948926c54ef401bd49c61a850798da9f1f1ec4ce4bc0f92379aa836327c")
addappid(2400162, 1, "9a57bac04a41c00b46f72813522fe798eb2744a7cac83de34bb1a8dc2ed8aa64")
