-- Lua provided by SkyAPI 
-- Game: Life Can Be Amazing
addappid(1697780)
addappid(1697781, 1, "97133c284400ef56cd2274a942f58c87fea11e452cadcccfc43cef042de8cd60")
addappid(1697782, 1, "11e871a6fc468e5f23b22b5d3318b86f8ed3cd30d3fba10515e52037099f3c57")
