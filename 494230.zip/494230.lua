-- Lua provided by SkyAPI 
-- Game: AppID 494230
addappid(494230)
addappid(494231, 1, "2b2146966b3eeb697d9d356dcde87d07fa85641d2d405618efaf9f452f7bb40f")
addappid(498590, 0, "49ac2a97a7e36f3bf59ea6fb3fc1b4ad6d7425a41247a7fc8520ac523104ac3d")
