-- Lua provided by SkyAPI 
-- Game: Hades II Playtest
addappid(2933700)
addappid(2933701, 1, "9d50bb8e55a8559ca5653d0a86ccf171cda8972323a5e7ec260ee0621c6dfa8b")
addappid(2933703, 1, "124d209bb15dc686ce48f8dbc0a1ccb54f96a95cce319e99a0258e9765c23ef9")
