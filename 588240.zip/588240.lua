-- Lua provided by SkyAPI 
-- Game: Frisky Business
addappid(588240)
addappid(588241, 1, "f80ef8ed2d027e6da76f1f0d60c56e5e1e59a75e84b0912c31d25d67355dbcc5")
