-- Lua provided by SkyAPI 
-- Game: Spirits
addappid(210170)
addappid(210171, 1, "2b3037f49b88b4d368d0c464b0d19b0928cec8b5e12abbf5e40fd1af684a44c0")
