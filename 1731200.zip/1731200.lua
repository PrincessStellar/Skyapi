-- Lua provided by SkyAPI 
-- Game: TRATRITLE
addappid(1731200)
addappid(1731201, 1, "2659a322346ed19b8a915837030ef31d9aa2a89871d3869ce06ef54c6c345edf")
addappid(1731202, 1, "bb4bb26a0951948fb60b19b82f46264365bb4b285ed6ab7dc9a49fa6e1bd215e")
