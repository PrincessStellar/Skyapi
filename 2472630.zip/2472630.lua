-- Lua provided by SkyAPI 
-- Game: Flow State - Max Chill Edition
addappid(2472630)
addappid(2472631, 1, "94793a43ceba5d4d3eb1c09bc400aa9fd61d0b4df0fc4c0d8ca171d887862c35")
addappid(2472632, 1, "57e2057ceaf290cf3ed757852bd47df47ddc032f4f94a3efc0e183fe92bfdc53")
