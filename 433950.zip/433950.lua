-- Lua provided by SkyAPI 
-- Game: Bit Blaster XL
addappid(433950)
addappid(433951, 1, "a481c6f695652788d14e8b14afac69fa5d1144b1f781cb1bfdea29a69cceddf8")
addappid(548700, 0, "80957c0db01a9438481fe456823d25deafc0a9cdbce3a15d76c7da553dc220e0")
