-- Lua provided by SkyAPI 
-- Game: The Murder of Sonic the Hedgehog
addappid(2324650)
addappid(2324651, 1, "9b874b4aa3ead509172b645b3fc5bec06e4f311c8e0e5055906d6e7032324259")
addappid(2324652, 1, "5673bfc56a2dcadbc107d840e20815d5b9a3c4bfacb5af6d81a3a6f044de373a")
