-- Lua provided by SkyAPI 
-- Game: Warhammer 40,000: Dawn of War III
addappid(285190)
addappid(285191, 1, "61cb95500f7f309deee0cf3f496e1aa21591997a0817a79cec79c47a9b6ed6f8")
addappid(607143, 0, "c63b76c63fd6d9fddd163fb5a2dfefc6adbdf2f7bd392eb6348b0112557d4a38")
