-- Lua provided by SkyAPI 
-- Game: AppID 343360
addappid(343360)
addappid(343361, 1, "480289ff44beb3e9d5002736701f1be69771c264c398ff9e47fe1b672de1aac9")
addappid(810290, 0, "9eec4060f4e839811a744194ef146a9b4a1ea8963a36bd2a0dc489dd554d5234")
