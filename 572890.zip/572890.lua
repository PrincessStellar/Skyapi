-- Lua provided by SkyAPI 
-- Game: AppID 572890
addappid(572890)
addappid(572891, 1, "002409a0b848ba2e2d716bfdbcf7a99127727f61c4a6b88532c1f92bcd843d2c")
addappid(1016520, 0, "de3dcdeae5e646c7385bb032c68908235d0a8e15a039fc35cd80c4d363789edd")
