-- Lua provided by SkyAPI 
-- Game: MiniOne Racing
addappid(380000)
addappid(380001, 1, "3c9ef5affb4d6a0aa53837086e1295a389140aec66992bdbea55de39e1fa10db")
