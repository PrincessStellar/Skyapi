-- Lua provided by SkyAPI 
-- Game: Spermination
addappid(363460)
addappid(363461, 1, "0073d98a33b51f498c54fb531772daee2f21e24f4df7693495e075235109133e")
