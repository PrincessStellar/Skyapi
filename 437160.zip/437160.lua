-- Lua provided by SkyAPI 
-- Game: AppID 437160
addappid(437160)
addappid(437161, 1, "87b0121ee2578c7a76ee5a3cca55ce9763e43419bb9b7b1aae268f0e6e8eb057")
