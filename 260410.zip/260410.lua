-- Lua provided by SkyAPI 
-- Game: Get Off My Lawn!
addappid(260410)
addappid(260411, 1, "b804bd964aaaf84990e9f825d655c95d973007993e5fe4c3cd6d68fdd1229256")
