-- Lua provided by SkyAPI 
-- Game: AppID 321040
addappid(321040)
addappid(321041, 1, "a8fcf9cb8be847bc7e617384f9a4746c9796ec67bf64e9bbc73fce4a0b84c86d")
