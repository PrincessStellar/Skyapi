-- Lua provided by SkyAPI 
-- Game: License to Breed
addappid(2552100)
addappid(2552101, 1, "b6959139b382dd21b43f853c13207cdc70f6c78bc5e8572837025dbc2443de8c")
addappid(2552102, 1, "95e7025c9a49e28f52855e803c99bfb9fb4a0ba6909884c479def3d771253a91")
