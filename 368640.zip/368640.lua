-- Lua provided by SkyAPI 
-- Game: htoL#NiQ: The Firefly Diary
addappid(368640)
addappid(368641, 1, "3ec9a8f870e0d220f32a59071e1c995b0849989f02f3f1243e297fd3f8c10751")
addappid(535970, 0, "bf59c04cbfae53a205fc5633dfb89f16b194182f51add5a4d0b8dee96241eff5")
