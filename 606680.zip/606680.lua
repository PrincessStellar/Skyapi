-- Lua provided by SkyAPI 
-- Game: Silver
addappid(606680)
addappid(606681, 1, "78de972bfd03082fd9a519c77c2f566c1f7785142d177136c9eb4e85723f7f63")
addappid(647970)
