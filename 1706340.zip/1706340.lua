-- Lua provided by SkyAPI 
-- Game: Big Klondike - Classic Solitaire
addappid(1706340)
addappid(1706341, 1, "892f1c4723c73af74c1d01eef764dc101312cefdaead81db9e3dd91facf8a04a")
addappid(1706342, 1, "14c1c6c3e8e004454f32cb759529accd6c8956d6677389f8d053e7d4a5dd51aa")
addappid(1706343, 1, "bc38f30c678fe660718dd3c5b98580b8772a784edc007c1ea94d43f3acd87e7d")
