-- Lua provided by SkyAPI 
-- Game: AppID 1887330
addappid(1887330)
addappid(1887331, 1, "cf7ca19d27c10adea8c594a0cbad97ceb4c1245496eea8395f2b1c6e34da8fec")
addappid(1887332, 1, "2f7ef355b0a751595c73f19ed37981a1bfb822fd07fcfe101d5bec68845ac152")
addappid(1887333, 1, "40902e074995702b9293f15e7276507bb97c6d06a8b9c84d57c8198e4ada3edb")
