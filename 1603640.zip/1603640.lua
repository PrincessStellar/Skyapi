-- Lua provided by SkyAPI 
-- Game: The House of Da Vinci 3
addappid(1603640)
addappid(1603641, 1, "2a6d947351486fa4fdedbc17d6ca1a5fa2eb9d94e4f4a51f63bf678c8d229257")
addappid(1603642, 1, "317a46fbbc20d9564d8b4d4e0cf2c6bcebe9b192c4241ddc85080bb8d2d3a2b6")
