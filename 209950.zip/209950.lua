-- Lua provided by SkyAPI 
-- Game: AppID 209950
addappid(209950)
addappid(209951, 1, "fa54f6240f27dd18a528eca18afcd5c423d1b760cd51ef7aa4a4ae811c375cb0")
