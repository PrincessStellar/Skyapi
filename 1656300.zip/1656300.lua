-- Lua provided by SkyAPI 
-- Game: Slime VS. Female Hero Party
addappid(1656300)
addappid(1656301, 1, "520c21f0b5f7d23ce7e1270a13046717c62b87c75b44cc7351e7b36a4bc6ea4c")
addappid(1656302, 1, "199e95095591f3a136ecf7b52d18bd2a22d91cbbf67ec9b80d1ffd0324a71b79")
