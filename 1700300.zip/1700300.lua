-- Lua provided by SkyAPI 
-- Game: World Warfare & Economics
addappid(1700300)
addappid(1700301, 1, "9e302ff310351f40c8227c049200a023fa2b77f4a176710df7fe8293fa3857a3")
addappid(1700302, 1, "06f71b02f1f37f36dd084f67026abf8a2d02daae1c26d40df2247b68f1e31a79")
