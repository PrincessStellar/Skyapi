-- Lua provided by SkyAPI 
-- Game: AppID 684680
addappid(684680)
addappid(684681, 1, "39a8617d51c5654ef1f6757c6e7bd210b4d5e01e61e04531cf6dc205d3db8123")
