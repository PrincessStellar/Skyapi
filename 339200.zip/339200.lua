-- Lua provided by SkyAPI 
-- Game: Oceanhorn: Monster of Uncharted Seas
addappid(339200)
addappid(339201, 1, "6f31e2f91386aa771ee8def2025b780b72428388b01c05437468f27710072b34")
