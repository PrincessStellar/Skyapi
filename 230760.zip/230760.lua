-- Lua provided by SkyAPI 
-- Game: DIVO
addappid(230760)
addappid(230761, 1, "5432b2f5b82c54efe873290b43bc4b77ec1ae633c375f5f3c17ec47a3084cff6")
