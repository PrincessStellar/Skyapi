-- Lua provided by SkyAPI 
-- Game: AppID 454900
addappid(454900)
addappid(454901, 1, "0bf31be0c4cdb7e13b33a4cadf90306e0e409e89d928a70ea42c182961672210")
addappid(465530, 0, "ba217c9326c24f9aa7f248186dddb14cb97a940448ce1286c3912b52c17bd607")
