-- Lua provided by SkyAPI 
-- Game: DESOLATIUM: Prologue
addappid(1640540)
addappid(1640541, 1, "bee01425c567fc9a4a449720bc8877e3d23475254ce9f5881763a258e13c7561")
addappid(1640543, 1, "4a5e175c9de1e1f3211cc242f9693961cf1fc787a1b1cf0fe3338672740d7faa")
