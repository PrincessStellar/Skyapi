-- Lua provided by SkyAPI 
-- Game: Hira Hira Hihiru Original Soundtrack
addappid(2804630)
addappid(2804631, 1, "3cbd5b217b7ade08874678acc76ac018f64bc778f2d9ea88460fc2aedd298a1c")
addappid(2804632, 1, "d50ef8a46c3c998e524d214078f5226dcf72231df9ccb8a98d738b683a435621")
