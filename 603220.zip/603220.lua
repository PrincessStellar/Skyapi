-- Lua provided by SkyAPI 
-- Game: ROTii
addappid(603220)
addappid(603221, 1, "6dd7c6c08cc7316a5d5af31c42604133a0351216bf3482e31ecf8ab7bcfe52b7")
addappid(604480)
