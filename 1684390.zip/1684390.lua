-- Lua provided by SkyAPI 
-- Game: FAR: Changing Tides Official Soundtrack
addappid(1684390)
addappid(1684391, 1, "c2c4d6f0f81a1869a8dede43ff5a1ffa82fe28931181b5817eb4ec07825ca17b")
addappid(1684393, 1, "38f7a377799bef388545a8bf0244cd5096058e44bc691c669bb0c8bc887c1757")
addappid(1684395, 1, "0a2f128f6f644c26e52581da1db0f83c7deca433bc12fbf019fa042c09207114")
