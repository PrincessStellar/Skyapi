-- Lua provided by SkyAPI 
-- Game: Ittle Dew
addappid(241320)
addappid(241321, 1, "da642b6d5dfd89e55f668a09298f3cd8a6cc987dd083390a0a1a26fd0f95e664")
