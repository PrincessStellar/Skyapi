-- Lua provided by SkyAPI 
-- Game: iTop Screen Recorder for Steam
addappid(1611360)
addappid(1611361, 1, "731436cedc976e3c180cbd894554d1d3299ff90637874cdb97122a16564af6a7")
addappid(1611362, 1, "b660d2f3ab42c2a172c61bc43892ff5304311ce3e417298c8a7b834e3881cf7e")
addappid(1621510)
