-- Lua provided by SkyAPI 
-- Game: Peggle™ Nights
addappid(3540)
addappid(3541, 1, "1bd8c41e16d4706b60d57a2728fdb4736c28571510b62f7c71ac902786fa0460")
