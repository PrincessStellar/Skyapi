-- Lua provided by SkyAPI 
-- Game: Half-Life 2: Episode Two
addappid(420)
addappid(421, 1, "5afe8a6d938c98a0e2d90a41456af70491194fc5f6b5260a6f3bed29373c7429")
addappid(323160)
