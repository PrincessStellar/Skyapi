-- Lua provided by SkyAPI 
-- Game: Day of the Tentacle Remastered
addappid(388210)
addappid(388211, 1, "5d7d18fd5916bddba2e9340b05c731f4b0f33de544c10fb6bd189e4818a5338d")
