-- Lua provided by SkyAPI 
-- Game: AppID 1730080
addappid(1730080)
addappid(1730081, 1, "2e76d7a2039889adee6effc2fed6882b5f3e83c8fc010d2dc81ddf3811b266f0")
addappid(1730082, 1, "52e0f7427550880d8b7b982f9f8fc3b7ea0a68ac980114225533b4fe3a0cd1a4")
