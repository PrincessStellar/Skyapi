-- Lua provided by SkyAPI 
-- Game: Mouthwashing
addappid(2475490)
addappid(2475491, 1, "397ceaf971a43c7d35d5eade1443d05df02019c433895547be26e88b177d948d")
addappid(4014000, 0, "eea7cb7344358df39b32d8f36167a652b13d54ef88ff0f16ddaba2c2ff3f30a9")
