-- Lua provided by SkyAPI 
-- Game: FOTONICA
addappid(253290)
addappid(253291, 1, "a314613da8ab1d3b72b14f2d9d5f28845fd3bd8a475c634a2dec2afd1facf5b8")
