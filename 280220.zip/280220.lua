-- Lua provided by SkyAPI 
-- Game: Creeper World 3: Arc Eternal
addappid(280220)
addappid(280221, 1, "fb7df66a56f70ba2b2ede78d3ab0081dd9b61103066c8cacc91c084943b70d0b")
