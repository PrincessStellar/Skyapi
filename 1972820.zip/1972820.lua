-- Lua provided by SkyAPI 
-- Game: Suicide Guy Deluxe Plus
addappid(1972820)
addappid(1972821, 1, "f50f15a0524c07af487d549b7faf4149207d0e9840b7d01b66c3178e3ee1f434")
addappid(1972822, 1, "55c19ecae09644af5e2b1474a0792921ad3fdc58be4a4056a66cb9910438675f")
addappid(1972823, 1, "d3434c1c36485ea620f97460da0efd769c55867313f9bf0d1eada4f0dc543012")
