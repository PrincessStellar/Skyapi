-- Lua provided by SkyAPI 
-- Game: Who Pressed Mute on Uncle Marcus?
addappid(1628130)
addappid(1628131, 1, "7b425efc82183fc639abf0a9bf1379f1edcf9b9f1631e89afe02206607e09502")
addappid(1628132, 1, "57e49e9ff425fc761522ad4d8f656f5260fdcb07323bef61d4233f65d30e7862")
addappid(1628133, 1, "8fbf8de19fe1778cd73fe6604039f03a32a05e0c05b7ea1ba0c4ff824df9e326")
addappid(1628134, 1, "903f4a20290fb7a637b9dba9d1397e412d383ab9ca71c3813de7fc99403aa406")
