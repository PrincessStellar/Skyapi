-- Lua provided by SkyAPI 
-- Game: AppID 300570
addappid(300570)
addappid(300571, 1, "7fd9b259544dd58716ed8fe72b9d98b204b3040ec1b3369b9594502e97befd4a")
addappid(510350, 0, "9f97709f49bdf8b18e8caddb53d88968d91de8dd59ea9d252ef58d2a4f2ad067")
