-- Lua provided by SkyAPI 
-- Game: 12 is Better Than 6
addappid(410110)
addappid(410111, 1, "1a3d27168d3940fa042064bdf6b2ef270bfda7541717eaa00bc6e6a008ee2e0b")
addappid(450820)
addappid(450830, 0, "31848f9751155309eee3b0e193ba670688f2734ee6e750fcf7e9c1d02c4a0613")
