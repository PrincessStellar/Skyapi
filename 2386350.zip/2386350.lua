-- Lua provided by SkyAPI 
-- Game: Marauder of Dystopia: The weakest go to the wall
addappid(2386350)
addappid(2386351, 1, "74264716fa3d8bb0877b4e4d622f575c66c469fa424c3ca948bc620eabb07627")
addappid(2386352, 1, "20543ecd2040f575df58191883ce6563a441cbe578f7195e392c962de636aac7")
addappid(2386353, 1, "e1fbc82c1364d8d0678d2871437cc9a2c67025a74f4d095a345c6775524a5a7e")
