-- Lua provided by SkyAPI 
-- Game: Agent Team Simulator
addappid(2233980)
addappid(2233981, 1, "2ff11022a019774f3ee7a0e2b6663ee9c5b2689bc129e5d08cefd7235c6f9702")
addappid(2233984, 1, "9038720b467ffccf8e2ba24551c38f3da38e8a0abdab9fd37885355dc7f95903")
