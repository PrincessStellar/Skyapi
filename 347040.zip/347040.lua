-- Lua provided by SkyAPI 
-- Game: Keebles
addappid(347040)
addappid(347041, 1, "053f67edbd819b056ab6a9ce3d4b208bcef6f2e853f74551e2a58135aa8f37b3")
