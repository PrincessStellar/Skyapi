-- Lua provided by SkyAPI 
-- Game: AppID 575630
addappid(575630)
addappid(575631, 1, "35f1f852dc841f498fd8f024b81b8abc7bca62b8a1bd2f7d81d2477960f8d4f6")
