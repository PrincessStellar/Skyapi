-- Lua provided by SkyAPI 
-- Game: Stories of Bethem: Full Moon
addappid(412270)
addappid(412271, 1, "bc650f1ce7191133af3f191954a433c585a56e20588acfdc4e7afa883e95231b")
