-- Lua provided by SkyAPI 
-- Game: Rabbit and Steel Soundtrack
addappid(2984870)
addappid(2984871, 1, "b794d332bb63c9e0f0da3606648dbb2368bceb6c39165ba39d75012f9108e3f9")
addappid(2984872, 1, "524f3f6f37355bca5ec3b8a21d79f76fd6730a2e4e694696ea6400acd57a4d9e")
