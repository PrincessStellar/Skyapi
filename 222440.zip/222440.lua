-- Lua provided by SkyAPI 
-- Game: THE KING OF FIGHTERS 2002 UNLIMITED MATCH
addappid(222440)
addappid(222441, 1, "ecc4bf27f87ee88b4bb037ee5747c78dea710c160d950c9204f19d7e6a8deff6")
