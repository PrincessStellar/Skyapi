-- crimsom desert deluxe edition by skyflare30 [Denuvo required]
addappid(3321460) -- Crimson Desert
addappid(3321461, 1, "e2e570c84eb8b4cfe9c20268cd30b84f8c1c7c076691c92ae8c5ba7b510b8a95") 
addappid(3321462, 1, "6eb3bfe7d16b9eb6441dba4f7d18b341fe83ab2f1e9385d042ce622f38a600cb")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(4024620) -- deluxe pack
addappid(4024630) -- pre order pack