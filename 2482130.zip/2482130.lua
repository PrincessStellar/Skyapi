-- Lua provided by SkyAPI 
-- Game: Final Resistance
addappid(2482130)
addappid(2482131, 1, "11bbf528388ef97757177d072d3e6bc12ca6131c603dff7f475c5cfb73298c60")
addappid(2482133, 1, "0208ecaf6cdb0bd2340ccaa8a74038a201fb21e840f433b334185f87761ddc6e")
