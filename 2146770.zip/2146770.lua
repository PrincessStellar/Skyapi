-- Lua provided by SkyAPI 
-- Game: Deputinization
addappid(2146770)
addappid(2146771, 1, "5a0c71721773bbf179d6c2b749510484e34654d87a5ba5c924fc4dfa0ee915cb")
addappid(2146773, 1, "edbed16d28f7c3f5503d54a7f456e15ea638784c7ef1aeaf0e976299df960ba0")
