-- Lua provided by SkyAPI 
-- Game: Chuck's Challenge 3D 2020
addappid(262590)
addappid(262591, 1, "4484f469178edb25c6f196f5791c778d2194c38611624493fd72be0fae1ebdcf")
addappid(286990, 0, "0faff36e6b87f9fe9f21069a50fb53035a812ad7e01cfb33e047abe6910c4e19")
addappid(286991)
addappid(333700)
addappid(1406190)
