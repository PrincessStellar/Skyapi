-- Lua provided by SkyAPI 
-- Game: Gynophobia
addappid(365020)
addappid(365021, 1, "8628ef468250a32db022b817eb50b2e772f063c3363388979cb057e3b4f58ecf")
