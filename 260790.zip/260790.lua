-- Lua provided by SkyAPI 
-- Game: 1001 Spikes
addappid(260790)
addappid(260791, 1, "63755527e56285d3e7264e05f17a06551854ce0ff1e0fc88ebba1d3e008d1c4c")
