-- Lua provided by SkyAPI 
-- Game: Magenta Horizon Soundtrack
addappid(2455830)
addappid(2455831, 1, "9afbdc98c9b482480f03935edf3c97d568189ad68218b74341c2f41a6e779224")
addappid(2455832, 1, "16443c76636e48117034db8f782f393b362ba17957f7ee3a22e2ff666eff8b65")
