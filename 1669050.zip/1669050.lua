-- Lua provided by SkyAPI 
-- Game: Beastrun
addappid(1669050)
addappid(1669051, 1, "96f516f4187ba7a62736d5593d7430ca5128e03352f5bae2564330c6c942d9fe")
addappid(1669052, 1, "366e93fa692e701d62781e7fc037d4ba84dbfd2cd49046b4fda89b2d8a5413d3")
