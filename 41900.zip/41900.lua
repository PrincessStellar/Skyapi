-- Lua provided by SkyAPI 
-- Game: The Bard's Tale ARPG: Remastered and Resnarkled
addappid(41900)
addappid(41901, 1, "5d71ff231e8ce1a65c17defee4f5876a44dea4ed1e7a0101dc153b2bec274bba")
