-- Lua provided by SkyAPI 
-- Game: AppID 720280
addappid(720280)
addappid(720281, 1, "1c5936138789e03fd0b8c12a1de63a23af402dffd7e432244ac52bec71d795d0")
addappid(778160, 0, "ff58ff6e8b5ce79459be19207cba35cf9fefed3006c72124383d9c20446ed30b")
