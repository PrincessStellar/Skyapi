-- Lua provided by SkyAPI 
-- Game: Roots of Pacha - Soundtrack
addappid(2504760)
addappid(2504761, 1, "a705ef083b343a4b4e9ad7f3f01a343e079b487449cbb2fceb545c0224170f68")
addappid(2504762, 1, "28ecf2571da08bef4429b73e7967cf26804393cc50c5423c7e90330dc5d82f8d")
