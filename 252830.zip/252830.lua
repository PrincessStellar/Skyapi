-- Lua provided by SkyAPI 
-- Game: Claire
addappid(252830)
addappid(252831, 1, "fabf59414795d9e672f1ec401a13126612604cedf672437b5a383488d41a194f")
addappid(326270, 0, "241c03191ecd566a5f6063d9acef4db4bcde099012e2be40c7c5541ef1aae31b")
