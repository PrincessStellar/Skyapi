-- Lua provided by SkyAPI 
-- Game: SEASON: A letter to the future Complete Soundtrack
addappid(2233230)
addappid(2233231, 1, "4bab15febc08802d94881dbbdc8d1ea7a473554e82d61773544636ccee61962e")
addappid(2233232, 1, "d4ac08b1750a3131773d660759ea687d797d67b8c35c917aabdfe1531fd1b22f")
