-- Lua provided by SkyAPI 
-- Game: AppID 2355220
addappid(2355220)
addappid(2355221, 1, "41323147cc2e496af9bb7f22f8d24c1bd315106b53bbadc3ce06ccc22738720c")
addappid(2355222, 1, "527f9b014ff92aabbc381478f7806db9721f3e01f082ec694b631cd0727ef6bc")
