-- Lua provided by SkyAPI 
-- Game: AppID 2186380
addappid(2186380)
addappid(2186381, 1, "e194dd0fd41dad448e57209e5ba4f5d1daa660cd7e49113c232252cfac71cde5")
addappid(2186382, 1, "22b88bcc20d98884cb5083a513bd90c35c6ced0a7d94b6d0c39ad5e006d9b38d")
addappid(2186383, 1, "ad6e027cfdd902254e86574720d9287f6eae5ee3bf4f90b0081cff5a29c0352b")
