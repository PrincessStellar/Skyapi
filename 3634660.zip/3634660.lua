-- Lua provided by SkyAPI 
-- Game: TyranoStudio Visual Novel Scripting
addappid(3634660)
addappid(3634661, 1, "4c737380646e142278822f1b764e5bcfb45a42a0c4a7f512b6461b72c7fca85a")
addappid(3634662, 1, "a23b2936cb38e222e2d7a9fb9b37e7a8fa70c3f1c1fb43ca8efda1868984ca2c")
addappid(3634663, 1, "5e965e6b7081cf71ebfabc28bc9b4388fca54f0b5d6413c559a41726bfb70c2c")
addappid(3634664, 1, "da1027f542e1242eb2264ae536fe5b6dcbaf2709d22fda8a1d9add95182fbfb2")
