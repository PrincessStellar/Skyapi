-- Lua provided by SkyAPI 
-- Game: Kemopop! Soundtrack
addappid(3136200)
addappid(3136201, 1, "9d99038dc415c46a0b6cfba4f39da72e1fcf7c5ab7feee57c317eccfb1397271")
addappid(3136202, 1, "014664a611fa7da95e2cc1d55d6520e167861500574e3d1b2b3c87e0f029984e")
