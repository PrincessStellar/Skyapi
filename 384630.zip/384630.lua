-- Lua provided by SkyAPI 
-- Game: Aviary Attorney
addappid(384630)
addappid(384631, 1, "48740732b2803309658791f97d1dab25ef34bee5de73f474eaa8ed6f6bb9b86f")
addappid(427650, 0, "49bf688970d693172086aa103c3983953429b8b656f883aef7498a529723797d")
