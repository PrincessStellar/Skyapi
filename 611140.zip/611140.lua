-- Lua provided by SkyAPI 
-- Game: Dark Passenger
addappid(611140)
addappid(611141, 1, "62f744182169e4b1c946d78bc8ebd2c6cc04a3d4fb5a4cdbb9defbf6ccb23718")
addappid(642640, 0, "e8d292a380404fdc1a5b8ea5c84829cf4fc58e7a4fb4050eac29485fe22e32e5")
