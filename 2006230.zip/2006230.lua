-- Lua provided by SkyAPI 
-- Game: Chevalier Historie Append
addappid(2006230)
addappid(2006231, 1, "bd583fa8018bdc34525fcb12b20f40203275da027119837fb26e7d19b86fff9d")
addappid(2006232, 1, "d29374b71b4f1fc61b31525f9b9708acc437499375b155bf2f00fcf8f70bacd4")
addappid(2006233, 1, "6b6290e0c38fc879c9f39fad8c39784fdb61967091a4aff524e2a2f10def59ee")
