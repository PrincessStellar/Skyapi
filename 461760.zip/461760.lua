-- Lua provided by SkyAPI 
-- Game: Reptilian Rebellion
addappid(461760)
addappid(461761, 1, "977431d3466b6c7fa490a60cab0a24b62b8393abeb9ed32aced1a096d8a7358d")
