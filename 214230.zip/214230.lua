-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(214230)
addappid(214231,0,"3547ddc3808a205c910928fd8c68cee5f706a67ad7a2a41564a356273863ad8d")
setManifestid(214231,"3600483744922830492")
addappid(214232,0,"4ce2fd7aae28ce77f5f7f18b80cb7ea90baabb8532b6d5373f6e5f6e79efe1cc")
setManifestid(214232,"3942254984108578433")