-- Lua provided by SkyAPI 
-- Game: The Swords of Ditto: Mormo's Curse
addappid(619780)
addappid(619781, 1, "65f53cee46e2bfb7449f06a650af2732f029dc6a508491d0456bca74ec8797b1")
addappid(846860, 0, "141714a2aa6beaf310958f185e3231d76981beb2130d85a9f23c31d56bc9e975")
