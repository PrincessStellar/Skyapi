-- Lua provided by SkyAPI 
-- Game: Final Strike
addappid(357920)
addappid(357921, 1, "eca3db6e7d99575c1b12433f1c8e60aaa7862914e45a46365d10537b18186780")
