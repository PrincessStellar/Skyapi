-- Lua provided by SkyAPI 
-- Game: KILL KNIGHT Original Soundtrack
addappid(3229490)
addappid(3229491, 1, "595069e300a9b0cd7630a8a444ffbbfc61bf9b03431030513d65fa65ce7b94b4")
addappid(3229492, 1, "226e04133bed910140d01e86dbcef5f2083d3ebda0c9e2e768893543f7301414")
