-- Lua provided by SkyAPI 
-- Game: Broke Alchemist Emma's Debt Repayment Plan
addappid(3049980)
addappid(3049981, 1, "07796d7e90630813d11129f1f7c45619400e1faff02dab8341dfa04e5b9c3e2c")
addappid(3049982, 1, "fbe59dc757745431bae5cc2bbefbdaaf047ca7b15eb957af8f8102205482308b")
addappid(3049983, 1, "a699abc4b2505d9f918b7691fb50f268625dbdcb6a01ee9c45c1bed27486fa3c")
