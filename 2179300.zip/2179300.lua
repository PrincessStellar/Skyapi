-- Lua provided by SkyAPI 
-- Game: Blades of Jianghu: Ballad of Wind and Dust
addappid(2179300)
addappid(2179301, 1, "892591c64c3e69becc37b1771700c2a33bcf4adc3ffc6a89b99a8cedfec532b1")
addappid(2179302, 1, "f7af54f68211b6c293dd065b391b067e300e8aeea170c90ba38d5366bfa4abb5")
addappid(2183310, 0, "d74052b4617f0addac9696255cf8e5f928cb37e129c5d7b0f208c35075b5cf81")
addappid(2183311, 0, "24bb3c97d369d0659b3644a5923394ef887029f3a37030aa2ff53bbf6e4c46e4")
addappid(2401190, 0, "1bbf108ee4182858d51bbe8f1ad59e1ecfb5925db681399ce5138ff4a3861316")
