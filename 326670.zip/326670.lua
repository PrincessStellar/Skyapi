-- Lua provided by SkyAPI 
-- Game: Warhammer Quest (Classic)
addappid(326670)
addappid(326671, 1, "e25c61923561c5cccb0dcd3e59962b2a754d2f79b416d637ff055b926f56f509")
