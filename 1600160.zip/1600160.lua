-- Lua provided by SkyAPI 
-- Game: Solitaire Legend of the Pirates 2
addappid(1600160)
addappid(1600161, 1, "fcc94bc8005c514e19549dd339af3975de3d12b3af526014002071dd3bf16f84")
addappid(1600164, 1, "e6cdd96509a7746c7398c39f33c3467de444e5576db82df1ea99adf7ed21ee3d")
