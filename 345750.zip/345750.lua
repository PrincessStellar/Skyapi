-- Lua provided by SkyAPI 
-- Game: Idol Hands
addappid(345750)
addappid(345751, 1, "22386a92fc8a12b3f64f98c77175519cca587a8a94e507e0abc7e393a677de87")
