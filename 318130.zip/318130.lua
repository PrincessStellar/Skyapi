-- Lua provided by SkyAPI 
-- Game: Doom & Destiny
addappid(318130)
addappid(318131, 1, "0ff6fbe8dd768d0ec0a555b41f6d0016bddb9b954c18143ef0a65cfa5831d736")
