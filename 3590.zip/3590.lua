-- Lua provided by SkyAPI 
-- Game: Plants vs. Zombies GOTY Edition
addappid(3590)
addappid(3591, 1, "1625fdac425750d0736c420f3877d3b4b4119d1d361629c2d12b360eb3689839")
