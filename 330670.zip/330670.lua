-- Lua provided by SkyAPI 
-- Game: DiscStorm
addappid(330670)
addappid(330671, 1, "5021c5f499f27359afa1f22b244c2a3873c542218edea150ad9588fb9f918f22")
addappid(374530, 0, "20c1b6e25eb37528b43318243de6d642c7f6ae0767a11b8067ba5dacc8f79bbe")
