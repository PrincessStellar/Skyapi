-- Lua provided by SkyAPI 
-- Game: Rasetsu Fumaden
addappid(1844400)
addappid(1844401, 1, "fd4ad80dd111054aaf6a83307a5c9a351bebc9f6ed76ba73f9fe6ffe87481d9c")
addappid(1844402, 1, "2516ab62a7004002154a50c3902a461dcd35e5352cefa5692498dcc79446c69d")
addappid(1844403, 1, "2c6edec8e606bc91f41489b45b0ff678d236849abea0641f3e565716cf52d83d")
