-- Lua provided by SkyAPI 
-- Game: DJMAX RESPECT V - V EXTENSION III Original Soundtrack
addappid(2164530)
addappid(2164531, 1, "4b6848723cdf8cf1a7b7da508fb42c3aed657876992e3192a6d947a8dd7f515e")
addappid(2164532, 1, "63a3fef2bfc86c8c6079e95ef878d40ba6a19502a00541e327533a731bf5b42c")
