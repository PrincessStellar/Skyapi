-- Lua provided by SkyAPI 
-- Game: AppID 342380
addappid(342380)
addappid(342381, 1, "c5953b93d1408897f575ca929be4e2d6b91e1ddafc68c77f4db69a7a8585b581")
