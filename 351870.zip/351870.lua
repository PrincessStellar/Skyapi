-- Lua provided by SkyAPI 
-- Game: AppID 351870
addappid(351870)
addappid(351871, 1, "29bd950e6ab6c65337ab0d9bb5245ab431a3379016b0c1efcfbdf45c8da9b7c7")
