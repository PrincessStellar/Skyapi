-- Lua provided by SkyAPI 
-- Game: The Stanley Parable
addappid(221910)
addappid(221911, 1, "63a52ac3857a0c6a6a85bfe4af6d84395e79ddf0cc5e38eb1bf45b6932e30999")
