-- Lua provided by SkyAPI 
-- Game: AppID 269310
addappid(269310)
addappid(269311, 1, "2ef32e57ecadeedeb0ae789828c2718f0701cc30216b901a5b3245a60a246aa7")
addappid(707490, 0, "c358a6ba6c05801f20a43d5e14d609cc6973c916458f706154fb3c4e5ba072ae")
