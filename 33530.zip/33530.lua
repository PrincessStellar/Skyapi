-- Lua provided by SkyAPI 
-- Game: Tropico Reloaded
addappid(33530)
addappid(33531, 1, "79dbf5973e0f7c2db109252f74d2add84f1f8fe57692a218dd77503d7ff9845a")
