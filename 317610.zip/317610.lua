-- Lua provided by SkyAPI 
-- Game: AppID 317610
addappid(317610)
addappid(317611, 1, "3888f92d8cddf34c5b1c5f06f0ca2e5a6537d16540ecc2662ceb2c5afae824a2")
addappid(328790, 0, "aa2e475533714732a436bb7a573f23038b59918a9847fd468b83f26effdcc3ba")
