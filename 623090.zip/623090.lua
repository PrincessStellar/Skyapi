-- Lua provided by SkyAPI 
-- Game: AppID 623090
addappid(623090)
addappid(623091, 1, "080be6240c5acefa6d4ec019861c5899112f53fd2c05c103b556cf4d1c713cde")
