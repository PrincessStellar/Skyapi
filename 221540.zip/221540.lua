-- Lua provided by SkyAPI 
-- Game: AppID 221540
addappid(221540)
addappid(221541, 1, "218b2b3b9d874e694e1af2fe5a774b43d43b63dc4589d3ce869e1d0bda927770")
addappid(267190)
addappid(267191)
addappid(315410, 0, "b6c9b9cf4e7bfbfa125320910302e39f873a3d973b08e2b7b6e7a6cd61f07762")
addappid(315411, 0, "cbe9575a280fc0613f1f425ac2c0be361c9b347ffb0c9a8cc827cbc1d754d883")
addappid(315412, 0, "d9e4b2cdb711c3a089e6171de549588facedd1991c1efb1b75c7bc0ac86955bc")
addappid(330540)
addappid(1080920)
