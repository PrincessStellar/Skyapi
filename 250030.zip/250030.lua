-- Lua provided by SkyAPI 
-- Game: Lilly Looking Through
addappid(250030)
addappid(250031, 1, "0f6a7ba736e1167ff8063e268ad891ae12e2784676f7e780443a17d791a6fce3")
