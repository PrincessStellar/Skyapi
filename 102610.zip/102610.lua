-- Lua provided by SkyAPI 
-- Game: Orcs Must Die! Demo
addappid(102610)
addappid(102611, 1, "460b1292c72eacbbb405cdc2ddc7cb43263261cc68d98b2b5d9045d71aa114f8")
