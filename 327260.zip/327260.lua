-- Lua provided by SkyAPI 
-- Game: Super Life of Pixel
addappid(327260)
addappid(327261, 1, "f70084a21e55ccee797e2e305f80c4998e8b4704df5a15252f4936c535514b9e")
addappid(369410)
