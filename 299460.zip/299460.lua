-- Lua provided by SkyAPI 
-- Game: Woodle Tree Adventures
addappid(299460)
addappid(299461, 1, "b06c5999156282cf82600f8b242f9efea5956e2c44c996f76af3bfcbad8fb127")
addappid(450130, 0, "b64aeb1da7c277c7ccbd55313a18cb5c3de770ac55bb8b065c86086bd22e0ad2")
