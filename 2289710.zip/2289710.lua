-- Lua provided by SkyAPI 
-- Game: AppID 2289710
addappid(2289710)
addappid(2289711, 1, "668b602b52fca2cea38319fc50eb03f2ffcd601ce4079920deb2cd272cd3d9ef")
addappid(2289712, 1, "bb2009b6da33cc63b97031742a95a0ad386d980319ddfcd2af6efe3d753f3291")
