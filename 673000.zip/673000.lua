-- Lua provided by SkyAPI 
-- Game: High Hell
addappid(673000)
addappid(673001, 1, "5f60c8e355d39c9d48840d1fd005c999b0b1565422a96d40bab51cac30df2fbf")
addappid(737250, 0, "493a33b0ad081ffb9c0fb6df74b01e4b335ef2ec03578f4a6bcf396f135fe95d")
