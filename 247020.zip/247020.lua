-- Lua provided by SkyAPI 
-- Game: Cook, Serve, Delicious!
addappid(247020)
addappid(247021, 1, "5bc584172120fbc3cbad60429a5970a5a410f5c8b2c7f9e04e2828052c161af0")
