-- Lua provided by SkyAPI 
-- Game: AppID 600370
addappid(600370)
addappid(600371, 1, "80c597b40936f62da545e75c91ecb46f467a1294bc1bd9f6b80f8f9830382c04")
addappid(626180)
