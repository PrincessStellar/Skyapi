-- Lua provided by SkyAPI 
-- Game: Engare
addappid(415170)
addappid(415171, 1, "c2efe33f49d2788af78961a99d50a2899710e23e4fca0ded9a7d155be65f0959")
