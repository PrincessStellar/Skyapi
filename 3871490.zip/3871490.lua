-- Lua provided by SkyAPI 
-- Game: TwelvesShadow SoundTrack
addappid(3871490)
addappid(3871491, 1, "4ecd562ed4a5c81f8a57c3cec210fa509634de3e83d66d39b4cb3cd54069e61d")
addappid(3871492, 1, "4f9a441d28422243364017c81a2e517d004452dc47256d7b851d6539394949df")
