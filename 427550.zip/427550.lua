-- Lua provided by SkyAPI 
-- Game: Tibetan Quest: Beyond the World's End
addappid(427550)
addappid(427551, 1, "032b1d1a7a6e8bfd6d9ac21d7b46a0200fd815ee6727ada3171e5b0e0e36e49e")
