-- Lua provided by SkyAPI 
-- Game: AppID 512790
addappid(512790)
addappid(512791, 1, "7053104246951f3341e356c2bdd1268b74689928bc6f8814a6503891df2b2c53")
