-- Lua provided by SkyAPI 
-- Game: LiEat
addappid(373770)
addappid(373771, 1, "73e94c3a643ec03b55b07d0f77d1dcef1788bf07de180e11c1629bede38dab8d")
