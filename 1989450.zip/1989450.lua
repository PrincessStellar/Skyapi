-- Lua provided by SkyAPI 
-- Game: Public Defense Corp: The Ambassador of Peace
addappid(1989450)
addappid(1989451, 1, "9bb58cb3e2d69569d65d0c190862b37d238ac71df8843d23cc96fd8c92623272")
addappid(1989452, 1, "e2065e50545980ccf2f598678c000f17a936046e48695ff88cb7de288e39f373")
addappid(1989453, 1, "d4d4b25e17bc7009188bc7211e81288efe3836eaca7dbcb9de3c6327e341b507")
