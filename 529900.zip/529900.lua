-- Lua provided by SkyAPI 
-- Game: Polygon Attack
addappid(529900)
addappid(529901, 1, "b61e1e9716474c561d0f09b94d9a4ab8044c4271c845722f0e74089819ab25e9")
addappid(639080, 0, "9655c82bed260bbf27cb5b681f0de6ab22cc0b1705282217b206527a7928f287")
