-- Lua provided by SkyAPI 
-- Game: AppID 245300
addappid(245300)
addappid(245301, 1, "87ea80e4349933db5545ae53cd3e8b10f652f69adbc7c5d60b225d4e367b8ef5")
