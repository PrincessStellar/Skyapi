-- Lua provided by SkyAPI 
-- Game: Letter Quest: Grimm's Journey Remastered
addappid(373970)
addappid(373971, 1, "b68e37dbe1451040dbce4c82c7125460249cfa2823e50056ee9760f42114954b")
