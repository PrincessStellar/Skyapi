-- Lua provided by SkyAPI 
-- Game: Legend of Grimrock
addappid(207170)
addappid(207171, 1, "76d94b4cd3547087fd6c76b09517238f980fef757bdc865f0d8465cc80615866")
