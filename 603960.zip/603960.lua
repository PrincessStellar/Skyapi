-- Lua provided by SkyAPI 
-- Game: Star of Providence
addappid(603960)
addappid(603961, 1, "d080bc7bd6d033e446b44c6d824255672423e854465847fb24f358616c2505da")
