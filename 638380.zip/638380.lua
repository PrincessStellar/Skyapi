-- Lua provided by SkyAPI 
-- Game: AppID 638380
addappid(638380)
addappid(638381, 1, "51c0e4955c2a90e5fa1e1d5c17f4290771ce1a7f88cc90144d2ebe9ba2dc94ca")
