-- Lua provided by SkyAPI 
-- Game: AppID 575950
addappid(575950)
addappid(575951, 1, "2b37d7956867f94a194dd1bbc488179fe19470ef73f3f2c934b35e2c7e10980c")
