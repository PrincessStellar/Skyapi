-- Lua provided by SkyAPI 
-- Game: Cut 2017
addappid(745840)
addappid(745841, 1, "997fa9791b766b168108e8367f1c0042942f9b4980b3fbc619e98ec3c1a52393")
