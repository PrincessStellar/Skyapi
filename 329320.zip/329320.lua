-- Lua provided by SkyAPI 
-- Game: QbQbQb
addappid(329320)
addappid(329321, 1, "9f528d9657a6d4d9b2ec519924f31b2e956bd1c359369d03ac9ad8873d44b306")
