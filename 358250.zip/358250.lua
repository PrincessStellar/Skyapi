-- Lua provided by SkyAPI 
-- Game: AppID 358250
addappid(358250)
addappid(358251, 1, "f7d5319340f5f80899d68b4ad882d1a3425e156cdd30ec304e0aa33a4b0c5795")
