-- Lua provided by SkyAPI 
-- Game: Dungeons of Dredmor
addappid(98800)
addappid(98801, 1, "f2fdd1c79c4fa60e730b17e4d532e7805da7a7c3e4ec1d131f77ff69265651f7")
addappid(98821, 0, "60fc5e86e42d8a00cd81d7fa7deb090af3bc573a3ec14a8016efc207de3e2604")
addappid(98822, 0, "f5c6e6d71bb85078203a7d9f262ff26a124f7f440dd4f2b47269242a9ea7d839")
