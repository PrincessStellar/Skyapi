-- Lua provided by SkyAPI 
-- Game: StarDrive
addappid(220660)
addappid(220661, 1, "73fc18e13bf3f4ff8030fd28db03892d20fba2cbd08b680f048165afe1257c76")
addappid(229013, 0, "75aeb4e30ec2d6234e1ae43959d4859fcc3d68c8559f11456b5012d7a9c6fa72")
