-- Lua provided by SkyAPI 
-- Game: Huntsman: The Orphanage (Halloween Edition)
addappid(246740)
addappid(246741, 1, "ba7445cb314a7da273889bb8058e3349b7565bbc522e0c52e86cc22557d4e14d")
