-- Lua provided by SkyAPI 
-- Game: Idle Clans
addappid(2103530)
addappid(2103531, 1, "0100e83dd88a9b05652e4c328d7e7df46f371d74ff3c84e987a9923262bdc901")
addappid(2103532, 1, "bcf67df6dbbe71f920b6dcb586955db0e0d7479b935ee192dc215dc5b712f6be")
