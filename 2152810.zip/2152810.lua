-- Lua provided by SkyAPI 
-- Game: Forge Industry
addappid(2152810)
addappid(2152811, 1, "068101e185b00b2138183c34d7775540b020a8e7d4718fa4c8c1cdde6842678e")
addappid(2152813, 1, "30309f98fed10dacf9b691c5e4cd3add4451c0b168cfee4c41154529a28bf504")
