-- Lua provided by SkyAPI 
-- Game: Super Dragon Punch Force 3
addappid(2500050)
addappid(2500051, 1, "6bc0dc60f4df88402cf0eead5b8146329c7fe272c68d3d3bcb5e65b45663a318")
addappid(2500052, 1, "393d527a953d985cb5dfaf4cf5cbd1eecd601dae5e3cf77d89214b2043c89e87")
