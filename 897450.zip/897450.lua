-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(897450)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(897451,0,"df0e26a2550f9f01d966469a8644b16bdab4ff313d46eda71b8fdd4c75fbb1bb")
setManifestid(897451,"7890167199684978257")
addappid(1378760,0,"d0db88f4fc0da49bb2a4bb7db3695cec059a5e8cb791fd5b860665e7af0a9473")
setManifestid(1378760,"1440457219443394317")