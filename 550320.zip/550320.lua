-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(550320)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(550321,0,"1adbb6079be99d7bbfa2bb6b8c2c7e446527b5fe5d4595c60bc1827778184715")
setManifestid(550321,"8197696282432093844")
addappid(550322,0,"b717a52a646b68cc50f02c06b3b4a5a2d0105de315d2bc614e98f88d1e6ca85d")
setManifestid(550322,"6939463898595741384")
addappid(550323,0,"37c2957c38798570700f82893fb8769997be89f6c03368e95d70f2029c97033f")
setManifestid(550323,"7263183872078182055")
addappid(1421640,0,"05b2b8e62573a1dfbccc75328d6fa8c5cb53f5fe9b11ba227f1425a5ee6d2a2d")
setManifestid(1421640,"6190583343336093589")