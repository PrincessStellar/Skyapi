-- Lua provided by SkyAPI 
-- Game: INK
addappid(385710)
addappid(385711, 1, "897c48d560ed60ef672ce5c050c0739361f701551d0bb71daad70bf1203a5a65")
addappid(392400, 0, "f5f1995bb4fc15f39a90bedfbd8bf606d637a2faf9a1570aeb5c994a96426301")
