-- Lua provided by SkyAPI 
-- Game: AppID 553640
addappid(553640)
addappid(553641, 1, "c43efb7d162191ffd887e73f2373974c64df411656075028af76deadb0f1dfdc")
