-- Lua provided by SkyAPI 
-- Game: Stranded In Time
addappid(385150)
addappid(385151, 1, "8175de7e28529d805bf7113b0329ddf1fb16dc989b00a8a7f2d86f9c4da3c48b")
