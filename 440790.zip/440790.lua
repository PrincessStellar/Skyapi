-- Lua provided by SkyAPI 
-- Game: AppID 440790
addappid(440790)
addappid(440791, 1, "f3ac1956ab9af7a2ea4b86e8324184d9a14c7a97d341beb20b8dd5f1da94b93b")
