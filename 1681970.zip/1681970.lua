-- Lua provided by SkyAPI 
-- Game: 神都不良探 Underdog Detective
addappid(1681970)
addappid(1681971, 1, "2b1c1ed24f1505af8e7e51e8ebee2247edb3e81ee1b529ffffe29bb3a2d3c2d4")
addappid(1681972, 1, "123acb660b73f6af4d72bdbbdbd9bb9c8e02f811b726e63fd083a22f8e957557")
addappid(1937520)
