-- Lua provided by SkyAPI 
-- Game: AppID 376410
addappid(376410)
addappid(376411, 1, "2a9d017540944b9581852dec1db374cecb751303ea3ccc716231767ccf497436")
addappid(449080, 0, "a6e4597dbf97c04631c612121aad4f09fb508b91cd03e186a4d9cc4959883d5e")
