-- Lua provided by SkyAPI 
-- Game: DARK SOULS™: Prepare To Die™ Edition
addappid(211420)
addappid(211421, 1, "f49080bced75e29fd2910bcd647816b25fb2240e476a5a72da281e8f1f5c0578")
