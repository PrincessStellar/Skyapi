-- Lua provided by SkyAPI 
-- Game: AppID 80310
addappid(80310)
addappid(80311, 1, "4a81d67d9a92e78d13638d071c5e73e2389bcf9257b7d8a0ed3a19b0fc77c16d")
