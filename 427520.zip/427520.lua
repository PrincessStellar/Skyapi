-- Lua provided by SkyAPI 
-- Game: AppID 427520
addappid(427520)
addappid(427521, 1, "313aabe725a369c7112e56db4fb78556f9fe5d8a1e599833000c4b3a29ceb0f4")
addappid(645390)
addappid(645391, 0, "e1e840cb840b8d382a84e6cc0443393d76f99ab19ee8afd3a61a0b414fc5ac9f")
addappid(645392, 0, "a7b9074d3a2634bc9163847fe1ae9cfb0ad55a286a6c32b67289f2a07e2e654f")
addappid(645393, 0, "df5808d5e8ae3a9cce0454d6f6968c6f200e4d28a4cd2a4ba4f8be1426ad7ff4")
