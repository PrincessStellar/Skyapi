-- Lua provided by SkyAPI 
-- Game: Minako: Beloved Wife in the Countryside
addappid(2820940)
addappid(2820941, 1, "b50319b5257a61195dd6086e555ebf1db8ab2f8031304628026eba45711e3b83")
addappid(2820942, 1, "a0e809976a203875a5d259cf369ab549cb281cd08317c152c7b81576b838222c")
addappid(2820943, 1, "73c5fe2e8b8e6d3c6123d74c7690e1843ca6f8afe9f5bdd5629e64a9f27944bc")
addappid(2820944, 1, "dfaf5f3cb626eb60d9249e1d8596470ab4f15c2f7a7dd0a1c094cdfade97ad0f")
