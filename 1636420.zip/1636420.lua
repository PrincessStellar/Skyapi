-- Lua provided by SkyAPI 
-- Game: Sweet Shine
addappid(1636420)
addappid(1636421, 1, "81a8bba71c987f1000aa4414a338f5d70827480c0bccebb8b4db724ad044247e")
addappid(1636422, 1, "549689f5f3327673e0c3501e2762327db0b8ba976eea5b673dbd7e561ddd24b5")
addappid(1636423, 1, "738dca3e6b9d96119e4de05694f1c5ef97e50cc0e84bac4d448ac3791c3f3b0a")
