-- Lua provided by SkyAPI 
-- Game: Re-Loaded
addappid(2395450)
addappid(2395451, 1, "a98b479d37e328485ad5991b21fb63f30f24f867533ac8a962652e1a96994161")
addappid(2395457, 1, "7bf5e1fa91c52854ae0d430c0042bcc5930093b31641fde5b19378fdcb0fde2e")
