-- Lua provided by SkyAPI 
-- Game: LOK Digital
addappid(2207440)
addappid(2207441, 1, "e171b3127fe1a0ed8eb58a70c0009d464410f14da0a923de00b339455bd5b2dd")
addappid(2207442, 1, "8efd17cfb99e7738d48c573d1db14f95e557659e5e8b2427b271bd9acab453b9")
