-- Lua provided by SkyAPI 
-- Game: AppID 533950
addappid(533950)
addappid(533951, 1, "9ea5dea7502557ef71acadeaebaf7a2754e2188b9ca1ca331c72fab899b1a1a8")
addappid(556100)
addappid(598290, 0, "52cf9a437a7887a4c640c3ba30592eb0140a46140981c34a92912dda99d4aec8")
addappid(803950)
