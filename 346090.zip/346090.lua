-- Lua provided by SkyAPI 
-- Game: AppID 346090
addappid(346090)
addappid(346091, 1, "0819336c2b71aee8e25f07c9349ca13edb9c6861c874763d2dc59d3f663417b2")
addappid(395450, 0, "e6a0d799de26a7debe4ea288e4540ebde152a3ca1926277390a066ece0dfdccb")
