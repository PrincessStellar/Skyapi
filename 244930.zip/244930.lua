-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(244930)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(244932,0,"c2b7ba04b844b1b17e43e54b12e41fe26dbb58e5395efa4c00f331c19d6ee960")
setManifestid(244932,"8252072277213176985")
addappid(244931,0,"68a04c41820256641aab2e2ece89e9fe85ed5f29e8b74bbc8f08184c129d98d8")
setManifestid(244931,"6633547932201161198")
addappid(244934,0,"9119fb228785f766c6b25164f6be06426452e82b8f4ce42f8f3d9efa32728747")
setManifestid(244934,"3177227709443963649")
addappid(244935,0,"07c1aee91ec03ceb4db622bcd90243ae899b141a3075296a40a82f1bb497d3a7")
setManifestid(244935,"4068944397068568551")