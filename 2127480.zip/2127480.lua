-- Lua provided by SkyAPI 
-- Game: Shovel Knight Dig Soundtrack
addappid(2127480)
addappid(2127481, 1, "e8b95bd461c04a3e5f5fc25495075e1fcaf1f822bd0f5a7a14d05c01a9181e54")
addappid(2127482, 1, "62892b38e112859980e8b7392fd4ea6c4b5b48396827446a299455936b706980")
