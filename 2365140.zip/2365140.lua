-- Lua provided by SkyAPI 
-- Game: The Artist
addappid(2365140)
addappid(2365141, 1, "09fa0f7133a916c20fcb5c480dc744ef3000848d520e716f4eb729c7a2926795")
addappid(2365142, 1, "0d2e043218daa73b5ae4c8ea2ed6cf306ef1034d10d281b456af0243ffb136a9")
addappid(2496490)
