-- Lua provided by SkyAPI 
-- Game: AppID 434300
addappid(434300)
addappid(434301, 1, "b30a75a036b71e53b7c01de6804439fdb3f27ba2e8a468e696a6cfbe9cc2a631")
