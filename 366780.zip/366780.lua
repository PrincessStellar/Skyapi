-- Lua provided by SkyAPI 
-- Game: Magical Eyes - Red is for Anguish
addappid(366780)
addappid(366781, 1, "72517077716776f80768653182d9b3419f43c1d386a1fa6174060dc64726e627")
