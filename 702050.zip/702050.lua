-- Lua provided by SkyAPI 
-- Game: AppID 702050
addappid(702050)
addappid(702051, 1, "50e945a3ff5eb1c7d9767adb0480a08691bcd99c89d4f0c1a6a242eaba7830b3")
