-- Lua provided by SkyAPI 
-- Game: UBERMOSH:BLACK
addappid(444940)
addappid(444941, 1, "b823d73a2bd753aad374c088917088c5dde7af9288af0f5531b7a47a600fceaa")
