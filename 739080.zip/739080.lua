-- Lua provided by SkyAPI 
-- Game: 9 Monkeys of Shaolin
addappid(739080)
addappid(739081, 1, "aa1b588da2ee859a1e530435c7a206d0796edeea69790d1b8fc20f907b51b852")
addappid(1426920, 0, "edab9c31af39bd300990e325da324c74004919288d0237d674384a04aa7b3d87")
addappid(1426921, 0, "f39853ffc4f96854986733d5cecb93c67d37c209c9bb818f371d042a2a4b309c")
