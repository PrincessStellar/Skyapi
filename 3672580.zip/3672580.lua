-- Lua provided by SkyAPI 
-- Game: AppID 3672580
addappid(3672580)
addappid(3672581, 1, "f4e65177007b97ce2529cc10fac85626b3634f4c093b52e919fd7b55845456c6")
addappid(3672582, 1, "c2748ec64bdaef2bc4f15eb51279b9299aad4a1849c74af802516ee7887ff72e")
