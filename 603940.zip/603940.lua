-- Lua provided by SkyAPI 
-- Game: Pixel Shopkeeper
addappid(603940)
addappid(603941, 1, "8332f3bae35238872467c1f8b766a01a5f0c7d183c632105e798c56d479cc119")
