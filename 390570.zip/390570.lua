-- Lua provided by SkyAPI 
-- Game: AppID 390570
addappid(390570)
addappid(390571, 1, "286d8cb6a5d132ea759f4faa3d50d66ce4d8016b68906bb390730cc444bf4ae4")
addappid(394400, 0, "dceeba6f7fe4e9cffa7a89b3ed7a0da5cb7ef3855ecd11fe6ca9e4b8ba640ab7")
