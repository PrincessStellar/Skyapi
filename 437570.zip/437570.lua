-- Lua provided by SkyAPI 
-- Game: AppID 437570
addappid(437570)
addappid(437571, 1, "74289b7f9336ad3a455a221cf3715e45aa22d3e8b7c4b2f6cbb98fa5b60f96fd")
