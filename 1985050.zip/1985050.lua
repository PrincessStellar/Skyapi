-- Lua provided by SkyAPI 
-- Game: Field of Glory: Kingdoms
addappid(1985050)
addappid(1985051, 1, "4163d53617fe646682ace0eb1ac032be866bb8d07f085dedf4c6ab912dab10b9")
addappid(1985052, 1, "2eebd9c2c00f0e7e9ce888badfadd23ebbb9b8d9fa9e67c95cf01156c7abf121")
