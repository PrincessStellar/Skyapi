-- Lua provided by SkyAPI 
-- Game: Automation - The Car Company Tycoon Game
addappid(293760)
addappid(293761, 1, "fb8222a3b3e27287488f679bac5fcfad63a0e0788aba25dc92daef1b8bcc8a20")
addappid(350690)
addappid(359180, 0, "ed26582ba2f857a7988fddd419b3349a3ea2c59cea1259d7f6d52383e1fd9252")
