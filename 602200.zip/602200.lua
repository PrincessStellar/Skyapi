-- Lua provided by SkyAPI 
-- Game: AppID 602200
addappid(602200)
addappid(602201, 1, "29b22b7eee675d455b839ff837188b115a59a2751870327592a712f7b4a5840e")
