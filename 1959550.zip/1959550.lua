-- Lua provided by SkyAPI 
-- Game: CUSTOM ORDER MAID 3D2 × NEKO WORKS: NEKOPARA - Taiyou Paradise Dance
addappid(1959550)
addappid(1959551, 1, "bfc0e7f84ad17f4ef37c809dabfd406854d80e75c3ed63175dc0c3e16c413656")
addappid(1959552, 1, "9f8fefd7022b692a9d4fa797360ee1f795180ceedd74157ad02ab046592a3b4c")
