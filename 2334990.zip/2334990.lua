-- Lua provided by SkyAPI 
-- Game: Green New Deal Simulator
addappid(2334990)
addappid(2334991, 1, "039f7b311df2db4ffc845923a9e49d9370d249ee9bcebf74166981c31e3ba888")
addappid(2334992, 1, "8ea80c60ce5018d7038606aa5fcae33c8236ad1a125d1f8cdcc78f453a063995")
