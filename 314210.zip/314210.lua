-- Lua provided by SkyAPI 
-- Game: Tesla Breaks the World!
addappid(314210)
addappid(314211, 1, "8d2a13c6174f6a8f36aecc44c148a47cd806074f91483691ac5ab71b1c30b66f")
addappid(334990, 0, "2cc64cb935add5f61a2cd65f57d7bdee110596b0aa121749b53d4cbbce39ef5d")
