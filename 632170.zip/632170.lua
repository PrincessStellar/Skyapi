-- Lua provided by SkyAPI 
-- Game: AppID 632170
addappid(632170)
addappid(632171, 1, "1b9482f8418efffaeea95321d3ba1a3da3209fac031e1b984aae4929b7329342")
addappid(726370, 0, "786f2af43cbf760173cd6bbc3a2b11444f48c5053dd66fc0081427e269ad77b9")
