-- Lua provided by SkyAPI 
-- Game: Witch Amelia
addappid(2081420)
addappid(2081421, 1, "7c7d55031d861501d73b3f39e84a8cbf9075409cf2294fbde672c47c28a23139")
addappid(2081423, 1, "d8c504015eac1d405809e9511c9e58e83c56c7ae1cfdb27b4cf236911df1789c")
