-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2460900)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2460901,0,"debfd07445a9b103c6bd2caa947ea9254b689cebbd8e24832eb8cba849d1b9ed")
setManifestid(2460901,"8037916335492789338")