-- Configura��o gerada por Onekey para AppID 1551360

addappid(1551360, 1, "None") -- Adiciona o AppID principal

-- Configura��o para Depot ID 1551361
addappid(1551361, 1, "13b42353469d4bb26905e2c12e73d4cd63ad89c21f438b3cf5b4b9a9bb659227")
setManifestid(1551361,"7664687112047859092") -- Bloqueia para o manifesto mais recente: 7664687112047859092 
-- Configura��o para Depot ID 1613280
addappid(1613280, 1, "1cc274dec87bdc5651311f72c4c162f4067eafba2d8fb98cac6e3be307f5948a")
setManifestid(1613280,"1076978755699820847") -- Bloqueia para o manifesto mais recente: 1076978755699820847

-- Configura��o para Depot ID 1613281
addappid(1613281, 1, "d371f628205489a48d2888a29f596b335963d189f3e822ec32978292e989483a")
setManifestid(1613281,"8702078743692499086") -- Bloqueia para o manifesto mais recente: 8702078743692499086
