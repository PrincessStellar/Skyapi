-- Lua provided by SkyAPI 
-- Game: AppID 301910
addappid(301910)
addappid(301911, 1, "33e5e82540f1c1e20249a0e8e38f334a1439f8b3f52c1e4a5d729cdce62a83e6")
