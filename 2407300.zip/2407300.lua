-- Lua provided by SkyAPI 
-- Game: Asteroids ++
addappid(2407300)
addappid(2407301, 1, "78a9b3d572dbb1d09574e56e0bd0107226e9f7f2cb2aa85874aa4783acc20c6b")
addappid(2407302, 1, "9e33b732081e63761337e8e2a6d19e9eca715c2a9d3cf2f2eabe01254de47787")
