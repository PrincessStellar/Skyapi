-- Lua provided by SkyAPI 
-- Game: Melissa K. and the Heart of Gold Collector's Edition
addappid(321150)
addappid(321151, 1, "68d24729f247e1725c651e903372e5252efb1a09b93d3dde5f65587db2e3bf72")
