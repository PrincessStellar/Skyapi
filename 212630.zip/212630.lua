-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(212630)
addappid(212631,0,"c43bec7fffe8fe518d4671a68ab7c973971699ba8ac2f4cc955a56d8bbfa1bad")
setManifestid(212631,"5952855941513904570")
addappid(212671,0,"64508cb46acbbebdcf6f4fcff14bd65813fc24dfb82325a810c301442d8f7d59")
setManifestid(212671,"1266992249386689046")
addappid(212672,0,"29c92834e0ba13a45a6d9026111ba68d9ed4f8909abf6b97a168764eeb1dcbf7")
setManifestid(212672,"343729444442703002")
addappid(212673,0,"e96d99dc3bc90b22cbea5e3fd1a9d25e8dc675282f8b995204575bf5bdc568de")
setManifestid(212673,"6264598334958646457")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
setManifestid(1716751,"3341282173115166582")