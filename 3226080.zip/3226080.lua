-- Lua provided by SkyAPI 
-- Game: Tiny Glade Soundtrack
addappid(3226080)
addappid(3226081, 1, "2375ec4e71066e6fe59299ff72cbe7c9ef9e20c400869a12471a32bbe1745925")
addappid(3226082, 1, "5d1352f1b768186c33afa9a6904d74dd96bdd6e28f3564061dd59a3c3be9734a")
