-- Lua provided by SkyAPI 
-- Game: Astral Shipwright
addappid(1728180)
addappid(1728181, 1, "60e8b61df5784ffef313fa3d0f8519071398e471aa65e372272b72b3a7cf45bd")
addappid(1728182, 1, "e194b7a575531e8aa205b62845e80dc82c0836880ec064c12609a3dfb56f6424")
