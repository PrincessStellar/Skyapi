-- Lua provided by SkyAPI 
-- Game: ArcaniA
addappid(39690)
addappid(39691, 1, "0017f440e275cbff33c5b3b72e4d23c715231b31297b2aa4e3ab9f8c6fce357b")
