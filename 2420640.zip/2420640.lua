-- Lua provided by SkyAPI 
-- Game: Angel Tear: Goddess Betrayed
addappid(2420640)
addappid(2420641, 1, "de3deb7b7b097b0f8a05567fc103947f985f07b22ed8c07103a61bd5f84f2caf")
addappid(2420642, 1, "e2d34ffeb8dcc0779f80678c28683fae6c39127e6edb8bf8c55f99af6d350937")
addappid(2420643, 1, "c481f9636cdfc8a39144c67bad996ebf520fe301355147e923d5aa0cb7a003e2")
