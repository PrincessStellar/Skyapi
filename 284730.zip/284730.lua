-- Lua provided by SkyAPI 
-- Game: Dark Arcana: The Carnival
addappid(284730)
addappid(284731, 1, "ebce26abd7da9ef6387363dc6bd4de034376732fa18cc499b31bbeac10909f0c")
