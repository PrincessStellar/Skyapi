-- Lua provided by SkyAPI 
-- Game: AppID 339250
addappid(339250)
addappid(339251, 1, "98f4fef1a0c61c4991db31ce18287711d85d7e140debd5a842905ec6078cf114")
addappid(721880, 0, "cac615daeed12424dcfdaa22a1b8c9e4ef000b11f7e0ece4671320822c1e7a09")
