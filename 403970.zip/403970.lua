-- Lua provided by SkyAPI 
-- Game: The Dwarves
addappid(403970)
addappid(403971, 1, "d9cfcadcc0c06ca497e0924965af1412930b34a757c98739250b4891b11589c2")
addappid(545070, 0, "2a2c46cba0d595ffe6c375bf82836a7e3b1675dbc9cc4a7a0877188bc9ec9011")
