-- Lua provided by SkyAPI 
-- Game: Beholder: Conductor Soundtrack
addappid(3659480)
addappid(3659481, 1, "61cfbb13d30164f2ddf675de307a28f9364f413066c65f7e89d1af74de5a2d59")
addappid(3659482, 1, "c37861920052728584b02f083a1f8561033152d8c3900513f89590fb06d4bde3")
