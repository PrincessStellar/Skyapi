-- Lua provided by SkyAPI 
-- Game: BeatBlasters III
addappid(246800)
addappid(246801, 1, "44cf50c00384f21a86f566233ab2c11e0cebb23a075e1031064909a21e015d75")
