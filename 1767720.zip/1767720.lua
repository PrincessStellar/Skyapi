-- Lua provided by SkyAPI 
-- Game: PixelOver Demo
addappid(1767720)
addappid(1767721, 1, "b333f7a43fa7a1924382b1989c6f512c15d06821b8d47d484feef77ceab10294")
addappid(1767722, 1, "061ddf1d67b01bc79be1555728791caf4f559f0acfc4878435432c62103750a5")
