-- Lua provided by SkyAPI 
-- Game: AppID 599460
addappid(599460)
addappid(599461, 1, "61c232f11f72565e9a55439a648b64acea77751842c57ea761b91bd5237679fb")
