-- Lua provided by SkyAPI 
-- Game: Risky Rescue
addappid(439910)
addappid(439911, 1, "26c11fd7229fac6c6ca5cfda4e559284792ba37b9e55e4bed24fb9c38306ff09")
