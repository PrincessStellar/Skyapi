-- Lua provided by SkyAPI 
-- Game: Detective Gallo
addappid(556060)
addappid(556061, 1, "0065df6d2cdfee24db38d42d3c2c45147ecd33a8bbe3d257e698db346ce28860")
