-- Lua provided by SkyAPI 
-- Game: AppID 403240
addappid(403240)
addappid(403241, 1, "9450def3f4d4837c80969cf4f916915099c49c80c3edacbebbb8c96572a73cd4")
addappid(1123920, 0, "6e595b318ca37cc13710648c00e22386d7c5d385fadef84067f0e22b81b1d468")
