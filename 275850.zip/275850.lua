-- Lua provided by SkyAPI 
-- Game: No Man's Sky
addappid(275850)
addappid(275851, 1, "a5ce5217e5d5d20115ea81209764d4e89f37bed55b84690951d5df23e73852a6")
addappid(3380990)
