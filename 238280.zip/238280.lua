-- Lua provided by SkyAPI 
-- Game: Legend of Dungeon
addappid(238280)
addappid(238281, 1, "4653e69f87ea275f7d4b5babe260f4ddaf9eb948d249939ca861677d9d53018b")
addappid(255240, 0, "fff03c0eced1954cc5a86a829af7b2e145f4928678fe927726bfc6d03c10e385")
