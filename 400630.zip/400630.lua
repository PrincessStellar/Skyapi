-- Lua provided by SkyAPI 
-- Game: Wuppo: Definitive Edition
addappid(400630)
addappid(400631, 1, "2cc748e997524001018f71812a352a56eb88ebef11152dc8a5314db7fabe9caa")
addappid(527020, 0, "8f3eecb3a733a28d7c837e66cf1add7500ce34dd1b5dea6bcd7a953e117b2535")
addappid(527021, 0, "7eddd175701d7ca6516a707f2d8aac27edba181fa15d3961ebc689b7c3020713")
addappid(527022, 0, "618db311666d98b8119c5fea811246ea0f8819bfbdaabc215b8d99dd5dfd7583")
