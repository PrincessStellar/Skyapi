-- Lua provided by SkyAPI 
-- Game: The Guest
addappid(402040)
addappid(402041, 1, "383848f3a0ee7cf8f2ab44ac34cd0b1d47c2d4ce5e921284063ea2408e8787dc")
addappid(464580, 0, "a6e63bf930131719293258b4149b12009aeeba22bd542c1820c71ca95c93cd7a")
