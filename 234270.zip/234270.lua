-- Lua provided by SkyAPI 
-- Game: Ken Follett's The Pillars of the Earth
addappid(234270)
addappid(234271, 1, "8fe88491a4a6c23bcbe1f1547bda40e76595379d43a6a3eea26414f0aa296ac6")
