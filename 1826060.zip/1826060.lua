-- Lua provided by SkyAPI 
-- Game: Night Loops
addappid(1826060)
addappid(1826061, 1, "5c6216e6e7b7b51aa14101258e48a6b94f16f701b1cb47276a767048f2c9517c")
addappid(1826062, 1, "1b0dc3617f519ce20896a30534d411af471bf3d2bc54dee71d17cb23f3b730ac")
