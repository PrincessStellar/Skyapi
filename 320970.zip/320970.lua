-- Lua provided by SkyAPI 
-- Game: IGT Slots Paradise Garden
addappid(320970)
addappid(320971, 1, "a571cad2d0a15193a105760a8ba67b989dc4cf54049d92f9bdb2b610661bd9fa")
