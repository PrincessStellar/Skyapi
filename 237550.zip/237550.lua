-- Lua provided by SkyAPI 
-- Game: Realms of Arkania: Blade of Destiny
addappid(237550)
addappid(237551, 1, "0863ab8a2a4fd55685249383aadc0f8f50a1b5885fcac43cef90cff83658662e")
addappid(264840, 0, "ea90d3184033e55b3968702ba0bb81981ceeab8f96b6e96de96fd3678df9c162")
addappid(264841, 0, "cb9e6b89c09801d430ddb432851d739c55e6db87fb2b360c7762453aed76820b")
addappid(387910, 0, "d6517f790a4cd5a24a7cd061c3b4ca4509497099a68b76fa912c94da20bedb5c")
