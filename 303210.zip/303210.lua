-- Lua provided by SkyAPI 
-- Game: The Beginner's Guide
addappid(303210)
addappid(303211, 1, "60a04d46a56182551146b5da68422591375fa4a7e6873d6c7dcb3180ae71c6b5")
addappid(406461, 0, "d50673cd1356f45330ee57d1e79ff1c035b72479c166d2a08945fc86fabd06de")
