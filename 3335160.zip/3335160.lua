-- Lua provided by SkyAPI 
-- Game: Uncle Chop's Rocket Shop Original Soundtrack
addappid(3335160)
addappid(3335161, 1, "1e431bd976468ab1e9d7f53ad4f167a9c47d3b042d9c741fff54803794165abb")
addappid(3335162, 1, "f95fbc44e54f2616830219b1520e83b8e809fa88720a640adc0dd541bbdc39e5")
