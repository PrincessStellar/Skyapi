-- Lua provided by SkyAPI 
-- Game: ArcheBlade™
addappid(207230)
addappid(207231, 1, "ca8d9c24441a574bd3871cc750d6b1d0728696c21cf89d6908861629f749dab0")
