-- 1480870's Lua and Manifest Created by Morrenus
-- Lightning Fast
-- Created: October 01, 2025 at 23:19:22 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1480870) -- Lightning Fast
-- MAIN APP DEPOTS
addappid(1480871, 1, "79d1bb6dfdaf06bef3114b3a044162aadce2d84b4f170bea5a3f1b773fa22474") -- Lightning Fast Content
setManifestid(1480871, "2633442155221304344", 7206297757)