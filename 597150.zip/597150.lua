-- Lua provided by SkyAPI 
-- Game: AppID 597150
addappid(597150)
addappid(597151, 1, "cf0d6c456b6d6d42eb0d576381c53c864676928b4ef48420f29ba5dde109472d")
