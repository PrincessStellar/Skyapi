-- Lua provided by SkyAPI 
-- Game: AppID 363330
addappid(363330)
addappid(363331, 1, "ae0abd6d07bbdfa3f2773c4cf837bc12e701b8ef5344032f2d5dc2dee2a7aa8e")
