-- Lua provided by SkyAPI 
-- Game: Slinki
addappid(354930)
addappid(354931, 1, "145b5566921bcbe57970aa0c3ac2241ca56a60bd17cc0602c9175af2f24ade49")
