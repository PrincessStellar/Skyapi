-- Lua provided by SkyAPI 
-- Game: The Walking Dead
addappid(207610)
addappid(207611, 1, "2504e31b160035dedf8690255102320b7bc9b2e4ae50fec1ad94f4d77b273e28")
addappid(207620, 0, "b09a45186c9d017b6b6aa6c5841327bf027bfc952eb31ef3f442c68a8d83e6f0")
