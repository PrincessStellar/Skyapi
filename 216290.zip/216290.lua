-- Lua provided by SkyAPI 
-- Game: Gateways
addappid(216290)
addappid(216291, 1, "59c2e03041d95f6cf8fbb21478536ab0343e05f102f5932adb0a6fecea1edb6d")
