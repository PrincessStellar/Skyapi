-- Lua provided by SkyAPI 
-- Game: Genital Jousting
addappid(469820)
addappid(469821, 1, "6317b276f5f1d6bed97a40ab77bb91875303a4414e00ef3a3633f8878541af7b")
