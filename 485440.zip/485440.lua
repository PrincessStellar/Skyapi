-- Lua provided by SkyAPI 
-- Game: AppID 485440
addappid(485440)
addappid(485441, 1, "c5b0a2ce24c3a2ee1837be7c6b0df8561311d09b69c7bae2e2f48d3b8c3ae507")
