-- Lua provided by SkyAPI 
-- Game: Civil War: Battle of Petersburg
addappid(584800)
addappid(584801, 1, "122351d74c36837b0a888927b1adda6b01f3163b89a98471f0500b0f9da3a45c")
