-- Lua provided by SkyAPI 
-- Game: Pure Pool
addappid(300610)
addappid(300611, 1, "62c69656df0c1bef82caf1591d71d431aca986b4d787fa273a54a63a15f5e883")
addappid(300860, 0, "9ab0fe97b50337ddf8c79bf184c4cb526b4cf0dcde443d74c384f4472ee8dedf")
addappid(305400, 0, "b24f862a38ac3698659e57e0d4728c58756a9c5c408572b88dcd332902ab9d88")
addappid(362360, 0, "be034f06794b3b98786e2a951204fdf99db6dab7c38ffbe4ffadb55db2edd20e")
