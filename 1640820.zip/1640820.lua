-- Lua provided by SkyAPI 
-- Game: Chinese Frontiers
addappid(1640820)
addappid(1640821, 1, "2de4c341c69a5caece120eed798bbd441bada826bdf8b1ea784ad8d1964397b9")
addappid(1640822, 1, "523e44823dd5e6b046a2f63a9d4c6cdea4d21188c21f153da271138c00b1685e")
