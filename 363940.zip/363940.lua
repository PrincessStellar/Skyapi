-- Lua provided by SkyAPI 
-- Game: Solar Shifter EX
addappid(363940)
addappid(363941, 1, "0bdf67fd605e2ec855b55ebf123b938175f28d0f1a63934970af021f4b424875")
addappid(400770, 0, "c1d092cb12746b278b5a28c4094441e06db7f7826350a078ec618f751a9cd84c")
