-- Lua provided by SkyAPI 
-- Game: Rabbit Hole 3D: Steam Edition
addappid(283660)
addappid(283661, 1, "e68ea3d839f99bf0b298ce3d8c2c7c1c0c5a65041bd912b2cb925878e10e37ae")
