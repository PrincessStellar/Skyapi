-- Lua provided by SkyAPI 
-- Game: Raining Blobs
addappid(414370)
addappid(414371, 1, "6971dd4969cd0a87b3385bec9f21708da85f720922256c65e0e8d0c845fc5103")
addappid(593040, 0, "892516a491a8acf4c084cb00370f35772e2cc19ea0a1ba55de17172ba1b963a2")
