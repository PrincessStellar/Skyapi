-- Lua provided by SkyAPI 
-- Game: Bacteria
addappid(448470)
addappid(448471, 1, "09ad1fc66a5eee2929a6beb2511648c9d9be3067cfbac8e7ef3718c034aafbdf")
addappid(448760, 0, "f961b81b26aaa75ba6999abea1b120cd3056a339a88b3b7edc5d66dbdbafa2b8")
addappid(449400, 0, "414a8470801c917b04744159dc1ac27f786f6ff0b4e566b4c2d03bee69cee6dc")
