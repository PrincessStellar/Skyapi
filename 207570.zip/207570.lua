-- Lua provided by SkyAPI 
-- Game: AppID 207570
addappid(207570)
addappid(207571, 1, "cc8f6871f6bba2a47a4b0987950189cdf0c17ce2a0f60b3b89d0498fbb505415")
