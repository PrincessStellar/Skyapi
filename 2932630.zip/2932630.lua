-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2932630)
addappid(2932633,0,"d0c4ca72a290ec9043a3550a7f37b90000d4b60b44410a3ed75881a3cd0f7626")
setManifestid(2932633,"9120630058666726416")
addappid(2932631,0,"19d54cc71d9f34c8ab79b0c9b083021ccacf9efb02c70e8f3cf3d3c997779cc0")
setManifestid(2932631,"7340820829856029139")