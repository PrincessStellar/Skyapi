-- 1373510's Lua and Manifest Created by Morrenus
-- BloodRayne: Terminal Cut
-- Created: September 29, 2025 at 01:36:51 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1373510) -- BloodRayne: Terminal Cut
-- MAIN APP DEPOTS
addappid(1373511, 1, "1656da2f40de519eabcff0dc39322978f16a1c017214f1c89c068cabec08f63f") -- BloodRayne: Terminal Cut Content
setManifestid(1373511, "4513483547061206365", 12513717313)
addappid(1373512, 1, "9b5167dea57d9d726e026caac17eeb3cd11b383b9488efee075c7a0f4b6e537f") -- BloodRayne Legacy version depot
setManifestid(1373512, "6591583254492672950", 1684359028)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)