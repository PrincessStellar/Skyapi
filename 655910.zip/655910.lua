-- Lua provided by SkyAPI 
-- Game: AppID 655910
addappid(655910)
addappid(655911, 1, "e9f5483c976a5471e7e3c610495331734e835366d67958ccb86ef97850f1c9a7")
