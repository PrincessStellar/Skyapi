-- Lua provided by SkyAPI 
-- Game: Heavy Bullets
addappid(297120)
addappid(297121, 1, "58d969ae18fa82acb659bf17caeed2773222834a0129de7d3f5f5851303d4786")
