-- Lua provided by SkyAPI 
-- Game: Eternal Step
addappid(374240)
addappid(374241, 1, "d0f02bdd9e22444b140b80dc80ddd03a676517ad9693ff6bdafd8e28c1ccabec")
