-- Lua provided by SkyAPI 
-- Game: Cities XL Platinum
addappid(231140)
addappid(231141, 1, "815a9b328b48efbc031cdd6d88c29717db907810096f3715ed38bf44e62f3424")
