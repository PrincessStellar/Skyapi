-- Lua provided by SkyAPI 
-- Game: Game Dev Tycoon
addappid(239820)
addappid(239821, 1, "5c590b0d0e5b292ede17d5bd6b6eb1a2b75487771e3465047c2a9829839ba8e6")
