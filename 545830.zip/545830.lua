-- Lua provided by SkyAPI 
-- Game: Princess of Tavern Collector's Edition
addappid(545830)
addappid(545831, 1, "70ff84898b08b2040fb402999599bd6d289de71202f7b016b4e70b22db30c5b3")
