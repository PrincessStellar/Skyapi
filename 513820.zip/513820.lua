-- Lua provided by SkyAPI 
-- Game: LUXIS
addappid(513820)
addappid(513821, 1, "ce2ead7175ddae7e4d811213a96e1244c9a4c9916c04a7d5ad02f1cc20802e00")
