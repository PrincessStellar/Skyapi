-- Lua provided by SkyAPI 
-- Game: Sherlock Holmes The Awakened
addappid(1949030)
addappid(1949031, 1, "9d24669555d74ce46354104ac51cabb0d56b98f2be48de9c9eef2ff5b2a392cc")
addappid(1949032, 1, "f5ed67a9eed700ec2032583ddac5767254f593873bcc340b7b30141eac7d1dc7")
addappid(2208700)
addappid(2208701)
addappid(2330100, 0, "21dd9d672e685c3529683b7c95ec6e28aaae408ef532769282a39c17f9f0d43c")
