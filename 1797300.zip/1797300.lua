-- Lua provided by SkyAPI 
-- Game: Void's Calling ep. 2
addappid(1797300)
addappid(1797301, 1, "166dd53fd78e613460f3bc6986edb9d108b1365044f3833bdd6c769c5de90909")
addappid(1797302, 1, "7d1165a7e217b33faa3d14f220b6c662c3d3f48f01ab07abfcff5cd460bc779b")
addappid(2576940)
