-- Lua provided by SkyAPI 
-- Game: LoveKami -Divinity Stage-
addappid(547340)
addappid(547341, 1, "5192f6611ab0e0b626a19e96e47bed7bd6bfcb939285eb818ceffe382cefb5cb")
addappid(881830, 0, "725281fb86c9038b860207652242349db9f4c91a599601e6cbb095d803f69159")
