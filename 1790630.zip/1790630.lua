-- Lua provided by SkyAPI 
-- Game: Astral Masters
addappid(1790630)
addappid(1790631, 1, "53aef9f12e790e5a7a24afb1a69745211bdb8d74588c2da1f54bb86a276a1d6b")
addappid(1790632, 1, "86860c3581d8cb4e09c3a358d7b1bbae610adbf185cc125ff67f7a77bf913453")
addappid(2160780, 0, "cef2b91289dc81f53aaeed05d9e137da9dbb2fbc7af8abda66a4db4f0bb78eac")
