-- Lua provided by SkyAPI 
-- Game: AppID 3060900
addappid(3060900)
addappid(3060901, 1, "ead4c9a8a43c73e6e396b2cf9d1b892e6b6322b2219ab77e02be03a366108053")
addappid(3060902, 1, "c5add8e10019a0bd7199e30107b4ecf8b6bf348de6759c385dc6ba53cbf16414")
