-- Lua provided by SkyAPI 
-- Game: Rule the Waves 3
addappid(2008100)
addappid(2008101, 1, "13f30cd722bc69ec14523f5401a4e3ec55681fae33d7178fbe2ab185d6d06690")
addappid(2008102, 1, "66152eff38c7eb7dcee53c21ef361af6cda1c45fc6d4d3670ed3792c07b27ea0")
addappid(3170370)
