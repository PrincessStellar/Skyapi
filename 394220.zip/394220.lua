-- Lua provided by SkyAPI 
-- Game: Last Horizon
addappid(394220)
addappid(394221, 1, "9224d91c4b3ae434b316d8388d4278fe8ddd8338ccf5991f23bf5cc28388c537")
