-- Lua provided by SkyAPI 
-- Game: Sea of Thieves Audiobook
addappid(2308990)
addappid(2308991, 1, "6833b5cf42d28a05dfe529663c50d181c215ba32289377bd1b3e8bb3c45608ab")
addappid(2308992, 1, "ea926e9a97486f11781266ab5fd434810f285cd0cdbb42ca5282490cdc755e1d")
