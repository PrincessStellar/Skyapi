-- Lua provided by SkyAPI 
-- Game: AppID 629280
addappid(629280)
addappid(629281, 1, "bc219c8f6988769ade75c7732947e6233c69a38c8a75be993058c7c83f4a4449")
