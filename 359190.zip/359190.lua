-- Lua provided by SkyAPI 
-- Game: Rituals
addappid(359190)
addappid(359191, 1, "aafe5e6be682d68b7eef6e8dd92a7ea71425a6abb43d98278eb4831c7db7c73f")
