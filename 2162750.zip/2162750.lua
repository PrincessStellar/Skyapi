-- Lua provided by SkyAPI 
-- Game: Draco
addappid(2162750)
addappid(2162751, 1, "e31c4e478d3ea8b630ca83180ce1194631a1d24d514c60846b7da181e54af7f4")
addappid(2162752, 1, "ddec173cbbbadb5255a731ca7e4faeda41b368ff6cd4272086b113ede8cf35b8")
