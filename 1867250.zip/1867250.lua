-- Lua provided by SkyAPI 
-- Game: HUMANKIND™ - Music for the Ages, Vol. V
addappid(1867250)
addappid(1867251, 1, "7f09bb27209072a2e06da413d5e77c9bf9e24c7042bd5d835de440984b01a944")
addappid(1867252, 1, "ae680afd6ccda507099320a02ed3e6aa5b18d1de954b2b2bdffc650fb5887475")
