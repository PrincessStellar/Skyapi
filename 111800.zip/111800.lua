-- Lua provided by SkyAPI 
-- Game: Blocks That Matter
addappid(111800)
addappid(111801, 1, "f9a8bb4a9a9b6c6197d48cbe110c896d8764fb21de0790832f3774ed268c3c8d")
