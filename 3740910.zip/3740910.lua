-- Lua provided by SkyAPI 
-- Game: AppID 3740910
addappid(3740910)
addappid(3740911, 1, "ff044bc72f04adbf6b35cdbdb36ee6d2dd29e451f6db874624cb397e96c290cf")
addappid(3740912, 1, "d09111bfa26de03202c50165c9cec69f4565a2281ebd9121984b0668b923b281")
