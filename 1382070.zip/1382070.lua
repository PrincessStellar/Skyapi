-- 1382070's Lua and Manifest Created by Morrenus
-- Viewfinder
-- Created: October 01, 2025 at 05:30:41 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1382070) -- Viewfinder
-- MAIN APP DEPOTS
addappid(1382073, 1, "91db9b94243c9fa25520ef73ded5d2c2cc4345c27b38f36f4d110545dcaaa4d5") -- Depot 1382073
setManifestid(1382073, "3086948026555098456", 15347663063)