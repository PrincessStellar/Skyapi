-- Lua provided by SkyAPI 
-- Game: Egypt: Old Kingdom
addappid(646500)
addappid(646501, 1, "038f7283e1e87ce42dbb136be2b87c950108a34c238864cebb0e3bf833efc78a")
addappid(844470, 0, "12822d3b4f6edf10c23ac308b8983ba4858d2f7d8d500a12463312a3c90b6266")
addappid(844480, 0, "62535c9e442b1225fd52264e2f8da3eaa66c08a5a15e964758f9b0f6f974f72e")
