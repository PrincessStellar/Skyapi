-- Lua provided by SkyAPI 
-- Game: AppID 545040
addappid(545040)
addappid(545041, 1, "4dde7a91c0187c1676c399c1747b601ebf96006d5fff94482045e41819688a92")
