-- Lua provided by SkyAPI 
-- Game: Skator Gator 3D
addappid(1996470)
addappid(1996471, 1, "c5de443b7f8dec8ad7796de319ba528858a88abc2430257c1929bd14b483549b")
addappid(1996472, 1, "1bbbc7e7b99624bc061b9cb7fd952d3277b9b9d1eeb020bb3a7bf3cf4a5eb547")
