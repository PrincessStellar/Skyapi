-- Lua provided by SkyAPI 
-- Game: Magic Research 2
addappid(2864890)
addappid(2864891, 1, "00df4cd16a04dc241db056aa7a3bc56671e98068358353649abeea1bc2a16796")
addappid(2864892, 1, "8ce0c28ea01408d1139b408db01ed6564f74237eb79380d85d0116d34495bbf0")
