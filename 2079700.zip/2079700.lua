-- Lua provided by SkyAPI 
-- Game: Witchhazel Woods Soundtrack
addappid(2079700)
addappid(2079701, 1, "541caad908fcee3bc13e16136a20dc9c35f1b7da5b002c234110b578b26c7863")
addappid(2079702, 1, "310e8a0b617a0384d06e3f52cbe63bcfa86fd627ec710dde8931d1a2e40228d6")
