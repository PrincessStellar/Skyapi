-- Lua provided by SkyAPI 
-- Game: Clawfish
addappid(1621140)
addappid(1621141, 1, "d259ab7572c22b579f1c615f6fc98d21a2a58ab4e39807bc655a1d19163c58d4")
addappid(1621142, 1, "8ad655fa0a12442f0698a6dead9f3b468e9f21c6b6337f853b19d2956d4dc5bc")
addappid(1621143, 1, "bcb64eff07670dce4aceb5ba0819c8535722a7acdedb8052b970b2fedc4d9839")
