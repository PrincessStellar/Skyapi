-- Lua provided by SkyAPI 
-- Game: The Silver Case
addappid(476650)
addappid(476651, 1, "3523e73546fd4c2a6a91804e5067f10277297887e37693c5b63b5de2b064796d")
addappid(533570, 0, "212e3ebeef7b649d3968f18b1e67ac1ec45a7201a9b69a28cf78aa6f56ba28c6")
