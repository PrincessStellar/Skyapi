-- Lua provided by SkyAPI 
-- Game: Wizard with a Gun Soundtrack
addappid(2506650)
addappid(2506651, 1, "ee5fcd0bf318a3e6bfa5505109de56b44b1e447c0ca320aa2882b1da291e41fc")
addappid(2506652, 1, "b6947dd40fc833ace5b5eff44a733d9ea5fac2504e6d1aff433e878e346b8bfa")
