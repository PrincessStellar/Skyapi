-- Lua provided by SkyAPI 
-- Game: AppID 423610
addappid(423610)
addappid(423611, 1, "73765a82a96361a2584438f8d8b5dabfcc40a86a0d0ac13f688b62cfc07fdf73")
addappid(446350, 0, "d219bc6dc05b50152e72293a2d35efdb4906e40f7a42cfb46b31138c5d9adbc6")
