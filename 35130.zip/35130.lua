-- Lua provided by SkyAPI 
-- Game: Lara Croft and the Guardian of Light
addappid(35130)
addappid(35131, 1, "5725f25146f6406779f703c8d3d6d761195fd83c3011ef5f6a9a69448489d0b8")
