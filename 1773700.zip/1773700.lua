-- Lua provided by SkyAPI 
-- Game: Hack and Slime
addappid(1773700)
addappid(1773701, 1, "e27395401d50deef7ca622360f4970bb1f6fd9947914ce94351a137f12e422e5")
addappid(1773702, 1, "a579ee43269530f04673c2741be7ce7a85ed515d984f4d1e02c884ea0c808012")
