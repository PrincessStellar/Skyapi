-- Lua provided by SkyAPI 
-- Game: AppID 594330
addappid(594330)
addappid(594331, 1, "bd25107db41b4499b57e397d12db225a8488620327bad7ef15021a9e0294cde9")
addappid(938721, 0, "237b39e0b35e141f64b5354d0ade640791de2d73b268d60eaed3cec81254a6d9")
