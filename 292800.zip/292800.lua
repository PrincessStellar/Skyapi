-- Lua provided by SkyAPI 
-- Game: Pajama Sam 3: You Are What You Eat From Your Head To Your Feet
addappid(292800)
addappid(292801, 1, "f4e9e712ba87894f333d29e02e0e7935224d02d2e244b845e90f68e63ce404db")
addappid(364150, 0, "0c3022e38f3086c538dc231adef5c64dd2f578e8be9ab504985cecf03870a347")
