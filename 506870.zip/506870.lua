-- Lua provided by SkyAPI 
-- Game: Unexplored
addappid(506870)
addappid(506871, 1, "6c69cbe96d3cc4e9c7d1418441d9274912e4b6119bfe5fd84732b826baab8494")
addappid(633410, 0, "4ee1eea324a56174567e70bfb743af59e5f0340f5874f9af8e233b31137ed473")
addappid(633411)
addappid(639030, 0, "7a99526c12dedd8dd06b5b4ec048b83d2fff1a7e05165c13beee4d532705903d")
addappid(639031)
addappid(913920, 0, "d479c5021b9f0b2d58709798f862d660d5afb04536d5fa168cebde30ea4ec870")
addappid(913921)
