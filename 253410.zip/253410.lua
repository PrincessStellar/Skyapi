-- Lua provided by SkyAPI 
-- Game: Ravensword: Shadowlands
addappid(253410)
addappid(253411, 1, "6aa87f4b8e487887b7cd2953cc69f7a9ec34228fb7070276d13bad3385435c14")
