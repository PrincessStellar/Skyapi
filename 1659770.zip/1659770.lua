-- Lua provided by SkyAPI 
-- Game: Robolife Original Soundtrack
addappid(1659770)
addappid(1659771, 1, "bc5f92802dfeebf55ce9e36b24946a752ea6f85f7e323ceea7ed972be234eebe")
addappid(1659772, 1, "6386ebd8f51d9bd99e3ec2142b51d44a865704c83ac8145310fd4ae7a3caa3df")
