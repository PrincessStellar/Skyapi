-- Lua provided by SkyAPI 
-- Game: OPUS: Echo of Starsong Original Soundtrack -Best Selection-
addappid(1727830)
addappid(1727831, 1, "0b771503378f1afc7db06c9e6faf57f7ac4f5757fa9f9b8defda91476066f7b7")
addappid(1727832, 1, "19fd83e285a8406551e3e46475f27bde2eca431205c6079a0b3b80edfaed31f2")
