-- Lua provided by SkyAPI 
-- Game: Snakebird
addappid(357300)
addappid(357301, 1, "15abadd380dd4ecbb4fda2aea3cdfc9217979f6fc472b548428226a84da34011")
