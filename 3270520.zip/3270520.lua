-- Lua provided by SkyAPI 
-- Game: Limbo
addappid(3270520)
addappid(3270521, 1, "814ce1b1f794e1b9b86bcfbb437118a48fcd3d8d1188cc5662749017e37228a7")
addappid(3270522, 1, "4f7f166ea57d7a0bc329213f7c4a86a52f5128f42250a08de685aeea59960540")
