-- Lua provided by SkyAPI 
-- Game: Dwerve Soundtrack
addappid(2012750)
addappid(2012751, 1, "a024a32350f19ada0411f8cbad53fa2848fe34ffc14a413a2cd8b3f6558379bc")
addappid(2012752, 1, "f4763ce612bc41b1029aa950ed42e281fdee0a015e26bedc149497f94bfe808b")
