-- Lua provided by SkyAPI 
-- Game: The Letter - Horror Visual Novel
addappid(460430)
addappid(460431, 1, "dcfc7d89afcf650def01d20ede66c9c3e2e44ca5742e33b96b6611dd8119408d")
addappid(742350, 0, "f5472f987e7c359ec907bb3535b11df0d7a16980402e4d23f64f3cd1bbf6f6df")
