-- Lua provided by SkyAPI 
-- Game: Mint
addappid(670100)
addappid(670101, 1, "f46c78205cf9f4e658f7eff0699360680f62597494d33e8e9fd769a781accc23")
