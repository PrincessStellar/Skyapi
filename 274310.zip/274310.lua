-- Lua provided by SkyAPI 
-- Game: AppID 274310
addappid(274310)
addappid(274311, 1, "b8a5679f1113f6a49979eb7be0c48d437a7260269584418eb8071d33497f1e4e")
