-- Lua provided by SkyAPI 
-- Game: AppID 501320
addappid(501320)
addappid(501321, 1, "b9811c7974d74633b7e34ff7d5703c96f1301e20901c724488ad22fa4242fa41")
