-- Lua provided by SkyAPI 
-- Game: Grimind
addappid(265380)
addappid(265381, 1, "f73222735647e9cb808ce34839e0cf4d68e1f4a3f0caceac7c8bebe56fe6e3ba")
