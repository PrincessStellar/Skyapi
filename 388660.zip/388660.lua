-- Lua provided by SkyAPI 
-- Game: Project Tarvotan
addappid(388660)
addappid(388661, 1, "d70496b4080a88ccf6fa5fd393ee2c4fe1b8b424999f7a7cd257bbe5c2c5beb7")
