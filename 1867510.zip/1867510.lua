-- Lua provided by SkyAPI 
-- Game: WrestleQuest
addappid(1867510)
addappid(1867511, 1, "db606293ddc0a6cacb973c03a6c7b7973fe8db366a6dd554c9b586257da8a8c7")
addappid(1867512, 1, "b962b06eac63f5ae8eaa2e565509e888da94a6d41bb780e8465a99ffa9d8faea")
