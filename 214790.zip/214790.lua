-- Lua provided by SkyAPI 
-- Game: The Basement Collection
addappid(214790)
addappid(214791, 1, "62a626490506a598e03e2840d904e0f47aa07ee1d3c0ece253b7a6af836c4c16")
