-- Lua provided by SkyAPI 
-- Game: METAL SLUG X Soundtrack
addappid(1940630)
addappid(1940631, 1, "3ecc0aacb590f100dbecda8c511fc6c744658ee7c4b5d98ef07002f30cbed5ef")
addappid(1940632, 1, "116fd054946d0ed59f7345e73070b9102295892c848963d0777ff89397ee28d3")
