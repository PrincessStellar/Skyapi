-- Lua provided by SkyAPI 
-- Game: Cat Quest
addappid(593280)
addappid(593281, 1, "33130777c4dc3a1691afe38e0202242580e2135bfb239dcd83e50cd18d384687")
