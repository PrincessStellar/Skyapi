-- Lua provided by SkyAPI 
-- Game: AppID 532330
addappid(532330)
addappid(532331, 1, "971bcf4c044bef9e1d8dcae51384e9ad768fa015dcc1a54e100e444fca40eb1d")
