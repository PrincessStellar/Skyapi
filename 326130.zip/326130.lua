-- Lua provided by SkyAPI 
-- Game: AppID 326130
addappid(326130)
addappid(326131, 1, "c2867fb32dee853aea733f7fb390f7c10b6b24cb358e135fe2cfce09502d6ce7")
