-- Lua provided by SkyAPI 
-- Game: TUNIC (Original Game Soundtrack)
addappid(1928140)
addappid(1928141, 1, "710d73c4141c73683893786213a450152dbeeed4d7158a106b522bf76baf7d41")
addappid(1928142, 1, "2850ed92913d55211b7fdbe1b01c64ec8cd645ce0cec09508c854de7cf75b511")
