-- Lua provided by SkyAPI 
-- Game: Kakuriyo Village ~Moratorium of Adolescence~
addappid(2326590)
addappid(2326591, 1, "06dffa8bbe8ca3cc7ca7a8002bce59c29899352e3950ab92462e53861b21a328")
addappid(2326592, 1, "7b7c2d7b88f3e48079fadda550611d68b15841b01427ec5511de10bd8a039afd")
addappid(2326593, 1, "a4d272aba6e82774c969408f0218f27978c1b55f561df6fb9b03874c06e248e5")
