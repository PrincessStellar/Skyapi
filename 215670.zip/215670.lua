-- Lua provided by SkyAPI 
-- Game: Home
addappid(215670)
addappid(215671, 1, "3d315bf5620c9dd58eae99067191f529697ac8e519a1253d4cba5d35ac159ab9")
