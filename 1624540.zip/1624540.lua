-- Lua provided by SkyAPI 
-- Game: Storyteller
addappid(1624540)
addappid(1624541, 1, "ff6c2e088a80d4a69004fd8f212214f02a6684da905e43037db5c6c7aea8c30b")
addappid(1624542, 1, "3f5ac40b88ab9803c294aacb5327309c7734c505607420d3ab523377a50f7137")
