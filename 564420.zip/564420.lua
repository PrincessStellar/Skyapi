-- Lua provided by SkyAPI 
-- Game: Santa's Special Delivery
addappid(564420)
addappid(564421, 1, "d0f6e2f6ad81cc73b5686afbf6ab8536fe030b865123210e17728e1d2f7b5ec0")
addappid(568170)
