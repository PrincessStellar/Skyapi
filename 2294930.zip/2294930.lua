-- Lua provided by SkyAPI 
-- Game: I wish it was morning all the time
addappid(2294930)
addappid(2294931, 1, "0d89a5c9065849413fe3d487498e275aebe9e9decbeb4df5a69191931cf5f2a7")
addappid(2294932, 1, "94fa4ae50ff9539625fc1d049b228f7301c0a919b699f1d43581bf939336a8c9")
