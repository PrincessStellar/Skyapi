-- Lua provided by SkyAPI 
-- Game: Wooden Sen'SeY
addappid(259830)
addappid(259831, 1, "92982b36b628685f7ae3d08838dc4fcc06b5f0c7f4b5bcc85d5b5b6d5dcedf83")
addappid(273700, 0, "e123ab3b030227aa48b12c73ecddc1feed8732b99f0eda8a122635f1bb9b3ded")
