-- Lua provided by SkyAPI 
-- Game: AppID 294000
addappid(294000)
addappid(294001, 1, "f34b579b60aa45d613c339f2d659ec698993742674238b4d11522f151382e7cc")
