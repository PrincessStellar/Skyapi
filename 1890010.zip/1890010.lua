-- Lua provided by SkyAPI 
-- Game: OOZEscape
addappid(1890010)
addappid(1890011, 1, "43f5c459ce2e14287e009933b7a6f26e151c1a3b0930c2acf2e5a8aa3de81d55")
addappid(1890013, 1, "bd738f485e965a0321963f4fcc4d359b02d212ea785648849bac98b5ea63f812")
