-- Lua provided by SkyAPI 
-- Game: Clinical Trial
addappid(2778550)
addappid(2778551, 1, "08b3499e13c9894ea4405c6fc4a02984b7ae0fe37097264e8fcaa2481923c5db")
addappid(2778553, 1, "28f4825efac3958a082db9c58ebede4c4eb81c8048b155271a99d8622c96aed9")
