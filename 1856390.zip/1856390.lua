-- Lua provided by SkyAPI 
-- Game: TROUBLESHOOTER: Abandoned Children - White Lion and Black Witch - Soundtrack
addappid(1856390)
addappid(1856391, 1, "c729fbc6cd983cd206c08842fe510dc9dbde4bdb6155dea0d216e8655ab73780")
addappid(1856394, 1, "48acfd5d3a375b76c7d1d753f448e5c686090e38ea72ea46dae6d33db6203501")
