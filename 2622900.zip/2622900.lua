-- Lua provided by SkyAPI 
-- Game: The Invincible: Original Soundtrack
addappid(2622900)
addappid(2622901, 1, "92a2065e3abb96d42f98fb09c5768d2522a106b4c0532c9bad255730ba7c2508")
addappid(2622902, 1, "c55a27b584cc48e98c6cd426bbe1a26e55710e461d1ac97810dae2b5092e6dd8")
