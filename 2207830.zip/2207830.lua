-- Lua provided by SkyAPI 
-- Game: Pentiment Soundtrack
addappid(2207830)
addappid(2207831, 1, "43b4d6f724400c6c47537d9fc0a721a8fe1252300454ae0454a7c05b414f6b2b")
addappid(2207832, 1, "752c2253d2086cab3111fd71f8f9359162e660c2590f2cf373b65ef76dda1cb9")
