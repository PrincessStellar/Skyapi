-- Lua provided by SkyAPI 
-- Game: The Emerald Maiden: Symphony of Dreams
addappid(429610)
addappid(429611, 1, "069d8626fd179249048376d1b5ee0055d8cab35bcde4b9fc8f80955696fb14c2")
