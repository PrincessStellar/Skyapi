-- Lua provided by SkyAPI 
-- Game: Kairo
addappid(233230)
addappid(233231, 1, "16fa7b6d3d49c6d18a9718fb2cfe36eb04a57a9d9b8d3a6694cc2384b7605c41")
