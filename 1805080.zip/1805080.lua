-- Lua provided by SkyAPI 
-- Game: Reta Tus Habilidades
addappid(1805080)
addappid(1805081, 1, "6ae89141e41bd28c4711b0f7ee293839f9412f8768b4d024e828f98cc54a0588")
addappid(1805082, 1, "f112c2398abf096506738a653cd0059dd23061f1ad97bc94b41b9ef6f04c37a0")
