-- Lua provided by SkyAPI 
-- Game: Megamagic: Wizards of the Neon Age
addappid(422650)
addappid(422651, 1, "45f35cde09b944344207cc0020e7cd0ed0c7e19fbba034de979f22cbc0a73380")
