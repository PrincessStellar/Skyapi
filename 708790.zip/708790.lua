-- Lua provided by SkyAPI 
-- Game: AppID 708790
addappid(708790)
addappid(708791, 1, "966acb1895290c68df9727f34e8cb189492d9a7a926ac6721c2568921854b124")
