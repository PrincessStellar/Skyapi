-- Lua provided by SkyAPI 
-- Game: Null Gravity Labyrinth
addappid(2701170)
addappid(2701171, 1, "5be0ba658b86bbac3af42d6460bc4aab19e0daf16405c80eaeeefad00d0233f0")
addappid(2701172, 1, "cfa1ed09ef4e3edb805749816ff6fdbe3f4c1eef42fdf8bbaf167e6d54f4a87f")
addappid(2701173, 1, "138e5894d2d0bd41309e57e6b1b9bee1bfe0715781639159d3864cc923d6966d")
addappid(2701174, 1, "e2a5ef1d1a926420adda0234933eafeabca95d015d0793bf30881422ff16d302")
