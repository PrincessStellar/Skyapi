-- Lua provided by SkyAPI 
-- Game: OBS Studio
addappid(1905180)
addappid(1905181, 1, "9893ce20679d91040e3ac618d31a5de675e18fa1462dd41962812a2a18b4c2ca")
addappid(1905182, 1, "57c87ca72a249265959763d8e435e45d4ac968d958c98b7f6ffb5a78e1ab8d9d")
