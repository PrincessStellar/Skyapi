-- Lua provided by SkyAPI 
-- Game: Over the Counter
addappid(1626460)
addappid(1626461, 1, "92babcbe4aafd293aa6643aeb310b16d084f0ffd3c4d0197c5e2138a5fc6cfcc")
addappid(1626463, 1, "6c15894aaed39439c4708166ee377b79e08a0da2f75ce996215bbd817a5a61ee")
addappid(1626464, 1, "1b6854c0055990f642894b45c75c7e2f447e8ae786d85a86b0eeaf80e9d34f52")
