-- Lua provided by SkyAPI 
-- Game: AppID 573490
addappid(573490)
addappid(573491, 1, "d48e8280304d1245c19aaf65dc98d9d4518ceed4b55d198994ef2db3d963da7e")
