-- Lua provided by SkyAPI 
-- Game: Mortuar
addappid(2921000)
addappid(2921001, 1, "89bdd046892ad7ec644bfa9a52cba44dd15d8318e1f7298f6500b6d94b9ef061")
addappid(2921002, 1, "43ac1fa39707672d968f9c876366f709cdd1f88e5574b4ad008fad81c799e37d")
