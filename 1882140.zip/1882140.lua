-- Lua provided by SkyAPI 
-- Game: Decisive Campaigns: Ardennes Offensive
addappid(1882140)
addappid(1882141, 1, "4f85ae994707f5c3552abf83ff58493d8dbfd2a9110c0ca40ce34467a74abfa4")
addappid(1882142, 1, "ffb5ee4010812a5e0d5bbdd604e6a0a620d5e177f8195eb460298328e7fc8b09")
