-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2958970)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(2958971,0,"6a77249e795dc23efaa8cc24bd18b87cd28f6707dc75eeb0e8f7a3170cd8e420")
setManifestid(2958971,"2968358844784895996")
addappid(2958972,0,"8d1dc0c5fcf66fd80551e763fb9476517739447e5c617f42584661657027fcbc")
setManifestid(2958972,"8552566512058024132")