-- Lua provided by SkyAPI 
-- Game: Radiant Princess - Poni Ceres
addappid(3050140)
addappid(3050141, 1, "686eba539c686cd7e11cf85b49d996cbba080e9b0c57203382f30e09a9d5d5e9")
addappid(3050142, 1, "5383e3ad1ff7172ed456cc3d5d664aa8365fe105e5d061517137694b56e08170")
addappid(3050143, 1, "8f06b578e2debab18ea9ad40c9e44a8ac60a42f3d6abd60d7962d148e075e60c")
