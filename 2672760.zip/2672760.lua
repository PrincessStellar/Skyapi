-- Lua provided by SkyAPI 
-- Game: Maza
addappid(2672760)
addappid(2672761, 1, "cd9c80c180f1286b8a467d2e2532f36a3a9661ac277bf5e73acd3446d7a6036e")
addappid(2672762, 1, "5cde1fd8dccf0c765d8d50fc0ed801dd606bf7618bc28abce03cc5a01c1e6f89")
