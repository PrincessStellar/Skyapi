-- Lua provided by SkyAPI 
-- Game: AppID 448070
addappid(448070)
addappid(448071, 1, "587a299e8c59f0059ea3e6b2be8280b598e96f5f1fca3bbce198e1a56a8c3fd5")
addappid(450470, 0, "817df10a0abcc143741ce9118a8f295eda9c65ed76742ca6d8fe160978559d5c")
