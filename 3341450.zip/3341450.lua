-- Lua provided by SkyAPI 
-- Game: Rat Hunter
addappid(3341450)
addappid(3341451, 1, "4aea273d8b9185fc94694246790b14958905556e0c922d52b72fdd4017fe298a")
addappid(3341452, 1, "2f626c4a9948f3b21146ef8b2eb1fd7c1e68fd8ed7f5effa133e2b56126ff5b0")
