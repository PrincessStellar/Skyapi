-- Lua provided by SkyAPI 
-- Game: Super Ride Grandpa
addappid(1966580)
addappid(1966581, 1, "852afa9d1174e9ca2a9a1899b4381d92e03142e015ac6efe704fa3c015b5e010")
addappid(1966582, 1, "bbc74371c73a211e59eb7c03a7e542912ab06f1778eb84e954c25f9974a6ad33")
