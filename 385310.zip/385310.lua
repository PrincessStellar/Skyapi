-- Lua provided by SkyAPI 
-- Game: The Land Of Lamia
addappid(385310)
addappid(385311, 1, "213ca3a659b99577ba393d6d849a5a3b45622e2cbfb25d3825c252bba0db448a")
