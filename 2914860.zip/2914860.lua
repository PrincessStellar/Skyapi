-- Lua provided by SkyAPI 
-- Game: Wow I Might Refer To This As Tooting: The Trombone Champ Soundtrack Collection Vol. 2
addappid(2914860)
addappid(2914861, 1, "4398bff553dd266c443236f142b058533cb8f94d51bf2b2907a659754eda5de4")
addappid(2914862, 1, "0e8a172f01edc46637e6ef4ed43fc6be6be9cb537e62ed9c7a25437ff4fdaf6e")
