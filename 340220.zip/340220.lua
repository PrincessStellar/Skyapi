-- Lua provided by SkyAPI 
-- Game: Shadows of War
addappid(340220)
addappid(340221, 1, "1ecfd38608bac2a57546ab2f21cd55b73af18fb08226fc669359931ecec28771")
addappid(387040, 0, "a5a9773a148619c96ddd17f64071344e7afb90e60ae13eed4a9a7b18f878e0a3")
