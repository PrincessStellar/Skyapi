-- Lua provided by SkyAPI 
-- Game: Rocket Fist
addappid(413500)
addappid(413501, 1, "b095d91742ec808787f0648a45b4b0100ab0b09a2eeb09bb5b6ca7c572f44fb8")
addappid(473410)
