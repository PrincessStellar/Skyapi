-- Lua provided by SkyAPI 
-- Game: Empires of the Undergrowth
addappid(463530)
addappid(463531, 1, "913b6f7c71e6b2453f127bfaa8581883b1fda1fa980ddbe4b1ef1b3f9b6c9cef")
