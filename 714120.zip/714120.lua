-- Lua provided by SkyAPI 
-- Game: Little Misfortune
addappid(714120)
addappid(714121, 1, "9c8332d28ea3cc30897635a7e15fb74637c0ba49bde89c1a8d697ef70c77bcad")
addappid(1146790, 0, "a5ee4a47b15583927994977ed495dc321cbccf682d8936de73535cd1919a04bd")
