-- Lua provided by SkyAPI 
-- Game: Eternal Ninja
addappid(3249190)
addappid(3249191, 1, "13c79ad9340d715c4777da5512ca29347ac9fe0ac0a93fb11207876913309a70")
addappid(3249192, 1, "a9207ad4fb3c934b716153d3fab6a3f9be25d0f0e9208e7665790c4712789cda")
