-- Lua provided by SkyAPI 
-- Game: Deadly Animal Duel
addappid(587790)
addappid(587791, 1, "be614d65d84ca2dcf47bdd255a2a1d1a3c9b3725c95b1ceec9596b17d813b6cf")
