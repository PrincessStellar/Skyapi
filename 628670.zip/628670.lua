-- Lua provided by SkyAPI 
-- Game: Hellpoint
addappid(628670)
addappid(628671, 1, "955fc7cba03bb9ac3216822e737749d4688231406d569ebf680cea22360a5f1d")
addappid(1380040, 0, "9ae1c8d6d4d8ecf5c84637f84f3f17d8dcc27b9fad706cc2574f3b93beb17f2a")
