-- Lua provided by SkyAPI 
-- Game: AppID 449510
addappid(449510)
addappid(449511, 1, "88e3e5c25925ebe37ab6f64ecfa3174cb2a59b11af93be5fa7f85cbeed54a002")
addappid(585730, 0, "723130fcbf24a01a31472cbd6bdf8d6a8c0b830f228b539951ac99d183f4e6a1")
