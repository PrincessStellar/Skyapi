-- Lua provided by SkyAPI 
-- Game: Play With Me: Escape Room
addappid(725780)
addappid(725781, 1, "1201e2e167012e4b7b7508670b41a8448ca01e3529dbdc65a59a4b6a44a79700")
