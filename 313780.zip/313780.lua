-- Lua provided by SkyAPI 
-- Game: Conarium
addappid(313780)
addappid(313781, 1, "ee2ee391cd9021988fb50c4fe904697513b511740123188476b3721ed4af9d2f")
addappid(651510)
