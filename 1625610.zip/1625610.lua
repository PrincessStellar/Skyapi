-- Lua provided by SkyAPI 
-- Game: Bub Block
addappid(1625610)
addappid(1625611, 1, "54a427ee72dd843df906d24beb5f5bb1c48d88d956b61219f39b7dfe7e2bd29e")
addappid(1625612, 1, "4432936fac9bbe112157c81666921110bb2cea19ade808428daa65b188ea49a1")
addappid(1625613, 1, "d58daa0342f780dade49455fd99edd512b4110f488ffba3b7f983e5045987dc5")
addappid(3382510)
