-- Lua provided by SkyAPI 
-- Game: Storm in a Teacup
addappid(104020)
addappid(104021, 1, "d5590b6865e6837a18cc977975853c5dbee6299c96e36aff2ffe22758ad6ca47")
