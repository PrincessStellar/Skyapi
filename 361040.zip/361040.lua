-- Lua provided by SkyAPI 
-- Game: Doom & Destiny Advanced
addappid(361040)
addappid(361041, 1, "1244dbf2052b2e8719f967b40baaef0df4d6efa37d2073ee671c118f92e2e55f")
