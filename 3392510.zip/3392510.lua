-- Lua provided by SkyAPI 
-- Game: Zexion
addappid(3392510)
addappid(3392511, 1, "5d53f23ed21b4ab30e5d0695879fba7a477dc9f550e3d934ccfc2e42317c09e8")
addappid(3392512, 1, "00d802867681ff00c5b399b781484783237bbea9b21626cb26b438d5e435868f")
