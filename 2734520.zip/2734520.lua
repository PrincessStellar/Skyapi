-- Lua provided by SkyAPI 
-- Game: Russian Soul Simulator
addappid(2734520)
addappid(2734521, 1, "15b0404e3a1425878577167a61a01e66f07102fc7de56213bf66a4ee05869412")
addappid(2734525, 1, "0112a352d0a5043483b8dd4493bb3b024592bb6179b2e82d11613d81d84c9b66")
