-- Lua provided by SkyAPI 
-- Game: AppID 329710
addappid(329710)
addappid(329711, 1, "91f6b6685c5c7d79cc1e5f5b256836bda788c63876d5730bc1e8985e228752bf")
