-- Lua provided by SkyAPI 
-- Game: HUMANKIND™ - Music for the Ages, Vol. IV
addappid(1715200)
addappid(1715201, 1, "106c4c2f56ca1e321d1274b3be4d3e6c2ce25d205211f548e9a9277cf47bfe08")
addappid(1715202, 1, "616c367c993f89f82282e848fac928df3c7cfafeef2bca54c056094418a661ca")
