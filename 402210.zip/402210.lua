-- Lua provided by SkyAPI 
-- Game: AppID 402210
addappid(402210)
addappid(402211, 1, "45305ddd725ffbc63d5bb6ecddae9ed9f5f440e0db40feb24f625f690c416af1")
