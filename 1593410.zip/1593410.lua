-- Lua provided by SkyAPI 
-- Game: The Awakening of Mummies
addappid(1593410)
addappid(1593411, 1, "5639a0d482276de2afe58a0d461a6ce50f0e833f2a8fe2a36d81dc18e91500bc")
addappid(1593412, 1, "d3991a12edad13438976623c515b9a7214b33e294ad73f2bae25282d6b861b50")
