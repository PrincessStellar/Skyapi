-- Lua provided by SkyAPI 
-- Game: Mystery Solitaire Powerful Alchemist
addappid(1624870)
addappid(1624871, 1, "ed0edb7bb9414e5f8690affb6450578720774b5e00c0a26ab84ff381916044bb")
addappid(1624874, 1, "ba241250b591b5aee62e01f94e5e272b400b6b90d6c003590911b7100040c984")
