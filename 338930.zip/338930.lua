-- Lua provided by SkyAPI 
-- Game: TRANSFORMERS: Devastation
addappid(338930)
addappid(338931, 1, "51a9e236d602d2935e45ae49bfd88e51d2a8cd1e01cb1ded32cba564d1196bb3")
addappid(347970, 0, "6d2871bfd5e964d84ba9d65ef821768d676a1635ddb5fae28da0e5b126d9473a")
addappid(359000, 0, "783c01fc9a7dd743e93ac5ddadcef8a2077606f42fe8309d2683c4c315239dbe")
addappid(359001, 0, "99f2d2a354ef621f0f9348a76c2508ca30e598fa6129eb023a550a4d496d7f5e")
