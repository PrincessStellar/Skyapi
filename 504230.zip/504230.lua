-- Lua provided by SkyAPI 
-- Game: Celeste
addappid(504230)
addappid(504231, 1, "54f178dcac153879e50ce091af232f1451898adf19d5613d4baa7d67ff7ed15e")
