-- Lua provided by SkyAPI 
-- Game: Not The Robots
addappid(257120)
addappid(257121, 1, "91db9e81ea5fc02a3b652b34e894d4f34c4efa21d875ee84d22b0d7cd2a89f68")
