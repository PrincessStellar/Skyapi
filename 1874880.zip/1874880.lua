-- Lua provided by SkyAPI 
-- Game: Arma Reforger
addappid(1874880)
addappid(1874881, 1, "f1bc308d3a58a8d144a76dc02d552819b433bda49c325060fcab53e8100cead3")
addappid(1874882, 1, "c964efe3e6ee7295beeb474f46e6c78d1f2f62097dc3c793b1474cfab9f2f055")
