-- Lua provided by SkyAPI 
-- Game: GROOVY
addappid(372490)
addappid(372491, 1, "876d03e830a575e890e83daa29dfdc38b24dca4a4b168362df80918000d9a19b")
addappid(486520, 0, "2c0f72712a7fd4cdfbdc9965b591a7751acfa0d35157cffdd0e26457b4d543bf")
