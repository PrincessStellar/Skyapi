-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3028310)
addappid(3028311,0,"553fc1b6d6075185f02a8eba5821d274d56536e35f297a4733b779552e9b07e7")
setManifestid(3028311,"1302140078595509051")
addappid(3028312,0,"2407db94a13666878dc806ac384b2af3741cce1a7499122097f3b1cd57b670e2")
setManifestid(3028312,"5927685249792041335")
addappid(3028313,0,"e86a6f9d2c72b0fb239862435f6b8c4c431acc28a8734d846ed3032fc6b5f4fe")
setManifestid(3028313,"8488006223424062743")
addappid(3453990,0,"6b5ee20b58e6268ecbdc302b151f75c70818bac9adeac5b600680781c73afed6")
setManifestid(3453990,"3517757317403910077")