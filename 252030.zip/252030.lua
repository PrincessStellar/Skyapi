-- Lua provided by SkyAPI 
-- Game: AppID 252030
addappid(252030)
addappid(252031, 1, "68a69eae1e2b5e510836415db3917d386db459464f57625387d2220b44f340f9")
