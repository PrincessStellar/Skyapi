-- Lua provided by SkyAPI 
-- Game: MechRunner
addappid(288100)
addappid(288101, 1, "7989c93295c404e9044d45194376a5e6c92cb2589b8db049d7898ebf13231ef6")
