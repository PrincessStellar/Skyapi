-- Lua provided by SkyAPI 
-- Game: AppID 521100
addappid(521100)
addappid(521101, 1, "ee185779556d3b529cfbe0b8759d5c373769e7f4ee070376c1ee5f2d86ecae0f")
addappid(533230, 0, "70c854b8f9a3b4a4b8c219d4e56531ec113cf7bd56dd3cfd3b56ea5430b83c7c")
