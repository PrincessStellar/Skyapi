-- Lua provided by SkyAPI 
-- Game: Grim Dragons
addappid(491440)
addappid(491441, 1, "4871ccb5798c241d96fb7b1ba53bf50738efe8c92a69a1f17a6f990034fd2687")
