-- Lua provided by SkyAPI 
-- Game: Tale of Toast
addappid(640150)
addappid(640151, 1, "2564db9a6ecfe703d9f6d5c0adcc45ec665806a9aaaffafdbc5789866ed225b1")
