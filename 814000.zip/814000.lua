-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(814000)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(814001,0,"42d84d2e42b1e4103fb7597c5044385c294167829b1e033d894530ec3e3c4456")
setManifestid(814001,"3541244075542598126")
addappid(1888180,0,"9b6b1e02076f2b3b11efddeddcf5f205f632842421696481a24be1cbfbd6a46a")
setManifestid(1888180,"1333443026720192680")