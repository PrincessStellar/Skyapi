-- Lua provided by SkyAPI 
-- Game: Mountain
addappid(313340)
addappid(313341, 1, "1335d7bdd136f5ac6f84e6e8131253ccf3e2afe71e88023510dc7edb6c6ef47a")
