-- Lua provided by SkyAPI 
-- Game: AppID 2276820
addappid(2276820)
addappid(2276821, 1, "8fbaf231482e9603e5f23c099808f11d33d6376da30cde049bc6aad046a4f580")
addappid(2276822, 1, "eb8b0f529350ebe7146b28b8f56d3f4ce01bcb7350e7e156f112c75ebb5b0120")
