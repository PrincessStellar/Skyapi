-- Lua provided by SkyAPI 
-- Game: Amnesia: A Machine for Pigs
addappid(239200)
addappid(239201, 1, "56e3256bf209f382a31c67bc688a43d3d203c7b1b1289fad2e5518f58974891f")
