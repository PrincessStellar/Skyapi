-- Lua provided by SkyAPI 
-- Game: World of Goo 2 Soundtrack
addappid(3681380)
addappid(3681381, 1, "f305789b66baa4965cf4828e4ad54634c915a74bc88dcc25d13eade21dccff87")
addappid(3681382, 1, "d8ea5cb6ae1ee2164752ad24606a2c803922286e26c35b8ce9b7890903146fe0")
