-- Lua provided by SkyAPI 
-- Game: Sister Lumina and the Hypnosis Cult
addappid(3147220)
addappid(3147221, 1, "e72fa4a999bfb12bda91b8545d421398aabe007869d6e98294fbf09c9216b181")
addappid(3147222, 1, "3b734c1b6661ab121508c32dde7b1b2699ce32d59f6b9adc86bbd63fd94a10fe")
addappid(3147223, 1, "888ee3a39ad5013abc00de6d55ee975cef2d64d57b0be96eeedfa8a9056deab8")
