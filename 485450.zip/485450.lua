-- Lua provided by SkyAPI 
-- Game: AppID 485450
addappid(485450)
addappid(485451, 1, "79ef5f961b6b2f27afe7eeaeea35370d07c6d4961f711d36454f0d25f907e41c")
