-- 1390350's Lua and Manifest Created by Morrenus
-- Webbed
-- Created: October 01, 2025 at 07:04:00 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1390350) -- Webbed
-- MAIN APP DEPOTS
addappid(1390351, 1, "ba207fae98255a61553df347356f3c5a08cbce410ccaf7ce6a00c7b05a75d1d3") -- Webbed Content
--setManifestid(1390351, "5801314574093294013", 231277780)