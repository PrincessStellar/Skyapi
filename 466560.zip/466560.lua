-- Lua provided by SkyAPI 
-- Game: AppID 466560
addappid(466560)
addappid(466561, 1, "073598adfc95cad9b9866fb7b6625dc6ab9ff54d5f00dff91733906ab3da0042")
addappid(820561)
