-- Lua provided by SkyAPI 
-- Game: 9 Kings
addappid(2784470)
addappid(2784471, 1, "3f1be54c32850828ed38015c593c4596fdec0af8820dc3e517efba88374d235e")
addappid(2784472, 1, "cea0ff84008944b1cbc251283a8ded658adf149382bfaf80d3959d28ebb5734e")
