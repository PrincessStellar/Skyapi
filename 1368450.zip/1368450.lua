-- 1368450's Lua and Manifest Created by Morrenus
-- ENDLESS™ Zone
-- Created: September 29, 2025 at 10:25:16 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1368450) -- ENDLESS™ Zone
-- MAIN APP DEPOTS
addappid(1368451, 1, "1dcf4dd2c76c53ed8514422afaa89a21bad1fbe31f053b3896b961f9d690935d") -- Air Content
setManifestid(1368451, "4150294388538648318", 1921952642)