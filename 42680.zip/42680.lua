-- Lua provided by SkyAPI 
-- Game: Call of Duty®: Modern Warfare® 3 (2011)
addappid(42680)
addappid(42681, 1, "b7003c5ea7e370881499daaf5ba52ea4f3a1e76843fb37ab4d97753d94df8f95")
addappid(278331, 0, "0e8c2e3857ffb4d0cca47f5cf07ccbe8ee9e2ccc66be7ac744d1fa5167745310")
