-- Lua provided by SkyAPI 
-- Game: Candle
addappid(420060)
addappid(420061, 1, "a1c4563aabe941f1faa4099011b5e7c616f2f6447a8a9fdd38130e9c3590327a")
addappid(537210)
