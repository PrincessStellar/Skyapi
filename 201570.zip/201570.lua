-- Lua provided by SkyAPI 
-- Game: Really Big Sky
addappid(201570)
addappid(201571, 1, "49b68ef461e25d17f203538b0c8763d080cf60a8135df17097e78ca0e617ad16")
