-- Lua provided by SkyAPI 
-- Game: AppID 284750
addappid(284750)
addappid(284751, 1, "ddc56be0db90b80d724b4a0029611ef0f75123ada26e88ad831795826c842b4c")
