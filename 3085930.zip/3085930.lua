-- Lua provided by SkyAPI 
-- Game: Deviator Soundtrack
addappid(3085930)
addappid(3085931, 1, "715fc7f15f0203f136da03f975ac42b05de8c752d5933d992c919bf53c348366")
addappid(3085932, 1, "93a0b2187f1aee30b2f435b2db525fc810703472b29a6f992f32d8559f25056b")
