-- Lua provided by SkyAPI 
-- Game: Receiver
addappid(234190)
addappid(234191, 1, "d4f466342b1f4e538d16e6e137855a7e8ab9dde11e425ff3773897ad456570f0")
