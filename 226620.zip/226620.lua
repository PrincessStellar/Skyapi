-- Lua provided by SkyAPI 
-- Game: Desktop Dungeons
addappid(226620)
addappid(226621, 1, "df2707056eeb76654471b4edb61355fe2a35217ba54974e9811859069f9e37fb")
addappid(261420, 0, "366cc6f05d9b690a50f37158c8430f2ebccc465e8b4dbb79d47be27f67b88638")
addappid(261421)
