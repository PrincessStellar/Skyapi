-- Lua provided by SkyAPI 
-- Game: Kotoko's a Little Weird
addappid(2657710)
addappid(2657711, 1, "224eaa711db3862947cff89b2b9851540b8614860a8b2b9194f874f9a72795c8")
addappid(2657712, 1, "ad4ccc132b6fff4831858cd7b48477951a1676a33d8ba18b7b4c94ef36e2e939")
addappid(2657713, 1, "d21f12c6802f7f877802c780307dab78a2faa60ddec0cf39a23a75cfe8d6e505")
