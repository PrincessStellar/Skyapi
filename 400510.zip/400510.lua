-- Lua provided by SkyAPI 
-- Game: The Final Take
addappid(400510)
addappid(400511, 1, "69296ae450c080f99f6aa733de48aa7139a030d1490f0ce8f765c28bd68dfdb1")
