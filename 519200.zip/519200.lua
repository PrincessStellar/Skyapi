-- Lua provided by SkyAPI 
-- Game: Kitty Kitty Boing Boing: the Happy Adventure in Puzzle Garden!
addappid(519200)
addappid(519201, 1, "7a85c71544fe5d43ae833d3ab55eda5abe441034aafe9d20a50df69df57f87e4")
