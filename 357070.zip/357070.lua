-- Lua provided by SkyAPI 
-- Game: UBERMOSH
addappid(357070)
addappid(357071, 1, "f94b4f0c4aa43367cb9f1d6d62d0de581c20e1fbbd51fca60347af858afaf342")
addappid(366420, 0, "c42acf1ea650816e6c2077c1351376fb5113a50ca2f4ed5a57409983dcacb3b3")
