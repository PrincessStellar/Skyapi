-- Lua provided by SkyAPI 
-- Game: Dungeon Warfare
addappid(355980)
addappid(355981, 1, "6b953e5d867a0580dd7b9f3a11887b704cc88f05c778160f7ea146e2e394b3d8")
