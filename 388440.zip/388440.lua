-- Lua provided by SkyAPI 
-- Game: AppID 388440
addappid(388440)
addappid(388441, 1, "7d28d226693b76a5095c84fce8aefce06a9024d3c98b0c615d62db4c63d0d95a")
addappid(439710, 0, "128fe6136724cdc0e4e2005826697a4dbd47912884b43e4de65ca035f1bb0138")
