-- Lua provided by SkyAPI 
-- Game: Nihilumbra
addappid(252670)
addappid(252671, 1, "93451a1f2412b47c53fa08c48a59504367abff6c63fcde0f4bfbdfe55041e488")
