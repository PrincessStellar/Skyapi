-- Lua provided by SkyAPI 
-- Game: AppID 2694570
addappid(2694570)
addappid(2694571, 1, "ee877345e997bede02675e0aceee469cad70043c0d871056d8bf3538dd6a1628")
addappid(2694572, 1, "527493505ceaccc4e7f3e43cd3c32e1c23915e4252cec3fdcaf4703f2b435669")
