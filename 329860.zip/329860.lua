-- Lua provided by SkyAPI 
-- Game: Catlateral Damage
addappid(329860)
addappid(329861, 1, "68cf5f1681b8575885350a4f12c363368eefb2f2f2346fca555d5f767bcda5d0")
addappid(474720, 0, "ae0781278b13ee27e2333cbd81a5fc20e2edc6a46a33a5a884510f6a041431d1")
