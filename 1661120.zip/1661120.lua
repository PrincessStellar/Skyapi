-- Lua provided by SkyAPI 
-- Game: Carrier Command 2 Soundtrack
addappid(1661120)
addappid(1661121, 1, "45dc325ffb241f270bc241eb326483cf3c532759fbca714231c58f70a866ae44")
addappid(1661122, 1, "32059e723b9954006a9958f78d30241e1023f1322dff1f252dd3cf694b3d2287")
