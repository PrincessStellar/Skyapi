-- Lua provided by SkyAPI 
-- Game: AppID 336140
addappid(336140)
addappid(336141, 1, "8a3ac50462bf7d31250c79826ad82caabe7ece2afa6c7dc3d5475b7b7a7b6238")
