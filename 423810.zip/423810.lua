-- Lua provided by SkyAPI 
-- Game: AppID 423810
addappid(423810)
addappid(423811, 1, "fabcf56208646a3f0f4b80e6c6f0d4da53ea431f81a0bb6471f2f7f6cdb82276")
