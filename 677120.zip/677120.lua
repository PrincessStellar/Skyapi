-- Lua provided by SkyAPI 
-- Game: AppID 677120
addappid(677120)
addappid(677121, 1, "a175a07de8796904ceaff58ff186aa983270cf4301f6a26d4f76abc7d8b2749e")
