-- Lua provided by SkyAPI 
-- Game: Ultra Street Fighter® IV
addappid(45760)
addappid(45761, 1, "57e09e51340949bac89d9a3b1be1274426a0a8c44c04288e78aeee7cebd1afdc")
addappid(301660, 0, "6bf7af0f3e6c1d6f19ce09adc0fcae00b25d17bc42ad7d30cb0ae095a6e5a89f")
