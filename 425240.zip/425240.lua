-- Lua provided by SkyAPI 
-- Game: AppID 425240
addappid(425240)
addappid(425241, 1, "27ab454e66bd6e48381b291b93557bfa718ee8f1586e85fcdf9ff1ee5fe43653")
addappid(692140, 0, "4b7b37e933bb37c8cb0c71618b2dfdd6bc2fc6490b7312fb0695be942ce6bcb7")
