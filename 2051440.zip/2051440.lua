-- Lua provided by SkyAPI 
-- Game: AppID 2051440
addappid(2051440)
addappid(2051441, 1, "f957318ef6e36855c2104b7536cf28b24b3dd0499cfbfdceb9d76ca53a85c44c")
addappid(2051442, 1, "5af279d5b0e6d86d9808788dbc246e6a00d87cd6115c1454e438bb1e7d30de10")
