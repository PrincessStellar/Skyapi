-- Lua provided by SkyAPI 
-- Game: Mark of the Ninja
addappid(214560)
addappid(214561, 1, "aa5e930d8aac47c439485a5d901793c531766de977a1b1d165223591a29a048b")
addappid(239570, 0, "8aff7876a4ea40e87c8565ec98a9bf8dac3ed1d13dc3ff20b114776041f4cf6d")
