-- Lua provided by SkyAPI 
-- Game: Just Go
addappid(1862520)
addappid(1862521, 1, "7965baacce6118b2eb5d0af056c4d7a02855c912a5cbf9947927c56e7d90b969")
addappid(1862522, 1, "3fa3f8c12dca76b1bc4fc94284e227818281c2f04f0644930744885b1d58f545")
