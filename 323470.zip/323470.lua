-- Lua provided by SkyAPI 
-- Game: AppID 323470
addappid(323470)
addappid(323471, 1, "a92b27f33a671ba1ff67c80c0508d6f8d276ac2936d558fba95d8dc83e5b0765")
