-- Lua provided by SkyAPI 
-- Game: Total Conflict: Resistance Soundtrack
addappid(2336780)
addappid(2336781, 1, "ec410f8cfd9d2abc6d1e8c14ef0bffd41ca47c28650b0b56993397b2df9b1ca5")
addappid(2336782, 1, "0bfd522f55d87ce73e94c976716221e18ae23c9f3792e9d2eb861f0f7ac9e7e3")
