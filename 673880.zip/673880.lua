-- Lua provided by SkyAPI 
-- Game: Warhammer 40,000: Mechanicus
addappid(673880)
addappid(673881, 1, "89aa31906085f80bb20d0b8a7d7602c459e28a8c8ece4e7e35807bc1fbcce0c6")
addappid(916250, 0, "c7f31588fd8cbdb0eeed1c684e2144817a03e391d91848d4c1c1da5f85c8baca")
addappid(1104970, 0, "2ddf38791f7b66a2f00994369228e6dc42682e4f5f87c68e7b3e954b015b00d8")
