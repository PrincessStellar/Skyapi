-- Lua provided by SkyAPI 
-- Game: Trace Vector
addappid(297410)
addappid(297411, 1, "75eb1b9a0965cafde181916cfdcf0dcdcffe63450d7d477b1b3536883ca83aad")
addappid(311460, 0, "230cab587d7ef3644466584145fe776efa0a59f2155fee971a66ed8546d46cbe")
