-- Lua provided by SkyAPI 
-- Game: Hegis' Grasp: Evil Resurrected
addappid(644380)
addappid(644381, 1, "a4e8a2537a96574504eab4d16c7a6371d0c14fb77a07e574e2e8b2ac4b914a2a")
addappid(953140, 0, "09668cf9ac4eb2a25f3b2bd87c5c0d813c0393efe27b0cd71f8c34f76ad91d83")
