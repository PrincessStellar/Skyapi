-- Lua provided by SkyAPI 
-- Game: Total War: PHARAOH - Soundtrack
addappid(2600980)
addappid(2600981, 1, "03bfa68a56193a215361350e07051d915b93bc96aee3250986d09d1c17d26c04")
addappid(2600982, 1, "f69472282780a66a7407af466bd0f6afe7f67b079559e1761468b72d0556529d")
