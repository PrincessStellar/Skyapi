-- Lua provided by SkyAPI 
-- Game: 葬花 Soundtrack
addappid(1802770)
addappid(1802771, 1, "c7268e9937aa5167524da894ad87e8447253fbc1a0433ee36a89386906bdd27b")
addappid(1802772, 1, "11ba4fc6739c7ce606376b34f00429302239a474e2995bb187b6b0e22646e3d3")
