-- 1333720's Lua and Manifest Created by Morrenus
-- From Hell
-- Created: December 19, 2025 at 09:23:09 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1333720) -- From Hell
-- MAIN APP DEPOTS
addappid(1333721, 1, "fe02af86792cc02fb1f6608ad0f3ea1b595ddec6db8677c4e5121c174463985e") -- Depot 1333721
setManifestid(1333721, "5511703674517761116", 23888717991)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)