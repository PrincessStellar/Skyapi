-- Lua provided by SkyAPI 
-- Game: The Darkness II Demo
addappid(204410)
addappid(204411, 1, "895956c4ca8ed25e89cce896f49d4a44e3d9ad930593897dd5c6099d0c67a23a")
