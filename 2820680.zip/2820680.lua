-- Lua provided by SkyAPI 
-- Game: Pogo-Gogo
addappid(2820680)
addappid(2820681, 1, "4511a35608038ee82af26f7fb5f0e57a166f0556ddec5f4fabd96298468b1fa8")
addappid(2820682, 1, "537b5e13d16b0e18e836be42d89e81123339d36611fecc14383d4bea722ada78")
