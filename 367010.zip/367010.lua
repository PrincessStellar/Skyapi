-- Lua provided by SkyAPI 
-- Game: AppID 367010
addappid(367010)
addappid(367011, 1, "fecf213f3832c56e772aa9e7e55cb42fa3b1f8f3aa14894d47afdfd8fe2b8a2f")
