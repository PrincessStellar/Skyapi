-- Lua provided by SkyAPI 
-- Game: Windsor - Grand Strategy MMO
addappid(1876070)
addappid(1876071, 1, "1a3d83885dbd612c0bbfb9414f331b203e947d22d229e0c64cf54365756f15b4")
addappid(1876072, 1, "a1376608cf6c371b321065acbb5767fc7ee3c54aea3d5dbab41e186aef296ba4")
