-- Lua provided by SkyAPI 
-- Game: Shattered Pixel Dungeon
addappid(1769170)
addappid(1769171, 1, "16fd8f03cbefeee50bcd0bee58adf8fa760e02ad522cd43ff176adc6809fe459")
addappid(1769172, 1, "437b34162453cb091719a785061a77e63a466a4aff5e80e6e5c239d950349bc5")
addappid(1769173, 1, "d1735f3afa87ecbf4b228220e1738c6eaf9ee9840229767e0694ec13bf87614f")
