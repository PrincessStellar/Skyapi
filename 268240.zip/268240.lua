-- Lua provided by SkyAPI 
-- Game: Mechanic Escape
addappid(268240)
addappid(268241, 1, "926d571c8a97ab61450c9a722bd153b9d5a166b99162784fa67b448d340833bd")
