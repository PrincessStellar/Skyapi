-- Lua provided by SkyAPI 
-- Game: Homicipher
addappid(2302660)
addappid(2302661, 1, "2af13d0401290a5bc53126249ba4d1d553d7d890d56c8f228916568fa3b2358a")
addappid(2302662, 1, "45e7664ae09f55c3b206e5ad052b4cefdcd9a1ee86e9c64284e066280e2718b3")
