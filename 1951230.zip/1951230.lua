-- Lua provided by SkyAPI 
-- Game: Pizza Possum
addappid(1951230)
addappid(1951231, 1, "025460d66afb6412c986c25877a6bd5a7782c206a2775bc9a0b044adceb489b4")
addappid(1951232, 1, "2a99c0068de13930bf27756368087af851c41d3cf32781092ece7ae693919ccc")
