-- Lua provided by SkyAPI 
-- Game: AppID 1914810
addappid(1914810)
addappid(1914811, 1, "a8271a36d9b4fb9d1ae38b4f688699f4596e3e68b76833cae1333d2c6f7c1f85")
addappid(1914812, 1, "146e16d13472f628d0f4f85405f76dcf3c84a5141dd3c5eb8294b520c2eea44a")
