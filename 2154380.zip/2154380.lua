-- Lua provided by SkyAPI 
-- Game: A Traveler to unknown Thule
addappid(2154380)
addappid(2154381, 1, "6c097e6258003dca819a7e30a10ac6ec00c8944fbc67f82461e815df976120e2")
addappid(2154382, 1, "161781734ccd3a5d5f179bbc08affb7e709bd76d0e5140acdb24abc217ab0990")
