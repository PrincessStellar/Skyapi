-- Lua provided by SkyAPI 
-- Game: Whispering Lane: Horror
addappid(2754490)
addappid(2754491, 1, "eceb3a8a16afab18113181ca05f39317a016e90094831f668282215da93297ae")
addappid(2754492, 1, "9d6a413bb25e6fb1953f0237187d1b4cb2e774295e3d29aedd1be58c79d1dd42")
addappid(2754493, 1, "83e4341124aa458cdb0f8590581e74229ae8712b27fa05caa0e5a45216601cb3")
