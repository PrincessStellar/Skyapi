-- Lua provided by SkyAPI 
-- Game: Angels That Kill - The Final Cut
addappid(383240)
addappid(383241, 1, "97a81f04bd54bdfbfd34cba4fc5fe1fdd1808eb046f1014b9482f7510ee6afd8")
addappid(406100, 0, "51d9b25a35c3afbe271e3ad9438f332e4028ce6465048eb6d7b11f34321f561b")
