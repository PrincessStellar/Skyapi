-- Lua provided by SkyAPI 
-- Game: Six Braves 🕌
addappid(1821570)
addappid(1821571, 1, "37badfe3c62bce36e29292c6d1f7aa959c568ee874e7cbf98fd0131481caffff")
addappid(1821572, 1, "14a00efa5e2fc43388cd664a6d4e49558dc6a1a7bc288d738d572a3d11182741")
addappid(1821573, 1, "8f68b3d358c9285dd6d4e4993fe4f4d03b72b8fb1ab4883903ca5e1190eaa3ff")
