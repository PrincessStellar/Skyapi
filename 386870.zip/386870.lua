-- Lua provided by SkyAPI 
-- Game: Playing History 2 - Slave Trade
addappid(386870)
addappid(386871, 1, "3b351442f34114fbe8ab5670e97d5e0a2e903674a73e03c52f5d8735d75c9740")
