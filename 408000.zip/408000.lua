-- Lua provided by SkyAPI 
-- Game: Cinderella Escape! R12
addappid(408000)
addappid(408001, 1, "cfa93944a8017d08f01a9363b240b8022209d53bfb9fc83a635a47234d6c2163")
addappid(425500, 0, "580815185038edaddeb5243170e26a95ae3ed83b60e4138e55866c8dc32b66be")
