-- Lua provided by SkyAPI 
-- Game: Musclecar Online
addappid(346440)
addappid(346441, 1, "4a11dbeaff954b92d2512a5855867e3d971f03c6f70333855b54ea154911f8c3")
