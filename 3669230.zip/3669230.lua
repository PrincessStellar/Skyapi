-- Lua provided by SkyAPI 
-- Game: AppID 3669230
addappid(3669230)
addappid(3669231, 1, "ba90e9501443b15991abb1ff1c4f6f313eb4b8911669ec6aad271779ac0543ec")
addappid(3669232, 1, "5b96e1630c4076d9c976cdc9cb570d2e944adb7639fba06caf9855c45cff6f38")
