-- Lua provided by SkyAPI 
-- Game: AppID 458710
addappid(458710)
addappid(458711, 1, "9d1dd1a44f33bf87b6f68344dc1081446e9e3d5e6ee5fb0a47898db00d96f3f8")
