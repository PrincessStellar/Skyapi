-- Lua provided by SkyAPI 
-- Game: AppID 263520
addappid(263520)
addappid(263521, 1, "f8a3a84128d9883c35749612ba32c7656dc56d48129b2f992b2f84e173db6fde")
