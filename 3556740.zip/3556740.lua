-- Lua provided by SkyAPI 
-- Game: A Night Filled With the Sound of Rain
addappid(3556740)
addappid(3556741, 1, "ec50a696d376c762e08e89f4f58e2fb02394bb8e9d84271ab52b5d18c2cb4fb1")
addappid(3556742, 1, "8276035ff1b257876fb1fb53dbfa27e0efb5b328092be56952f36fff5b926928")
addappid(3556743, 1, "fc15c9fc7b7403f426fd8c582d6ea3b88502276690d986d55374c14236332a6b")
