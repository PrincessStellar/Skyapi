-- Lua provided by SkyAPI 
-- Game: AppID 632470
addappid(632470)
addappid(632471, 1, "c1f12eca51041182cc2c6d43bf367dad67ca662865691b1beaac315b739fbf8e")
addappid(1173140, 0, "012eaa221b0a375c66d62ef1f37f67519f22863c8931e98cfc1517defaae5334")
