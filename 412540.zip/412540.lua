-- Lua provided by SkyAPI 
-- Game: The Minotaur
addappid(412540)
addappid(412541, 1, "86f4006cc7628f6c0b2b49de2511a2ba79362ce47b715467ecfcbd0be32a2e29")
addappid(412550)
