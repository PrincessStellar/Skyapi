-- Lua provided by SkyAPI 
-- Game: Sheltered
addappid(356040)
addappid(356041, 1, "4008b22f417ee9e2c479e326ecfe34e6dfbb9694bad680c106d7fd6ee0f3395f")
