-- Lua provided by SkyAPI 
-- Game: AppID 2569740
addappid(2569740)
addappid(2569741, 1, "b99b09ce4900e27aa8182212de0d6a0b48e5be981040b083eafee46847358b8f")
addappid(2569742, 1, "f54cb1f987cc7aba92ad0214385329ad6f33460483ac4a16a29bd840fb305b6a")
