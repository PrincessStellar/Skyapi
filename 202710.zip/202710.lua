-- Lua provided by SkyAPI 
-- Game: Demigod
addappid(202710)
addappid(202711, 1, "9a80fc3d47905a9dc082a75446d13462054a51c53f6bc2e2a5c589ca0b376f4d")
