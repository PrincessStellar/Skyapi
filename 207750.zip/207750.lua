-- Lua provided by SkyAPI 
-- Game: Symphony
addappid(207750)
addappid(207751, 1, "002f2eb9a72e805b68f82a48e55e95f306f624f44584456ca08d9463ab924d83")
