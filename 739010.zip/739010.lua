-- Lua provided by SkyAPI 
-- Game: The Blue Box
addappid(739010)
addappid(739011, 1, "21fc8c09d8ec2267500ea80a6c52c31a6afdb853fe9b5e09dd2b178210d4cc99")
addappid(1214896, 0, "b2fba8f7a8c2cdf6b3a8eec8db20a2bdebc1eaf9bbc4e40b78e544dfe14e69f9")
