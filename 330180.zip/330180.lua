-- Lua provided by SkyAPI 
-- Game: AppID 330180
addappid(330180)
addappid(330181, 1, "67bc979cd1fbb94d7b4022498118800f65d06764a0cfc33de7726d761770c286")
