-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2201710)
addappid(2780830,0,"3e647fcc837c11a11f603de9ba432b0188cd530ba21777a952ab49cef8b63986")
setManifestid(2780830,"5220617777075734693")
addappid(2201711,0,"7eb486f61d982d82e0005758c194897205c1ae6fae2d4563cfb4b0e6fa1f6163")
setManifestid(2201711,"2012673316021299327")
addappid(2541420)
addappid(2708550)