-- Lua provided by SkyAPI 
-- Game: Death Must Die
addappid(2334730)
addappid(2334731, 1, "c853e34553e6dd49da4def65bb28703c7fe9d7f6cda4458faf04d8aa95cd16bb")
addappid(2334732, 1, "45a23685a1639d2dbbd78516c4adb31fd11257137e5e367e327de766cfd56e98")
