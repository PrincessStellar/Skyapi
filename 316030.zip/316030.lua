-- Lua provided by SkyAPI 
-- Game: Disney Alice in Wonderland
addappid(316030)
addappid(316031, 1, "5a04f9a8eec42cf36cdd5b71f18548b23082db88929897df3aa4900af69e0abc")
