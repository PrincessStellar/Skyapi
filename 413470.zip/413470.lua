-- Lua provided by SkyAPI 
-- Game: Untold Mystery: Angel's Cry 2 - Tears of the Fallen
addappid(413470)
addappid(413471, 1, "cad6c8e2daf1f169c976bc9f825529b4e46c3f00398c1a4d5d43db30e9b29535")
