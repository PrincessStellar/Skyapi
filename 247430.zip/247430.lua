-- Lua provided by SkyAPI 
-- Game: Hitman: Contracts
addappid(247430)
addappid(247431, 1, "182bcba5d65a64b9c0dc8156b346cb0549ee2af8a977f547686343e596012aae")
