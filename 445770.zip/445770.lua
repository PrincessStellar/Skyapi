-- Lua provided by SkyAPI 
-- Game: Airport Madness 3D
addappid(445770)
addappid(445771, 1, "131020065b764f537d82aca92f4d8624c893c6bd4a2fd7bd2a85f726ee0e0e67")
