-- Lua provided by SkyAPI 
-- Game: Clear Mosaic
addappid(2417790)
addappid(2417791, 1, "79d15edd387e3a54e7c20a3b12947b78be98d215843b7801a3f8674975d2291d")
addappid(2417792, 1, "a0e93e7fdc66e60f10d43b93c26a784b0089baedd8b4cb6da4c30904ff3d5006")
