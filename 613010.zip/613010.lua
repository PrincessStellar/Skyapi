-- Lua provided by SkyAPI 
-- Game: AppID 613010
addappid(613010)
addappid(613011, 1, "4c06abf2984fa2c9201d7f9900468d7597eff28d833a7e3f6d39a855419e488b")
