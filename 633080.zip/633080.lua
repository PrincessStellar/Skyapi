-- Lua provided by SkyAPI 
-- Game: AppID 633080
addappid(633080)
addappid(633081, 1, "021a43b634a029d8933d6ecdbe24136044a180bbcddc541b424ff8ade92610a4")
addappid(2575460, 0, "b0dde1c4d1c744cdf744fc056f92bb4834e9152c0df481a415d77c97a8f5bca0")
