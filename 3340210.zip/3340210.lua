-- Lua provided by SkyAPI 
-- Game: Please pay the rent!
addappid(3340210)
addappid(3340211, 1, "c4006020f5a08ac2b141ac7db04a43248e894de76fac60e3c1191a5b05dba30c")
addappid(3340212, 1, "98fcdb154f707a417daca051b7d0a232ab6b325b88da1b45587d522fb49ea995")
addappid(3340213, 1, "8599bbaa7071a8b29b0b80290af40b2db8184ec29bc99b3036b708b953c80831")
