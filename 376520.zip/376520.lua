-- Lua provided by SkyAPI 
-- Game: Kelvin and the Infamous Machine
addappid(376520)
addappid(376521, 1, "3799b29ec790f116d3e0573daccdb439aa33c16cc451e15ef13fdfbf30cbf918")
addappid(506620, 0, "42abbba7a7dfe3c4cdef75a582758a886eb653dbe1fb9c61bd33bbf149946ece")
