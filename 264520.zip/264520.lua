-- Lua provided by SkyAPI 
-- Game: Moebius: Empire Rising
addappid(264520)
addappid(264521, 1, "d1d77e4feb51cabbc3ba042c39bbd63f4cd2854234084d7b4eeb37f721be7432")
addappid(287550, 0, "f9e6eacdd749c6451bd4be41baa4e30453e8f5dd404f6822abe365e3719116ef")
