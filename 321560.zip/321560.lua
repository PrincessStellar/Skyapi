-- Lua provided by SkyAPI 
-- Game: The Sun and Moon
addappid(321560)
addappid(321561, 1, "dc88be00784d300fe7a25a54dac9dd8fbaf1f4f8308804712ba53aff51b860cd")
