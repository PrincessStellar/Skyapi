-- Lua provided by SkyAPI 
-- Game: Pankapu
addappid(418670)
addappid(418671, 1, "5e73365d17b0820504ebb38527644a3a02ad72df421079f031d474e0228ce12a")
