-- Lua provided by SkyAPI 
-- Game: Mare Nostrum
addappid(1230)
addappid(1231, 1, "e730bef874fef4c883b2f9b9cda2f6eb03aad6a7a22c3513e2401142229e31fe")
