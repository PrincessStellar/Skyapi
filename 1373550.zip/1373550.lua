-- 1373550's Lua and Manifest Created by Morrenus
-- BloodRayne 2: Terminal Cut
-- Created: September 29, 2025 at 01:37:18 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1373550) -- BloodRayne 2: Terminal Cut
-- MAIN APP DEPOTS
addappid(1373551, 1, "a6654e02d3102fdd94c34601cb157943167510f0971228f403f41783988c65bf") -- BloodRayne 2: Terminal Cut Content
setManifestid(1373551, "7018195597762271367", 8636074588)
addappid(1373552, 1, "58a4242332e6a0b27ad94bbb62d2cd7f004c50e31e48bbb707c3cf2979047a7d") -- BR2 TC English video
setManifestid(1373552, "571115525569442075", 5361161112)
addappid(1373553, 1, "966346629cdfda4b45f83b7de0b791fd03f0f102d4ee9beaac631e23308900cc") -- BR2TC Russian Video
setManifestid(1373553, "2503184033911325343", 5361031456)
addappid(1373554, 1, "818fa66186af9c5ca3b00655860d89b83c0ef916b1b41758b50032e85b0d75f0") -- BloodRayne 2 (Legacy Version)
setManifestid(1373554, "6778675784090717553", 4667343064)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)