-- Lua provided by SkyAPI 
-- Game: Draw
addappid(2473980)
addappid(2473981, 1, "78cb2eb9bac423bc6455ce23e89874937377b19987ba3fbe2fbacd1a553fa42a")
addappid(2473982, 1, "977832bdca6ed77f166bc17a2a5680490d11cd725e278771c5cf3ae95163063f")
