-- 108800's Lua and Manifest Created by Morrenus
-- Crysis 2 Maximum Edition
-- Created: September 29, 2025 at 05:51:48 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 11
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(108800) -- Crysis 2 Maximum Edition
-- MAIN APP DEPOTS
addappid(108801, 1, "7524f88042c40cddc00d3a4d9a3887f14432d907b9e2037a48f7d597f904f385") -- crysis 2 goty depot
--setManifestid(108801, "4435336190133065638", 13361284459)
addappid(108802, 1, "69040cdd3ff6a14bc1aecdeb3a06879bd50598a251a38ea5d43bf547647c6102") -- crysis 2 goty tchinese
--setManifestid(108802, "4881587595324762365", 1112076)
addappid(108803, 1, "33673c96b61267bb9202e0ebe9626d830db3feef3e86f2ba548612f12c4d3d13") -- crysis 2 goty czech
--setManifestid(108803, "4964356744059286797", 997727)
addappid(108804, 1, "01000a281bf0caac31f0fbd0aebac8a2515e8f987ae29dd05ee5833334ad1e9d") -- crysis 2 goty french
--setManifestid(108804, "7091676493200822311", 934835)
addappid(108805, 1, "34c37d55f890fe2a85086fa82f090ec18001558ddbd9623269a5669bc3b837cb") -- crysis 2 goty german
--setManifestid(108805, "6267119516148811252", 910091)
addappid(108806, 1, "4fca762cefee410e93f011482ceacdd8b6dbbf38ea1ab22154d32df728e17514") -- crysis 2 goty italian
--setManifestid(108806, "5963919717102499067", 925382)
addappid(108807, 1, "6088d0f5f9c9b26b0f08a4549ed8823fc82d13b43bcdc6db90523a775fa5f2a5") -- crysis 2 goty japanese
--setManifestid(108807, "7516132942479836678", 1180782)
addappid(108808, 1, "c038da063908c97e01fb14b57a7f800294070f64a3bbe75bba4b1ddeeed30ade") -- crysis 2 goty polish
--setManifestid(108808, "1617765526315783219", 969881)
addappid(108809, 1, "296114ec58bcdb18a6fdb656a9c287ff4f5f05a1334fb1a697eb480d25f6e162") -- crysis 2 goty russian
--setManifestid(108809, "7342531331099624233", 1223059)
addappid(108810, 1, "cb2ea2f9940fb488647eac02d30308671ac6e64f6e601c6479d51d7d7fb32bf0") -- crysis 2 goty spanish
--setManifestid(108810, "6341353486687586219", 914201)
addappid(108811, 1, "a473fef39094e0c65952cf107c9dd2061b79e346929749b00761b17635df5c40") -- crysis 2 goty turkish
--setManifestid(108811, "3712559361882134850", 928994)