-- Lua provided by SkyAPI 
-- Game: Cyberhunt
addappid(636150)
addappid(636151, 1, "f064c91420e6b3a6e69499f96ffcacbfd14cc05232e9347da77272c8190105a1")
addappid(636880, 0, "37219206f919b2ff0a12e9431049667438b03b7c4c66c3160ff753685ee27b58")
