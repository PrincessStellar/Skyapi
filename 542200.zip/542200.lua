-- Lua provided by SkyAPI 
-- Game: Animal Lover
addappid(542200)
addappid(542201, 1, "24428ffc643c4768f0ff166d40b58ff445408627b6fc5c613b72d9a1786ec63b")
