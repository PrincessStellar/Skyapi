-- Lua provided by SkyAPI 
-- Game: EVE Online
addappid(8500)
addappid(8501, 1, "c566ea8e7e68fe163d7758b78b008c027d90bd8d74760589f03048805054cae8")
addappid(228986, 0, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5")
