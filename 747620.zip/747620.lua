-- Lua provided by SkyAPI 
-- Game: Joggernauts
addappid(747620)
addappid(747621, 1, "c164852deff57b8a7271c271579a11b5066635f8e6d83cd4e45b4535d0a73e8c")
addappid(962140)
