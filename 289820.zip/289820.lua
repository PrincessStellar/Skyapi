-- Lua provided by SkyAPI 
-- Game: AppID 289820
addappid(289820)
addappid(289821, 1, "dfe270ebb4a83684a10e99c3244ec2ebe8bc77cdf0e0c4ad32d351dc98f1f8bf")
