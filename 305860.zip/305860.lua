-- Lua provided by SkyAPI 
-- Game: AppID 305860
addappid(305860)
addappid(305861, 1, "2f6f56a823b18fb57a0548b53f6b368227b44891b04cac16ee603eef05268efb")
addappid(313320, 0, "d1d5087ed35b0f3f8096261a5ba0a99dc2806ebb3b1ed2fa51d05f6099035b11")
