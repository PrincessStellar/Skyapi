-- Lua provided by SkyAPI 
-- Game: Vertex Dispenser
addappid(102400)
addappid(102401, 1, "7fd36631cf6af92572a0099492299b195dea09fdf0c0c429bb9e99ad8c2a21e6")
