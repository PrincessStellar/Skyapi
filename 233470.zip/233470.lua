-- Lua provided by SkyAPI 
-- Game: Evoland
addappid(233470)
addappid(233471, 1, "cc2bff779beca66fec6727ce50c410f01987e4e964f48435b1a705fcb1c431ee")
