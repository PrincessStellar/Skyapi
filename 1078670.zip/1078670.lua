-- 1078670's Lua and Manifest Created by Morrenus
-- Another Dawn
-- Created: December 28, 2025 at 16:19:21 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1078670) -- Another Dawn
-- MAIN APP DEPOTS
addappid(1078671, 1, "23d30f22d19b27291ad07b68157341186b6bad4a0aeb18385ebf4411280dbe43") -- ANOTHER DAWN Content
setManifestid(1078671, "6395866603317227043", 5592694015)