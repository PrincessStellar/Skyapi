-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(389850)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(389851)
addappid(389852)
addappid(389853,0,"eefd5e23aefcfbab554a5f4b0532cd1cc447b18a7a68d71a8436303fa51568b9")
setManifestid(389853,"644274866689704496")