-- Lua provided by SkyAPI 
-- Game: Toadled Classic
addappid(521630)
addappid(521631, 1, "95d44330d153affb5345bc2a59216c79453889021dbe18e6d10e9a3fb5c204e8")
