-- Lua provided by SkyAPI 
-- Game: Royal Defense
addappid(291170)
addappid(291171, 1, "3faa2d7ea23df4bdae02fba6c43dfabb5e8bec7e950e93a3f1d3d527a143aabf")
addappid(320830, 0, "9d8e17f15f2a50de1fa60fc227f9103ed7d62737c95245a0a6888fcb601a0ca0")
