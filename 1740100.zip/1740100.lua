-- Lua provided by SkyAPI 
-- Game: At Home Alone Final
addappid(1740100)
addappid(1740101, 1, "d0f8516df69e0c0883656a91e8e0376c1841f6e88fc4161f17b8b424106eb1dd")
addappid(1740102, 1, "8a1578e1572aca35d92a846ae1b945c42af13cc3aa469560ed54c4445ee062c2")
