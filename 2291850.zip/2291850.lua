-- Lua provided by SkyAPI 
-- Game: Underground Blossom
addappid(2291850)
addappid(2291851, 1, "7301f06ff6d9c682a664803eaaaa115ffb893380e1f2f7bb8a3e8d23490b4768")
addappid(2291852, 1, "05e2d8fb8b99a17a8551bddf53421a9298b43602f6f14b99f2056cf4cad9daf7")
