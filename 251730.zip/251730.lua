-- Lua provided by SkyAPI 
-- Game: Legend of Grimrock 2
addappid(251730)
addappid(251731, 1, "9eb6976ef8121eb22a66cf7637f46bf150604d67f3b00c507a57396e4df473b8")
