-- Lua provided by SkyAPI 
-- Game: Reign: Conflict of Nations
addappid(46380)
addappid(46381, 1, "615b7b3df23b3aec7803847ab81cfbbf54ca40337dd5cf0e77e9cc743e59c025")
