-- Lua provided by SkyAPI 
-- Game: Yi Xian: The Cultivation Card Game
addappid(1948800)
addappid(1948801, 1, "36faa07f73256bab7c712cb6f5d353eb2fda66998700a7fa29f504f0144bf81b")
addappid(1948802, 1, "60312180090ac7e5966de810e791c5eac01abbe638b404f23ab2104a23ca0c01")
addappid(1948803, 1, "407089b44256e578ee60c2a6903feb10a4bfa7f0a689de8318659457ce3f375f")
