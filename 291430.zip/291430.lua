-- Lua provided by SkyAPI 
-- Game: Lost Marbles
addappid(291430)
addappid(291431, 1, "20e1d507ee6ee214bda616a507c43bedd15c1ff1b2eef3e541509309b3b8b05f")
