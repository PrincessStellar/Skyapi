-- Lua provided by SkyAPI 
-- Game: AI: THE SOMNIUM FILES –nirvanA Initiative– Complete Soundtrack
addappid(1802910)
addappid(1802911, 1, "8822990bf5dc2733250e0dab4f782bb24aafa8a678d41f3b586d5ab69fe0d30e")
addappid(1802912, 1, "eb106cbd40bc9e01c2a7f635201b84276858bbf0ba355b8e09474e3dd74ecfdd")
addappid(1802913, 1, "cb8aae0f896ff8b3c75a4911c6d2702641c8466bbd70861281878a192584bb6f")
addappid(1802914, 1, "410e60b1d4cb4efd48ce3621eac6732faa0ebe6330ecf4e95931eaa561749503")
