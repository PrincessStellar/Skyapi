-- Lua provided by SkyAPI 
-- Game: Time Mysteries 2: The Ancient Spectres
addappid(313650)
addappid(313651, 1, "0d46169c31d8537cc9bb397176a9cfbf0077d49ca7114604994af7d0cec228bc")
