-- Lua provided by SkyAPI 
-- Game: AppID 367120
addappid(367120)
addappid(367121, 1, "e1682983a98bbc2e75f551c087535b3f916f491fea1e047f03800a6b39678ae0")
