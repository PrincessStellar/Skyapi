-- Lua provided by SkyAPI 
-- Game: AppID 365800
addappid(365800)
addappid(365801, 1, "4c8ddf96c647b9646792fa2044f714b0f526a046d6fd575c3c8aca697258f9ff")
addappid(366130, 0, "b821acc39482c229184d6c2e3b60539e554718d63a4fa3033572c8d2f2c944ea")
