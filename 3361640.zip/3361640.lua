-- Lua provided by SkyAPI 
-- Game: AppID 3361640
addappid(3361640)
addappid(3361641, 1, "64d90be22f3c5de602647d2fe4da09a6c8df0adad34b025b3b81fd311fb7ac69")
addappid(3361642, 1, "b35d7a6a6e3e061bfea589118e6cf6b71e59f25f8d2a75b09f23b7d7f91d17d4")
