-- Lua provided by SkyAPI 
-- Game: Forts - High Seas Soundtrack
addappid(1944190)
addappid(1944191, 1, "f4ccd80e7d4d45ff9c1edbed416ac7482651000da13431d536d8cdc3f7ed557b")
addappid(1944193, 1, "48d4595c4d2c34fdc0d0fb147a8084c4a9b40d30792d6ac9434b5d94ad1dbcb5")
