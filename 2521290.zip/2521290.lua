-- Lua provided by SkyAPI 
-- Game: Chants of Sennaar - Original Soundtrack
addappid(2521290)
addappid(2521291, 1, "556fb399ac5ea71a4a0f430734ee76c4ef0290263705d576db5fe0ee614cf8df")
addappid(2521292, 1, "d99796b7d9c4815e1c29d515f3548c3416de9556ee4e95257829083e5ef9968d")
