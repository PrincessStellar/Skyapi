-- Lua provided by SkyAPI 
-- Game: Lamia's Game Room
addappid(434680)
addappid(434681, 1, "a3b0d3e23c707bf203ca8d3df205a839f2aece42e4189e779af6fd47e6f3b8ac")
