-- Lua provided by SkyAPI 
-- Game: Ａクラス
addappid(2372510)
addappid(2372511, 1, "2012fefbb08b923fdb30aa60b64a8680d51dfc0893205eb6416d4f80a15a5796")
addappid(2372512, 1, "7d0ac2c5d387ceba06c63881f32b9cc642300c17e8ce8066481e986d6aafb77b")
