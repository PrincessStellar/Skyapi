-- Lua provided by SkyAPI 
-- Game: RPG Architect
addappid(2158670)
addappid(2158671, 1, "d40993fa4f0cc48e88e518a471000f1a49ba2c42bb6c90d800adf30ca108a0b7")
addappid(2158674, 1, "b4d692290245a248588ef55e621206b00e68545965373178d692c280525d58ca")
