-- Lua provided by SkyAPI 
-- Game: Satellite Repairman
addappid(567780)
addappid(567781, 1, "25a8b3d9c9dbd0d0876695e1a543eb5d5eb2dc75bb7de348a368bb015c4c0d9b")
