-- Lua provided by SkyAPI 
-- Game: Those Who Crawl
addappid(2228830)
addappid(2228831, 1, "4f74c77f3999367fc1dd322ffc2a3e1e17d39324e3536372c8864c448f972b4f")
addappid(2228832, 1, "deec41852df93b3de11885a304d2612a9445c41e163d40225c41b9ffccece7a8")
