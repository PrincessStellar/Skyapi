-- Lua provided by SkyAPI 
-- Game: Ghostrunner - Soundtrack
addappid(1741240)
addappid(1741241, 1, "d0c46184813765018c3673e7df96df323690776c084cb921a72f141429750129")
addappid(1741242, 1, "1674c3d97f093b66246a074f1611811a01eccff652fdba50f349f2bb831dbccd")
