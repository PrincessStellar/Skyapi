-- Lua provided by SkyAPI 
-- Game: Bad Hotel
addappid(231720)
addappid(231721, 1, "5c3d826453633cdfedb1b49b2fc097181ea6771af113f30eb72af03510c4fd45")
