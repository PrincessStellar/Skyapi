-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3008030)
addappid(3008031,0,"a622c5a96b6e3006f74d2ede522e7fe726218a01452388b5a7754480067cd7cd")
setManifestid(3008031,"653700327025013025")
addappid(3008032,0,"80556fd4ccabe0f5d8145cbcfca11d83697a9bd0cc9e074acb38eeda2c13e59d")
setManifestid(3008032,"912877236270865035")