-- Lua provided by SkyAPI 
-- Game: TSIOQUE
addappid(393190)
addappid(393191, 1, "0deb27baf3ecc57ed5f135190b0768a9e56a9d524391b493a55f5c772bdfbdde")
addappid(994950, 0, "34d63c5a255050b663c271987a7eed1f08a20f9f2dbe15eb95a5d153d8f3a95b")
addappid(1003410, 0, "3700531f12316ae98ef3db3c077168c12d6fff67451fa9c69a7ff194ab5e895f")
