-- Lua provided by SkyAPI 
-- Game: 로스팅 리포트:대학생 수면제 사망사건
addappid(1666720)
addappid(1666721, 1, "77999b53c21d86e281d046bf4efe88dd5b0c82fa7ec8ccef6d8a1af8f5e6ce0e")
addappid(1666722, 1, "229ab2142855ccd3700d29d47c24fe4ecb82884cfea7561df5f0d3a1df118c88")
