-- Lua provided by SkyAPI 
-- Game: AppID 265000
addappid(265000)
addappid(265001, 1, "4fe7b1655e6a93fcb3623b5f1b8581bc8d301ca105ed4050acfe8834e19cf6d1")
addappid(453562, 0, "20dd16ffdbbe0c4e79f29333c9482c7877dfb7b58b8ac77bcac11147287ec44e")
addappid(453563, 0, "085e90e73b951b2953e55e45dbf28c3f749d3986a5cb935b0bc45d9698b22949")
addappid(453600)
