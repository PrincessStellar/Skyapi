-- Lua provided by SkyAPI 
-- Game: Dummynation
addappid(1892030)
addappid(1892031, 1, "f774aa35fdbc213a9300e376b44bc1fd144fdffc72af66355380a7c612dab59c")
addappid(1892032, 1, "d46ed4c39aa08f5663b55146ce5dcb320f8180b002526c5a043848aec3d75a74")
addappid(1892034, 1, "de7b2018ee7138e2e2d093ee8d159352f41d4b5b820f25be050ce03d862935ce")
