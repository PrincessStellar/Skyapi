-- Lua provided by SkyAPI 
-- Game: Airport Madness 4
addappid(387850)
addappid(387851, 1, "04209fa8e8057a1607be668fe24fd52f38d084ec6549efc272642fc4471e71d4")
