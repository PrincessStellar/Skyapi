-- Lua provided by SkyAPI 
-- Game: Brass Necessity - Demo
addappid(2824760)
addappid(2824761, 1, "2ba31e3b48ca8ac75ecf12d90e10563c9bea73968691aa474e47dc465a781b32")
addappid(2824762, 1, "2ca69f89524a97e345d497b6542d054ece3e0191f6356c0d59585ce0a31fa39f")
