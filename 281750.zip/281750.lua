-- Lua provided by SkyAPI 
-- Game: Munin
addappid(281750)
addappid(281751, 1, "a490a1dc5ee13f6bff0fadb0c0bc1fc42e9dec539f3f14587775658cb42c2b95")
