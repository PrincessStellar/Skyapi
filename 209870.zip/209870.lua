-- Lua provided by SkyAPI 
-- Game: Blacklight: Retribution
addappid(209870)
addappid(209871, 1, "b8f0f4d375949c868e38effc0492760fc1c222d3eca77ef311f85105fa80f056")
