-- Lua provided by SkyAPI 
-- Game: Dust: An Elysian Tail
addappid(236090)
addappid(236091, 1, "3155f6c04de0b5378792f0f0fbda30e9ede86cd2d21440cd04ad606c480a6d4f")
addappid(326860)
