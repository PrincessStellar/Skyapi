-- Lua provided by SkyAPI 
-- Game: AppID 375620
addappid(375620)
addappid(375621, 1, "0c56548f0fc96e259eb1f89e3d86e11876ca26cae9ca99963287a14b5671bf3e")
