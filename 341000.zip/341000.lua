-- Lua provided by SkyAPI 
-- Game: Mad Games Tycoon
addappid(341000)
addappid(341001, 1, "96a25d0e3e9e7c01469417f9624b39728c4af5bd6f874b09e5e9d0babdc405d4")
