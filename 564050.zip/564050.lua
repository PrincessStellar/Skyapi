-- Lua provided by SkyAPI 
-- Game: AppID 564050
addappid(564050)
addappid(564051, 1, "825cf8e6fbf2a6a005f7d2791f62ec008067a988e77f352ee98d7eef6ab8cbe1")
