-- Lua provided by SkyAPI 
-- Game: Chonkers
addappid(3244210)
addappid(3244211, 1, "aa9584f1d47d59b457b138110a0910e942a358280a28c0c4a5eeba0ce24faaf0")
addappid(3244212, 1, "e03eafb595bbabbeac608d519cbb4317aa78bec81e466cdbdcb4cd18bc8dae49")
