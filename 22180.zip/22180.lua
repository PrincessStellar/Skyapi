-- Lua provided by SkyAPI 
-- Game: AppID 22180
addappid(22180)
addappid(22181, 1, "8361518d950c6b853e91ebb6183945a513cbc32204a5eeb73ac0df6bef2be51d")
