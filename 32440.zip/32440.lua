-- Lua provided by SkyAPI 
-- Game: LEGO® Star Wars™ - The Complete Saga
addappid(32440)
addappid(32441, 1, "d77a4f05dc43f9c65f271b3702812287726bf1b90edb9e268382f4590bc93f63")
