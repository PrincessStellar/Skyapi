-- Lua provided by SkyAPI 
-- Game: Reflection of Mine
addappid(476020)
addappid(476021, 1, "366e2dcb145ff194030abb5617c56cac0576d41347d7086a995aa7a1d6076e8f")
addappid(594060, 0, "acb4231da757a29c33632a8fa390b7e8ea9f5110168e16ed35d8d3cd1782c1d8")
