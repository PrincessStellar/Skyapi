-- Lua provided by SkyAPI 
-- Game: Anomaly Korea
addappid(251530)
addappid(251531, 1, "b636c863af3f67cd1fe619c822730f1e7d0e2eb50cdbf01c95b43b5b2f2330c7")
