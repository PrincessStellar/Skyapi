-- Lua provided by SkyAPI 
-- Game: AppID 400040
addappid(400040)
addappid(400041, 1, "c11cc8fc37ef0584f8e81955b8d6b5dd1f9ed6f8519cc44b5eedc435da815653")
