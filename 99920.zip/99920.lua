-- Lua provided by SkyAPI 
-- Game: AppID 99920
addappid(99920)
addappid(99921, 1, "03108e9d60ac2bea5695feecd1f0a5f7dd490f02e8637e1ba9ee9fb9b745764f")
