-- Lua provided by SkyAPI 
-- Game: Forgotten Hill The Third Axis
addappid(2618920)
addappid(2618921, 1, "14ca14e15e71c0a05a767f4cff180568ff1c8b16e5f6c300707ccc3c04c9687a")
addappid(2618922, 1, "e445a4f88847a5fe7aae34f2736314b6aaed86fdb562257747bec7746b6305f8")
