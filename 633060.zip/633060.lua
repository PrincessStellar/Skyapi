-- Lua provided by SkyAPI 
-- Game: AppID 633060
addappid(633060)
addappid(633061, 1, "115ccd00243411c514b46f0e0d1c63d1d7a82f2d7e66fd9dc47a1cc5729bd6ca")
