-- Lua provided by SkyAPI 
-- Game: Brotato Soundtrack
addappid(3281080)
addappid(3281081, 1, "e6d0a71df9e37dbb1c69621d45ab42a35f0bc52e1c716e17bac88ffb29fa6cc6")
addappid(3281082, 1, "0b62d5b0ce0ca5679ccbfafa9035fcbd744dccf03d97e6f2305ef8d28bcb8c58")
