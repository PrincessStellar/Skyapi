-- Lua provided by SkyAPI 
-- Game: Linelight
addappid(469790)
addappid(469791, 1, "f1082dd64c9af1fc12d2cac7c078ea2803b51351cce9dd7616d1c0102ea37573")
addappid(587910, 0, "2178fb59468a58893facf89c344bd03e30a9b956c45c1c5bc4cf9cd41459b4d5")
