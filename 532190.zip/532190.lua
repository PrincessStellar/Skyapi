-- Lua provided by SkyAPI 
-- Game: Super Blood Hockey
addappid(532190)
addappid(532191, 1, "a0689f723c6c3993e48db15ffb4472b57f5bb755291f05eae39f3eab9adf7eac")
