-- Lua provided by SkyAPI 
-- Game: Necromancer Returns
addappid(632020)
addappid(632021, 1, "2e847db71e22a63012664f2462269bb4a0509ad78fc71a50fcc71f0003cbf4ee")
addappid(796410, 0, "032d3db03a073774c0f3a9a5fcaf6e873c2487461de104b3511d3d47874c9c8a")
