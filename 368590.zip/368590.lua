-- Lua provided by SkyAPI 
-- Game: Albert and Otto
addappid(368590)
addappid(368591, 1, "721c554b63650351fc7461fc54aa96a8c8b1b12c686ef4d1f556f90d8ad4a3cf")
addappid(418580, 0, "ad97eba66f5bf661290b521302ec294ac9e7bc276329f63bfc84ff0464949059")
