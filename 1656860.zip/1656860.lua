-- Lua provided by SkyAPI 
-- Game: AppID 1656860
addappid(1656860)
addappid(1656861, 1, "f301e5b8ee1b3ca571e4fe4fc665d10cb12a65c760318494c4c1551e468ab678")
addappid(1656862, 1, "7eabfe0cd3f140c0f02e5e3a7922664a8d545cada389ad91787eabcf0338dca3")
