-- Lua provided by SkyAPI 
-- Game: Little Kitty, Big City Soundtrack
addappid(2912860)
addappid(2912861, 1, "8f807218484798a1991badf9e3abd9141220d4db04fdb14ca3159671a6d818a2")
addappid(2912862, 1, "182b9a3af57cff3821e26311afbe4c2841477fba293607b54fd637b514418a1a")
