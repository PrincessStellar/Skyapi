-- 1049410's Lua and Manifest Created by Morrenus
-- Superliminal
-- Created: September 30, 2025 at 21:10:51 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1049410, 1, "b26cfedae29d54a4070130f05dc1ea5e88a4a14f1b3f38e899667e46856b0bb7") -- Superliminal
-- MAIN APP DEPOTS
addappid(1049411, 1, "e31233e6b65f2a9bc367c15c7bb132f1d9f0d8812222f22f072d74b78ce4daf9") -- Superliminal Game Content
--setManifestid(1049411, "3646111955971398231", 16010744346)
addappid(1049412, 1, "5e185815008cbba983f7ca6022dbd09dbf7bd5cf60ec34b328e583c337c3d48d") -- Superliminal Depot Mac
--setManifestid(1049412, "3891342746257394329", 16032166647)
addappid(1049413, 1, "2aa29e12cf628421a5b1391cf45cbb1258d24a2c01973be9070237e1e406e3c9") -- Superliminal Depot Linux
--setManifestid(1049413, "3065443301679919409", 16160081746)