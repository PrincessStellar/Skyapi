-- Lua provided by SkyAPI 
-- Game: Reshaping Mars Soundtrack
addappid(1737410)
addappid(1737411, 1, "2ed53174457038dd56b1ef62a5da5ae281e926cc8896cf7111455a4d5e9678c1")
addappid(1737412, 1, "697341b238d83e4598b87634cb21fee8c048593c644ad0542d2d2a569eec5117")
