-- Lua provided by SkyAPI 
-- Game: Crown Gambit Soundtrack
addappid(3795510)
addappid(3795511, 1, "55ad7fd4452c6b7aebeeec4a51116579951246c662ae018d70e380ec221f2d32")
addappid(3795512, 1, "a0aa2dc94cf9c502c245de16e3b199d81dd205d2fa259fd78b4e77e052d9391f")
