-- Lua provided by SkyAPI 
-- Game: Camp Buddy: Scoutmaster Season Demo
addappid(2118960)
addappid(2118961, 1, "fd5d9e0c0498dfc6854f8e5856627aad5d4cba71d1c07cfc9a44a8c8019ef324")
addappid(2118963, 1, "77284f2fa0d6652ec23fc65fe82a925b642384419ad870981a03a46d9ec2e678")
