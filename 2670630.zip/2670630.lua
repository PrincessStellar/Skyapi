-- Lua provided by SkyAPI 
-- Game: Supermarket Simulator
addappid(2670630)
addappid(2670631, 1, "72fc26c211612ffaa7b30cdfea152be9628668260d7f8c375980e0f96e445701")
addappid(2670632, 1, "05a026749d66983d1a8b484cee9c7e2e320926d365ae5fe9f916ca8e96c00e4a")
