-- Lua provided by SkyAPI 
-- Game: AppID 268540
addappid(268540)
addappid(268541, 1, "23feeb76adcd09d11c5f05c332ec9bc8d2865aa2832d801a9b57c113f7ead12f")
