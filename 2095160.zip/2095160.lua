-- Lua provided by SkyAPI 
-- Game: 液化物LIQUID Demo
addappid(2095160)
addappid(2095161, 1, "b2a92d43f9c75d8c867399ff8336bc71df28008e13d3d869884e9be426d790c7")
addappid(2095162, 1, "c8b08070a76ac20c2dd894d0568646d6b7e07273887e00aecbdbff4c41828a77")
