-- Lua provided by SkyAPI 
-- Game: APB Reloaded
addappid(113400)
addappid(113401, 1, "d6858c2ba4940054cdf81e2ac1d381f1468321c4fe7bc22dc8aac8d58148e9cc")
addappid(228984, 0, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068")
addappid(229002, 0, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738")
