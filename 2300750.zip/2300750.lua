-- Lua provided by SkyAPI 
-- Game: MathCar
addappid(2300750)
addappid(2300751, 1, "028f8c6a12d4833b8d4dffdc068c2214dd74a29807da010d5279b86fcdd9a191")
addappid(2300752, 1, "e5d5c154cdb62878d11bd525fb424d89dc204e75756cd76dc3d74693f0e11799")
