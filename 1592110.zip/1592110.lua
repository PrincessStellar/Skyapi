-- Lua provided by SkyAPI 
-- Game: Spirit of the Island
addappid(1592110)
addappid(1592111, 1, "e963a4163cc8989fe8bcc4dae5709550a284429f0956ff816864793f7a57b8df")
addappid(2419841, 1, "24c059a735e6e103d2aab530b015ebea2c7f2c1350a40c3b90ada94a83c44574")
addappid(2507940, 0, "90193764368eacd12ec78d6d8cbcc62f842c777db44cf19a88484ccd352aee5e")
