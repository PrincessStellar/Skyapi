-- Lua provided by SkyAPI 
-- Game: Abyss: The Wraiths of Eden
addappid(284710)
addappid(284711, 1, "f8e2bf4ef6ebe8d50907607d29ed292e2e2730e1123952114d7719b2728ad2db")
