-- Lua provided by SkyAPI 
-- Game: AppID 587620
addappid(587620)
addappid(587621, 1, "dbef9c5a131af356bcee9780519c447ff2fcf3b38399004c4aa76bd0eb85adec")
