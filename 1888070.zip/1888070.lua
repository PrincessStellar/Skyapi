-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1888070)
addappid(1888071,0,"f79c9e1ef0d9e2fa3c7a4d17b85acbf86a61e8625762bc9bd3ecc47e408ae7d4")
setManifestid(1888071,"5801256811200232074")
addappid(1888072,0,"133e1ffeaf570ef5e7df1bdfeb50bd77d7358653804bd00a340057b070894a33")
setManifestid(1888072,"6643428226284161545")
addappid(1888073,0,"59bddeec63f70bd660bf4de08ad39e8b91c03b43afb1a26383ff28c6190fa5c5")
setManifestid(1888073,"6222980486921281005")
addappid(2352110)