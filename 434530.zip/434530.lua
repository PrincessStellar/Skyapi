-- Lua provided by SkyAPI 
-- Game: AppID 434530
addappid(434530)
addappid(434531, 1, "41509135c0cdbd104dffb46e4ea395f1a8301e97bfc0988fad733bdb74eb1ddd")
