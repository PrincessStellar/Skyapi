-- Lua provided by SkyAPI 
-- Game: Into the Dead: Our Darkest Days
addappid(2239710)
addappid(2239711, 1, "b157624d7bd77e603f16902ecbb3c59596e83a552e4089ce119057efa9d2f0b4")
addappid(2239712, 1, "713b1f42f286d0647a93eb4b1ce92343c3294fbb200f2f937fa695d914c2d66b")
