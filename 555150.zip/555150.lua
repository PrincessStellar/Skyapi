-- Lua provided by SkyAPI 
-- Game: AppID 555150
addappid(555150)
addappid(555151, 1, "9cb9ba8f8cc67e2d84b45ca95aafccc0a562a3065582ee4e6780af58a03c18d0")
