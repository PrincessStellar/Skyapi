-- Lua provided by SkyAPI 
-- Game: Floors of Discomfort
addappid(372770)
addappid(372771, 1, "83bfad04a859772e1ca0913f22bf2da76dc9f5d8510b90b00e5a83244aa72c62")
