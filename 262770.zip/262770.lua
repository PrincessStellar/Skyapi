-- Lua provided by SkyAPI 
-- Game: Freedom Fall
addappid(262770)
addappid(262771, 1, "e76d9b6620cafb8b211080025d965feee0178dc991f3a1d5bd3c1daf1e761cac")
