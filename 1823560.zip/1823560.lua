-- Lua provided by SkyAPI 
-- Game: Anno: Mutationem Original Game Soundtrack Complete Edition
addappid(1823560)
addappid(1823561, 1, "ef12706289534d19f04e607c8ea78da1ca5f8fe1749f80ea0da212855f4094d6")
addappid(1823562, 1, "81c8b95ba8985277b143abfa3519b878e3963fdbcf4ac92226d8e767aa1cdbdc")
