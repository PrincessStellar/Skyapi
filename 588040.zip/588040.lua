-- Lua provided by SkyAPI 
-- Game: AppID 588040
addappid(588040)
addappid(588041, 1, "c9980cae454ca6aa70a0bde765512e866a7ac57e9db0abb4676bf7e5b38a73d7")
