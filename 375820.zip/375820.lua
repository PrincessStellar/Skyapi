-- Lua provided by SkyAPI 
-- Game: AppID 375820
addappid(375820)
addappid(375821, 1, "31b9e993b5d4b3887ecb03835a9c656599bef4a0541af61855fa8e6012543645")
