-- Lua provided by SkyAPI 
-- Game: Dangerous High School Girls in Trouble!™
addappid(27400)
addappid(27401, 1, "aefbb85f88caa4730a2e62a99aefe7b88072a86d0d0e06cd599c73ae30ddf7c9")
