-- Lua provided by SkyAPI 
-- Game: AppID 317710
addappid(317710)
addappid(317711, 1, "6c894e8fce69e76d6504e44ba504b9e847147e27b902f918d42d23ee1cf0ab8c")
