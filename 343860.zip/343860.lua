-- Lua provided by SkyAPI 
-- Game: Tacoma
addappid(343860)
addappid(343861, 1, "695ce80ed38ba63dfb0c7a1778f6ce3137e33ea48511a80046ba99a38e65d92c")
