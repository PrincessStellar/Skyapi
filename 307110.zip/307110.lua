-- Lua provided by SkyAPI 
-- Game: We Need To Go Deeper
addappid(307110)
addappid(307111, 1, "80bbf4c35e33893b32c6bd09378d89025fdcc94428ae2f79cdca786d24f18024")
addappid(1128020, 0, "50d66b04e6c7ba432ed444621dff827d12c4fd68f0b56f2783a487516945ed07")
addappid(2241680, 0, "6e426e912aecda99c780db40f86b028910ca9c4891a2a4ac9868af629ed5a846")
