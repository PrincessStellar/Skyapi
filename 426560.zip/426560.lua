-- Lua provided by SkyAPI 
-- Game: Full Tilt Poker
addappid(426560)
addappid(426561, 1, "e6dfa6a65c6af9225b2c7355d25ffd25a8f5ff763b58412f4da97a8261cd2b02")
