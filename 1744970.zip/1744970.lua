-- Lua provided by SkyAPI 
-- Game: Petit Island
addappid(1744970)
addappid(1744971, 1, "ed0b04db7cc19e53ce6439e7462dba6ca5843895e24561c887ac68718ef8513c")
addappid(1744973, 1, "c4c32eae27f87ec67dfd69dda81a3842599ae66886161933807d193f10a5925c")
