-- Lua provided by SkyAPI 
-- Game: AppID 410970
addappid(410970)
addappid(410971, 1, "a4ed80962c9fd292e8873862c3055e54fe8df8775aa072406241c172a6b5d64b")
