-- Lua provided by SkyAPI 
-- Game: A Trip to Yugoslavia: Director's Cut
addappid(545410)
addappid(545411, 1, "783495255cd76f85a24d8fab5948adeb76e75de4f58ffe3c8286197c6c8b9c42")
