-- Lua provided by SkyAPI 
-- Game: The Hat Man: Shadow Ward
addappid(291010)
addappid(291011, 1, "77ed43abb5867bff7e2c32daf96ed2093db35307a20bd77d83dce6d14e228f78")
addappid(475460)
