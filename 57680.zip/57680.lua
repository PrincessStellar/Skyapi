-- Lua provided by SkyAPI 
-- Game: AppID 57680
addappid(57680)
addappid(57681, 1, "fa7ead9e4b66e2d435c8502d22914aa416f5dc126bc1ab3b045f7a1bc58a7a5b")
