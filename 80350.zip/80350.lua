-- Lua provided by SkyAPI 
-- Game: Blackwell Convergence
addappid(80350)
addappid(80351, 1, "5f9a9773c02646980a0f05877d6c8f95a84f03f4f27d327bce552ac6a9206616")
addappid(2051780, 0, "db97a604734d3bc6aaa267a41e5290696dca5eac028114e3f30a11c579da7cac")
