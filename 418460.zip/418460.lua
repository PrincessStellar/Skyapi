-- Lua provided by SkyAPI 
-- Game: Rising Storm 2: Vietnam
addappid(418460)
addappid(418461, 1, "cf81b97143fb2a34580f171c2d5eb46c95b873e1a7f079c3e18eead69aca3926")
