-- Lua provided by SkyAPI 
-- Game: Super Sanctum TD
addappid(235250)
addappid(235251, 1, "bb22795698d724cc67722a4520e63e8de275663a616db758e0433bee41a31597")
