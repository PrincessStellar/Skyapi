-- Lua provided by SkyAPI 
-- Game: Etherion Online
addappid(2227990)
addappid(2227991, 1, "fcae836bb9ae26f310e9fabc4d2abfee8eccd8c5ee8069f23aa7a73dcb45819a")
addappid(2227992, 1, "004e15cd790f0d903a54e28aea3f1ba9e0c0de8d63a75ca7240e01ada0f48391")
