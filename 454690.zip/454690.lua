-- Lua provided by SkyAPI 
-- Game: AppID 454690
addappid(454690)
addappid(454691, 1, "9b064ed012dce5e8e2f022ad4fec5c1b409ac75438acde3f55953f8764fbe97f")
