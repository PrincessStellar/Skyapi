-- Lua provided by SkyAPI 
-- Game: Tomboys Need Love Too!
addappid(628920)
addappid(628921, 1, "760657e925e33f31c5b744e8f40436a3c0ba0106f214e4506127a32db198e04b")
addappid(943180, 0, "200001abe4c14856a0bc134132043828ba99855d7aacfb33b71a130e54fb1969")
