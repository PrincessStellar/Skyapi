-- Lua provided by SkyAPI 
-- Game: AppID 63710
addappid(63710)
addappid(63711, 1, "df5cb35bf6fb9fb96edf46dbd1580a5da418b3b8e5008274dba67c09c682baef")
addappid(202961, 0, "d62b83f76a2e9d5afb086018ef24e074e668f8e7a6d464cc842b4a622b0c2e23")
