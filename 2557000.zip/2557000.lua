-- Lua provided by SkyAPI 
-- Game: Prominence Poker - Original Soundtrack
addappid(2557000)
addappid(2557001, 1, "8b0cc68944510731d5fe59ee3430d9ac4a1e21968c010571589b9e84fb055d20")
addappid(2557002, 1, "2c46fb72c46f1ad479768f8f10c7a28ae6a6779afde62ba51262bf0b045c1533")
