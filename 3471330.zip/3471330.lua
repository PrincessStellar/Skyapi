-- Lua provided by SkyAPI 
-- Game: AppID 3471330
addappid(3471330)
addappid(3471331, 1, "ff8201a6315bdbd1293d40f30f8f0118c839fed03f04b9410f1ff2b1367fe263")
addappid(3471332, 1, "5a58a1f77d1404bf59f6d2c0b7e6f1d455d58d6eb24d894c756538eacc56163c")
