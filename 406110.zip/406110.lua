-- Lua provided by SkyAPI 
-- Game: Asdivine Hearts
addappid(406110)
addappid(406111, 1, "65997810d4a34ce11ac842b6007f94ef30210f86d511cdc3e71b210c423c6a6e")
