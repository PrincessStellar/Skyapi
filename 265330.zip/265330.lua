-- Lua provided by SkyAPI 
-- Game: Gomo
addappid(265330)
addappid(265331, 1, "5f5c00b4fab7d2cfd30d22b271ca1694bb95bd983cd597b4d2bbdd2059ab787d")
