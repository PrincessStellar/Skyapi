-- Lua provided by SkyAPI 
-- Game: Pay2Win: The Tricks Exposed
addappid(416760)
addappid(416761, 1, "fe893e02cfdf299b021fa34e84d3ef577ddbe9c935ebd06908eb138eb05e54de")
