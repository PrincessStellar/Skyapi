-- Lua provided by SkyAPI 
-- Game: Sonic Generations Collection
addappid(71340)
addappid(71341, 1, "e9a94a9cea6b1e07fb4ab98e4186c7af965a32ace868d3ed5bf8151adc2016e0")
addappid(200590)
