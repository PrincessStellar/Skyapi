-- Lua provided by SkyAPI 
-- Game: Phantom Breaker: Omnia Original Game Soundtrack
addappid(1764110)
addappid(1764111, 1, "09d6076fddd0f19b7b3b5d617fa87304e3f8bfad988958fdf26ead5436c9c944")
addappid(1764112, 1, "4a7c5ee84504ad49014355b119260aca00eef45885d63905ce8ddfdbb3f2503b")
