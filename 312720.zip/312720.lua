-- Lua provided by SkyAPI 
-- Game: Khet 2.0
addappid(312720)
addappid(312721, 1, "976bf97250d7d5afde92fc0c77b2672204e1af2e81f4319c2f780537cd687a9c")
addappid(327610)
