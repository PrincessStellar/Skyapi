-- Lua provided by SkyAPI 
-- Game: Grimgrad
addappid(1837340)
addappid(1837341, 1, "24ba207f9fb9574d2121090df3a114cc545532a4e21e8271a9a7d85632388ffc")
addappid(1837342, 1, "ccab1f21885b1fee2bd7ac3cc0b75f453ce30b637dced1cef7e6d74482abe8c2")
