-- Lua provided by SkyAPI 
-- Game: Infested Planet
addappid(204530)
addappid(204531, 1, "df80b94e10e93a6cf5eef5823adb94698115c649e88a91e0c3ccba2d749e9c2e")
addappid(358020, 0, "c8500ca0ceb2070c6a011269ebee70f47f898d48c5a1337330465b2558d332aa")
addappid(529620, 0, "5dde4c07a14cb4c2e95204a52bb1f06e65582ce6e1b31107a95899a26de6304c")
