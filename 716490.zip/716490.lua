-- Lua provided by SkyAPI 
-- Game: EXAPUNKS
addappid(716490)
addappid(716491, 1, "073b9cc0793c0e46222c5f40a0ab20e9018de00297df5c03cfa69a3c86daed43")
