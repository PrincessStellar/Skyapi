-- Lua provided by SkyAPI 
-- Game: AppID 546410
addappid(546410)
addappid(546411, 1, "0de3287f693e66764bff9f192dbd03b0785d8c8035f0b4d50bc4ebf04a3e4d5f")
