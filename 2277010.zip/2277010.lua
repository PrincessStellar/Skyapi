-- Lua provided by SkyAPI 
-- Game: Postmouse Soundtrack
addappid(2277010)
addappid(2277011, 1, "6fa7c7fb52f7d0a8b88c46302ecf1880e1363754548c8592e443f6b822a9f658")
addappid(2277012, 1, "7484df01338937184c24cb83dcf6c8832d2e4aba69e3c2b48d852389333154d5")
