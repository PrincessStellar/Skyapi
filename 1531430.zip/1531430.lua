-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1531430)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1531431,0,"1c549cd790d156d8ee3e77068c5b703473ca56182ded2a3323b1ecc214e25ea5")
setManifestid(1531431,"1000769327921509532")